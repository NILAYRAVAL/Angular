import { Controller, Get, Post, Body, Patch, Param, Delete, Query, Res, Req, ValidationPipe } from '@nestjs/common';
import { FaqService } from './faq.service';
import { CreateFaqDto } from './dto/create-faq.dto';
import { UpdateFaqDto } from './dto/update-faq.dto';

@Controller('faq')
export class FaqController {
  constructor(private readonly faqService: FaqService) {}

  @Post(':id?')
  async create(@Body(ValidationPipe) createFaqDto: CreateFaqDto , @Req() req ,@Res() response )  {
    
    try{
      const id = req.params.id;

      if (id) {
        const updatedService = await this.faqService.update(id, createFaqDto);
        return response.status(200).json({ message: 'Faq updated successfully', data: updatedService });
      } else {
        const createdService = await this.faqService.create(createFaqDto);
        return response.status(201).json({ message: 'Faq created successfully', data: createdService });
      }
    }
    catch (error) {
      console.error('Error creating/updating service:', error);
      return response.status(500).json({ message: 'Internal server error' });
    }
    
    // return this.faqService.create(createFaqDto);
  }



  @Get()
  async findAll() {
    return this.faqService.findAll();  
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.faqService.findOne(+id);
  }

  // @Patch(':id')
  // update(@Param('id') id: string, @Body() updateFaqDto: UpdateFaqDto) {
  //   return this.faqService.update(id, updateFaqDto);
  // }

  @Delete(':id')
  remove(@Param('id') id: number) {
    return this.faqService.remove(id);
  }
}
