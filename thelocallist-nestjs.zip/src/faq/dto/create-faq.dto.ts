import { IsNotEmpty, IsString } from "class-validator";

export class CreateFaqDto {

    // @IsString({message:"Question must be string"})
    // @IsNotEmpty({message:"Question should not be empty"})
    question:string;

    // @IsString({message:"Answer must be string"})
    // @IsNotEmpty({message:"Answer should not be empty"})
    answer:string;

    CreatedOn?:Date;

}
