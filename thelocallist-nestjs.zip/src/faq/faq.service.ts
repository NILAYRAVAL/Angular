import { Injectable } from '@nestjs/common';
import { CreateFaqDto } from './dto/create-faq.dto';
import { UpdateFaqDto } from './dto/update-faq.dto';
import { Model, now } from 'mongoose';
import { Faq } from './schema/faq.schema';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class FaqService {
  constructor(
    @InjectModel(Faq.name) private faqModal:Model<Faq>){

  }
  create(createFaqDto: CreateFaqDto) {
    createFaqDto.CreatedOn=now();
    const newFaq=new this.faqModal(createFaqDto);
    newFaq.save();
    return newFaq
  }



  async findAll() {
      return this.faqModal.find()
        .then((x) => { return x })
        .catch((error) => { console.log(error); })
    }
    

  findOne(id: number) {
    return `This action returns a #${id} faq`;
  }

  async update(id: string, updateFaqDto: CreateFaqDto): Promise<Faq> {
    try {
      const updatedFaq = await this.faqModal.findByIdAndUpdate(id, updateFaqDto, { new: true }).exec();
      return updatedFaq;
    } catch (error) {
      console.error('Error updating FAQ:', error);
      throw error;
    }}

  async remove(id: number) {
    return await this.faqModal.findByIdAndDelete(id).exec();
  }  

}
