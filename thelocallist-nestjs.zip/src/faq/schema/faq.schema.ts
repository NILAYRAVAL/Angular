import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import * as Joi from "joi";
import { ObjectId, SchemaTypes } from "mongoose";
import { IsNotEmpty, IsString } from "class-validator";

@Schema()
export class Faq{
   
    @Prop({required:true})
    question:string;
    
    @Prop({required:true})
    answer:string;

    @Prop({required:false})
    CreatedOn:Date

    @Prop({required:false})
    UpdatedOn :Date

    @Prop({required:false ,type: SchemaTypes.ObjectId})
    CreatedBy:ObjectId;

    @Prop({required:false,type: SchemaTypes.ObjectId})
    UpdatedBy :ObjectId
}

export const FaqSchema=SchemaFactory.createForClass(Faq)

