import { Inquiry } from "../entities/inquiry.entity";

export class CreateInquiryDto extends Inquiry  {

    customerName:string;
    emailAddress:string;
    mobileNumber:string;
    description:string;
    dateTime:string;
    VenderId:string;
    CreatedOn?:Date;
}
