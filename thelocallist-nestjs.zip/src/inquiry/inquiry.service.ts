import { Injectable } from "@nestjs/common";
import { CreateInquiryDto } from "./dto/create-inquiry.dto";
import { UpdateInquiryDto } from "./dto/update-inquiry.dto";
import { Model, now } from "mongoose";
import { Inquirys } from "./schema/inquiry.schema";
import { InjectModel } from "@nestjs/mongoose";
import { Vendor } from "src/vendor/schema/vendor.schema";

@Injectable()
export class InquiryService {
  constructor(
    @InjectModel(Vendor.name) private vendorModel: Model<Vendor>,
    @InjectModel(Inquirys.name) private inquiryModal: Model<Inquirys>
  ) {}
  create(createInquiryDto: CreateInquiryDto) {
    createInquiryDto.CreatedOn = now();
    let VenderId = "";

    createInquiryDto.VenderId = VenderId;
    const newInq = new this.inquiryModal(createInquiryDto);
    newInq.save();
    return newInq;
  }

  async findAll() {
    return this.inquiryModal
      .find()
      .then((x) => {
        return x;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  async findOne(id: string) {
    return this.inquiryModal
      .findOne({ id: id })
      .then((inq) => {
        return inq;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  async update(
    id: string,
    updateInquiryDto: UpdateInquiryDto
  ): Promise<Inquirys> {
    try {
      return await this.inquiryModal
        .findByIdAndUpdate(id, updateInquiryDto)
        .exec();
    } catch (error) {
      console.error("Error updating INQUIRY:", error);
      throw error;
    }
  }

  async remove(id: string) {
    return await this.inquiryModal.findByIdAndDelete(id).exec();
  }
}
