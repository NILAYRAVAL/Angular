import { Module } from '@nestjs/common';
import { InquiryService } from './inquiry.service';
import { InquiryController } from './inquiry.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Inquirys, InquirySchema } from './schema/inquiry.schema';
import { Vendor, VendorSchema } from 'src/vendor/schema/vendor.schema';

@Module({
  imports:[
    MongooseModule.forFeature([
      {
        name:Inquirys.name, 
        schema:InquirySchema
      },
      {
        name:Vendor.name,  
        schema:VendorSchema
      },
    ])
  ],
  controllers: [InquiryController],
  providers: [InquiryService],
})
export class InquiryModule {}
