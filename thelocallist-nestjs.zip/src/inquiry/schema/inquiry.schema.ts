import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import * as Joi from "joi";
import { ObjectId, SchemaTypes } from "mongoose";
import { IsNotEmpty, IsString } from "class-validator";
import { User } from "src/user/schema/user.schema";
import { Vendor } from "src/vendor/schema/vendor.schema";

@Schema()
export class Inquirys {
  @Prop({ required: true })
  customerName: string;

  @Prop({ required: true })
  emailAddress: string;

  @Prop({ required: true })
  mobileNumber: string;

  @Prop({ required: true })
  description: string;

  @Prop({ required: true })
  dateTime: string;

  @Prop({ required: false })
  CreatedOn: Date;

  @Prop({ required: false })
  UpdatedOn: Date;

  @Prop({ required: false, type: SchemaTypes.ObjectId, ref: Vendor.name })
  VenderId: ObjectId;

  @Prop({ required: false, type: SchemaTypes.ObjectId })
  CreatedBy: ObjectId;

  @Prop({ required: false, type: SchemaTypes.ObjectId })
  UpdatedBy: ObjectId;
}

export const InquirySchema = SchemaFactory.createForClass(Inquirys);
