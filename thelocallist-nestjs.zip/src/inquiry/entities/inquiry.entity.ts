export class Inquiry {

    customerName:string;
    emailAddress:string;
    mobileNumber:string;
    description:string;
    dateTime:string;
    VenderId:string
}
