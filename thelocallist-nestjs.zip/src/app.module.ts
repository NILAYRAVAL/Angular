import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ServicesModule } from './services/services.module';
import { MongooseModule } from '@nestjs/mongoose';
import { FaqModule } from './faq/faq.module';
import { ContactusModule } from './contactus/contactus.module';
import { BlogModule } from './blog/blog.module';
import { VendorModule } from './vendor/vendor.module';
import { UserModule } from './user/user.module';
import { InquiryModule } from './inquiry/inquiry.module';
import { PlansModule } from './plans/plans.module';


@Module({
  imports: [MongooseModule.forRoot('mongodb://localhost/service'), ServicesModule, FaqModule, ContactusModule, BlogModule, VendorModule, UserModule, InquiryModule, PlansModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
