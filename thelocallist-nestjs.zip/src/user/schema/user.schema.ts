import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import * as Joi from "joi";
import { ObjectId, SchemaTypes } from "mongoose";
import { IsNotEmpty, IsString } from "class-validator";

@Schema()
export class User{
   
    @Prop({required:false})
    name:string;
    
    @Prop({ unique:[false,"Duplicate email"]})
    email:string;

    // @Prop({required:false})
    // phoneNumber:string;

    @Prop({required:false})
    role:string;

    @Prop({required:false})
    stepper:string;

    @Prop({required:false})
    password:string;

    @Prop({required:false})
    confirmPassword:string

    @Prop({required:false})
    CreatedOn:Date

    @Prop({required:false})
    UpdatedOn :Date

    @Prop({required:false ,type: SchemaTypes.ObjectId})
    CreatedBy:ObjectId;

    @Prop({required:false,type: SchemaTypes.ObjectId})
    UpdatedBy :ObjectId
}

export const UserSchema=SchemaFactory.createForClass(User)

