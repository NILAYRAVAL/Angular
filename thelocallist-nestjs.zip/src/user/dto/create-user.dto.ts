export class CreateUserDto {
    name:string;
    email:string;
    // phoneNumber:number;
    role:string;
    password:string;
    confirmPassword:string;
    CreatedOn?:Date;

}


export class SignUpDto{
    name:string;
    email:string;
    password:string
}

export class LoginDto{
    email:string;
    password:string
}

export class updateStep{
    userId:string;
    stepper:string
}