import { Controller, Get, Post, Body, Patch, Param, Delete, Req, Res } from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto, LoginDto, SignUpDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('add/edit/id?')
  async create(@Body() createUserDto: CreateUserDto , @Req() req ,@Res() response )  {
    
    try{
      const id = req.params.id;

      if (id) {
        const updatedService = await this.userService.update(id, createUserDto);
        return response.status(200).json({ message: 'User updated successfully', data: updatedService });
      } else {
        const createdService = await this.userService.create(createUserDto);
        return response.status(201).json({ message: 'User created successfully', data: createdService });
      }
    }
    catch (error) {
      console.error('Error creating/updating service:', error);
      return response.status(500).json({ message: 'Internal server error' });
    }
    
    // return this.faqService.create(createFaqDto);
  }

@Post('/signup')
signUp(@Body() signUpDto : SignUpDto): Promise<{token:string}>{
  try{
    // let res=this.userService.signUp(signUpDto)
    return this.userService.signUp(signUpDto)
    // return  this.response(res)

  }catch(error:any){
    console.log(error)
    // throw error;
    return error
  }
}

@Post('/login')
login(@Body() loginDto : LoginDto): Promise<{token:string}>{
  return this.userService.loginIn(loginDto)
}



  @Get()
  findAll() {
    return this.userService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.userService.findOne(+id);
  }

  // @Patch(':id')
  // update(@Param('id') id: Number, @Body() updateUserDto: UpdateUserDto) {
  //   return this.userService.update(id, updateUserDto);
  // }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.userService.remove(+id);
  }


  public response(res:any,status:number=200,success:boolean=true):any{
    return {
      status,
      success,
      data:res
    }
  }
}
