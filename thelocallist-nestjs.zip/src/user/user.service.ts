import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateUserDto, LoginDto, SignUpDto, updateStep } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { InjectModel } from '@nestjs/mongoose';
import { User } from './schema/user.schema';
import { Model, now } from 'mongoose';
import * as bcrypt from 'bcryptjs'
import { JwtService } from '@nestjs/jwt';
@Injectable()
export class UserService {
  constructor(
    @InjectModel(User.name) private userModal:Model<User> , private jwtService: JwtService){

  }
  create(createUserDto: CreateUserDto) {
    createUserDto.CreatedOn=now();
    const newUser=new this.userModal(createUserDto);
    newUser.save();
    console.log(JSON.stringify(newUser))
    return newUser
  }

  async signUp(signUpDto:SignUpDto):Promise<{token:string, role:string , stepper:string,userId:string}>{
    const {name , email , password} =signUpDto

    const hashedPassword = await bcrypt.hash(password,10)
    const role = 'VENDOR';
    const stepper = 'ADDRESS';
    const user = await this.userModal.create({
      name,
      email,
      password:hashedPassword,
      role,
      stepper
    })
    const token = this.jwtService.sign({id:user._id})
    //{token,role,stepper,userId:user._id.toString()}
    const loginReq:LoginDto={
      email,
      password
    }
    return await this.loginIn(loginReq)
    
  }

  // async updateStep(updateStep:updateStep){
  //   return this.userModal.findByIdAndUpdate(updateStep.userId,{stepper:updateStep.stepper});
  // }
  async updateStep(updateStep: updateStep) {
    try {
        const updatedStepper = await this.userModal.findByIdAndUpdate(updateStep.userId, { stepper: updateStep.stepper });
        if (!updatedStepper) {
            console.log("User not found or not updated.");
            return null;
        }
        console.log("Updated user:", updatedStepper);
        return updatedStepper;
    } catch (error) {
        console.error("Error updating step:", error);
        throw error;
    }
}



//  async loginIn(loginDto:LoginDto):Promise<{token:string, role:string , stepper:string,userId:string}>{
//   const {email,password}=loginDto

//   const user =await this.userModal.findOne({email})
//   if(!user){
//     throw new UnauthorizedException('Invalid email or password')
//   }

//   const isPasswordMatched = await bcrypt.compare(password , user.password)
//   if(!isPasswordMatched){
//     throw new UnauthorizedException('Invalid email or password')
//   }
//   const token = this.jwtService.sign({id:user._id})
//   // {token,role,stepper,userId:user._id.toString()}
//   return {token,role:user.role,stepper:user.stepper,userId:user._id.toString()}
//  }

 async loginIn(loginDto: LoginDto): Promise<{ token: string, role: string, stepper: string, userId: string }> {
  const { email, password } = loginDto;

  const user = await this.userModal.findOne({ email });
  if (!user || user.password !== password) {
    throw new UnauthorizedException('Invalid email or password');
  }

  const token = this.jwtService.sign({ id: user._id });
  return { token, role: user.role, stepper: user.stepper, userId: user._id.toString() };
}


  async findAll() {
    return this.userModal.find()
      .then((x) => { return x })
      .catch((error) => { console.log(error); })
  }
  
  findOne(id: number) {
    return `This action returns a #${id} user`;
  }

  async update(id: string, updateUserDto: CreateUserDto): Promise<User> {
    try {
      const updatedFaq = await this.userModal.findByIdAndUpdate(id, updateUserDto, { new: true }).exec();
      return updatedFaq;
    } catch (error) {
      console.error('Error updating FAQ:', error);
      throw error;
    }}

  remove(id: number) {
    return `This action removes a #${id} user`;
  }
}
