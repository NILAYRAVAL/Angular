import { Injectable } from "@nestjs/common";
import { CreatePlanDto } from "./dto/create-plan.dto";
import { UpdatePlanDto } from "./dto/update-plan.dto";
import { Model, now } from "mongoose";
// import { Inquirys } from "./schema/inquiry.schema";
import { InjectModel } from "@nestjs/mongoose";
// import { Vendor } from "src/vendor/schema/vendor.schema";
import { plans } from "./schema/plans.schema";

@Injectable()
export class PlansService {
  constructor(
    // @InjectModel(Vendor.name) private vendorModel: Model<Vendor>,
    @InjectModel(plans.name) private plansModal: Model<plans>
  ) {}
  create(createPlanDto: CreatePlanDto) {
    createPlanDto.CreatedOn = now();

    const newInq = new this.plansModal(createPlanDto);
    newInq.save();
    return newInq;
  }

  async findAll() {
    return this.plansModal
      .find()
      .then((res) => {
        return res;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  async findOne(id: string) {
    return this.plansModal
      .findOne({ id: id })
      .then((res) => {
        return res;
      })
      .catch((error) => {
        console.log(error);
      });
  }

  async update(id: string, updatePlanDto: UpdatePlanDto): Promise<plans> {
    try {
      return await this.plansModal.findByIdAndUpdate(id, updatePlanDto).exec();
    } catch (error) {
      console.error("Error updating PLANS:", error);
      throw error;
    }
  }

 async remove(id: string) {

  return await this.plansModal.findByIdAndDelete(id).exec();
  }
}
