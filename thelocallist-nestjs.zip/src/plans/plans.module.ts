import { Module } from '@nestjs/common';
import { PlansService } from './plans.service';
import { PlansController } from './plans.controller';
import { plans, PlanSchema } from './schema/plans.schema';
import { MongooseModule } from '@nestjs/mongoose';

@Module({
  imports:[
    MongooseModule.forFeature([
      {
        name:plans.name, 
        schema:PlanSchema
      },
    ])
  ],
  controllers: [PlansController],
  providers: [PlansService],
})
export class PlansModule {}
