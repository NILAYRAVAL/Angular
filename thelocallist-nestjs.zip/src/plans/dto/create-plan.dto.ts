import { Plan } from "../entities/plan.entity";

export class CreatePlanDto extends Plan {
  level: string;
  priceMonthly: string;
  priceYearly: string;
  service: plans_data[];
  CreatedOn?: Date;
}
interface plans_data {
  name: string;
  count:string;

  isProvided: boolean;
  appointments: string;
  gallery: string;
  additionalService: string;
  lastPayment: Date;
  nextPayment: Date;
  renewDate: Date;
}
