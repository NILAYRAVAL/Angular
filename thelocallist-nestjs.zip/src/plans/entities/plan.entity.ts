export class Plan {
  level: string;
  priceMonthly: string;
  priceYearly: string;
  service: plans_data[]
  // VenderId: string;
  CreatedOn?: Date;
}
interface plans_data{
  name: string;
  count:string;
  isProvided:boolean,
  appointments: string;
  
  gallery: string;
  additionalService: string;
  lastPayment: Date;

}