import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import * as Joi from "joi";
import { ObjectId, SchemaTypes } from "mongoose";
// import { Vendor } from "src/vendor/schema/vendor.schema";

@Schema()
export class plans {
  @Prop({ required: true })
  level: string;

  @Prop({ required: true })
  priceMonthly: string;

  @Prop({ required: true })
  priceYearly: string;

  @Prop({ required: true })
  service: string[];

  @Prop({ required: false })
  name: string;

  @Prop({ required: false })
 count: string;

  @Prop({ required: false })
  isProvided: boolean;

  @Prop({ required: false })
  appointments: string;

  @Prop({ required: false })
  gallery: string;

  @Prop({ required: false })
  additionalService: string;

  @Prop({ required: false })
  lastPayment: Date;

  @Prop({ required: false })
  nextPayment: Date;

  @Prop({ required: false })
  renewDate: Date;

  @Prop({ required: false })
  CreatedOn: Date;

  @Prop({ required: false })
  UpdatedOn: Date;

//   @Prop({ required: false, type: SchemaTypes.ObjectId, ref: Vendor.name })
//   VenderId: ObjectId;

  @Prop({ required: false, type: SchemaTypes.ObjectId })
  CreatedBy: ObjectId;

  @Prop({ required: false, type: SchemaTypes.ObjectId })
  UpdatedBy: ObjectId;
}

export const PlanSchema = SchemaFactory.createForClass(plans);
