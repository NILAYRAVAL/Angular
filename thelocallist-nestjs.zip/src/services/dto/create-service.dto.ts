
export class CreateServiceDto {
 
    name:string;
    image?:any;
    icon?:string;
    CreatedOn?:Date;
  id: any;
}

