import { Injectable, NotFoundException, Req, Res } from '@nestjs/common';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Services } from './schema/service.schema';
import { Model, now } from 'mongoose';
import * as AWS from 'aws-sdk';
// import { Query } from 'express-serve-static-core';

@Injectable()
export class ServicesService {
  constructor(
    @InjectModel(Services.name) private servicesModel:Model<Services>    ){

  }

  AWS_S3_BUCKET = 'test-s3-direct-upload';
  s3 = new AWS.S3({
    accessKeyId: 'AKIAXQ4DMZG4A2YLFMBS',
    secretAccessKey: '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',
  });

  async uploadFile(file) {
    console.log(file,"fileeeee");
    const { originalname } = file;

    return await this.s3_upload(
      file.buffer,
      this.AWS_S3_BUCKET,
      originalname,
      file.mimetype,
    );
  }

  async s3_upload(file, bucket, name, mimetype) {
    const params = {
      Bucket: bucket,
      Key: String(name),
      Body: file,
      ACL: 'public-read',
      ContentType: mimetype,
      ContentDisposition: 'inline',
      CreateBucketConfiguration: {
        LocationConstraint: 'ap-south-1',
      },
    };

    try {
      let s3Response = await this.s3.upload(params).promise();
      return s3Response;
    } catch (e) {
      console.log(e);
    }
  }

 create(createServiceDto: CreateServiceDto) {
    createServiceDto.CreatedOn=now();
    const newService=new this.servicesModel(createServiceDto);
    newService.save();
    return newService;
  }

//  async findAll(query:any) {
//   const resPerPage = 10;
//   const currentPage = Number(query.page) || 1;
//   const skip = resPerPage * (currentPage - 1);
//   const keyword = query.keyword
//   ? {
//       name: {
//         $regex: query.keyword,
//         $options: 'i',
//       },
//     }
//   : {};
//   console.log(query)
//   const books = await this.servicesModel
//   .find({ ...keyword }).limit(resPerPage)
//   .skip(skip);

// return books;
//     // return this.servicesModel.find({keyword})
//     //   .then((x) => { return x })
//     //   .catch((error) => { console.log(error); })
//   }

async findAll() {
  return this.servicesModel.find()
    .then((x) => { return x })
    .catch((error) => { console.log(error); })
}
findOne(id: number) {
return `This action returns a #${id} blog`;
}


  async update(id: string, updateServiceDto: UpdateServiceDto): Promise<Services> {
    try {
      const updatedService = await this.servicesModel.findByIdAndUpdate(id, updateServiceDto, { new: true }).exec();
      return updatedService;
    } catch (error) {
      console.error('Error updating service:', error);
      throw error;
    }
  }
  
  async remove(id: number) {
    return await this.servicesModel.findByIdAndDelete(id).exec();
  }  

  //delete image from s3
  async deleteFile(fileKey:string){
    try{
      const deletedFile = await this.s3.
      deleteObject({
        Bucket:this.AWS_S3_BUCKET,
        Key:fileKey,
      })
      .promise()
      return deletedFile;
    }
    catch(error){
      console.log(error)
    }
  }

 
}
