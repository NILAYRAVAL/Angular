import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import * as Joi from "joi";
import { ObjectId, SchemaTypes } from "mongoose";
@Schema()
export class Services{
    @Prop({required:true})
    name:string;
    
    @Prop({required:false})
    icon:string;

    @Prop({required:true})
    image:string;

    @Prop({required:false})
    CreatedOn:Date

    @Prop({required:false})
    UpdatedOn :Date

    @Prop({required:false ,type: SchemaTypes.ObjectId})
    CreatedBy:ObjectId;

    @Prop({required:false,type: SchemaTypes.ObjectId})
    UpdatedBy :ObjectId
}

export const ServicesSchema=SchemaFactory.createForClass(Services)

export const createServiceSchema = Joi.object({
    name: Joi.string().required(),
    icon: Joi.string(),
    image: Joi.string().required(),
  });