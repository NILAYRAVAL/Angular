import { Controller, Get, Post, Body, Patch, Param, Delete, UseInterceptors, UploadedFile, Req, Res, UploadedFiles, Query } from '@nestjs/common';
import { ServicesService } from './services.service';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';
import { createServiceSchema } from './schema/service.schema';
import { FileInterceptor } from '@nestjs/platform-express';
import * as AWS from 'aws-sdk';
import * as multer from 'multer';
import * as multerS3 from 'multer-s3';
const AWS_S3_BUCKET_NAME = 'test-s3-direct-upload';
AWS.config.update({
  accessKeyId:'AKIAXQ4DMZG4A2YLFMBS',
  secretAccessKey:'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',
});
const s3 = new AWS.S3();

@Controller('services')
export class ServicesController {
  constructor(private readonly servicesService: ServicesService) {}

  @Post(':id?')
  @UseInterceptors(FileInterceptor('imageFile'))
  
 async create(@Body() createServiceDto: CreateServiceDto, @Res() response  , @Req() req,@UploadedFile() file: Express.Multer.File) {
  
    try {
      const id = req.params.id;
  
      // const validationResult = createServiceSchema.validate(createServiceDto);
      // if (validationResult.error) {
      //   return response.status(400).json({ message: validationResult.error.details[0].message });
      // }
  
      if (!file) {
        return response.status(400).json({ message: 'Image file is required' });
      }
      const filesRes: any = await this.servicesService.uploadFile(file);
      if (filesRes) {
        createServiceDto.image = filesRes.Location;
      }

      if (id) {
        const updatedService = await this.servicesService.update(id, createServiceDto);
        return response.status(200).json({ message: 'Service updated successfully', data: updatedService });
      } else {
        const createdService = await this.servicesService.create(createServiceDto);
        return response.status(201).json({ message: 'Service created successfully', data: createdService });
      }
    } catch (error) {
      console.error('Error creating/updating service:', error);
      return response.status(500).json({ message: 'Internal server error' });
    }
    
        
  }

  @Get()
  async findAll() {
    return this.servicesService.findAll();
    
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.servicesService.findOne(+id);
  }

  // @Patch(':id')
  // update(@Param('id') id: number, @Body() updateServiceDto: UpdateServiceDto) {
  //   return this.servicesService.update(id, updateServiceDto);
  // }

  @Delete(':id')
  remove(@Param('id') id: number) {
    return this.servicesService.remove(id);
  }

 @Delete('d/:key')
 async deleteFile(@Param('key') fileKey:string){
  return this.servicesService.deleteFile(fileKey)
 }
  
}



