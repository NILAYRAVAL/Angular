import { IsEmail, IsEmpty, IsNotEmpty, IsString, isEmail } from "class-validator";

export class CreateContactusDto {
 
    // 
    @IsNotEmpty({message:"Name should not be empty"})
    @IsString({message:"Name must be string"})
    name: string;

    @IsString({message:"Email must be string"})
    @IsNotEmpty({message:"Email should not be empty"})
    email:string;

    @IsString({message:"Message must be string"})
    @IsNotEmpty({message:"Message should not be empty"})
    message:string;
    createdOn?:Date;
}


//check
