import { Module } from '@nestjs/common';
import { ContactusService } from './contactus.service';
import { ContactusController } from './contactus.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { ContactSchema, ContactUs } from './schema/contactus.schema';

@Module({
  imports:[
    MongooseModule.forFeature([
      {
        name:ContactUs.name, 
        schema:ContactSchema
      }
    ])
  ],
  controllers: [ContactusController],
  providers: [ContactusService],
})
export class ContactusModule {}
