import { Controller, Get, Post, Body, Patch, Param, Delete, Req, Res, ValidationPipe } from '@nestjs/common';
import { ContactusService } from './contactus.service';
import { CreateContactusDto } from './dto/create-contactus.dto';
import { UpdateContactusDto } from './dto/update-contactus.dto';

@Controller('contactus')
export class ContactusController {
  constructor(private readonly contactusService: ContactusService) {}

 
  @Post()
  async create(@Body(ValidationPipe) createFaqDto: CreateContactusDto , @Req() req ,@Res() response )  {
    
    try{
        const createdService = await this.contactusService.create(createFaqDto);
        return response.status(201).json({ message: 'Faq created successfully', data: createdService });
    
    }
    catch (error) {
      console.error('Error creating/updating service:', error);
      return response.status(500).json({ message: 'Internal server error' });
    }
    
  }


  @Get()
  findAll() {
    return this.contactusService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.contactusService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateContactusDto: UpdateContactusDto) {
    return this.contactusService.update(+id, updateContactusDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.contactusService.remove(+id);
  }
}
