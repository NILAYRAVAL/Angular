import { Injectable } from '@nestjs/common';
import { CreateContactusDto } from './dto/create-contactus.dto';
import { UpdateContactusDto } from './dto/update-contactus.dto';
import { ContactUs } from './schema/contactus.schema';
import { InjectModel } from '@nestjs/mongoose';
import { Model, now } from 'mongoose';

@Injectable()
export class ContactusService {
  constructor(
    @InjectModel(ContactUs.name) private ContactModal:Model<ContactUs>){

  }
  create(createContactusDto: CreateContactusDto) {
    createContactusDto.createdOn=now();
    const newContact=new this.ContactModal(createContactusDto);
    newContact.save();
    return newContact
  }


  async findAll() {
    return this.ContactModal.find()
      .then((x) => { return x })
      .catch((error) => { console.log(error); })
  }
  findOne(id: number) {
    return `This action returns a #${id} contactus`;
  }

  update(id: number, updateContactusDto: UpdateContactusDto) {
    return `This action updates a #${id} contactus`;
  }

  remove(id: number) {
    return `This action removes a #${id} contactus`;
  }
}
