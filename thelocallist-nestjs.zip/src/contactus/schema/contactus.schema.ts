import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import * as Joi from "joi";
import { ObjectId, SchemaTypes } from "mongoose";
@Schema()
export class ContactUs{
    @Prop({required:false})
    name:string;
    
    @Prop({required:true})
    email:string;

    @Prop({required:false})
    CreatedOn:Date

    @Prop({required:true})
    message :string

    @Prop({required:false ,type: SchemaTypes.ObjectId})
    CreatedBy:ObjectId;
 
}

export const ContactSchema=SchemaFactory.createForClass(ContactUs)

