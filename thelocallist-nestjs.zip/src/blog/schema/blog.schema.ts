import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import * as Joi from "joi";
import { ObjectId, SchemaTypes } from "mongoose";
@Schema()
export class Blog{
    @Prop({required:true})
    image:string;
    
    @Prop({required:true})
    title:string;

    @Prop({required:true})
    shortdesc:string;

    @Prop({required:true})
    longdesc:string;

    @Prop({required:false})
    CreatedOn:Date

    @Prop({required:false})
    UpdatedOn :Date

    @Prop({required:false ,type: SchemaTypes.ObjectId})
    CreatedBy:ObjectId;

    @Prop({required:false,type: SchemaTypes.ObjectId})
    UpdatedBy :ObjectId
}

export const BlogSchema=SchemaFactory.createForClass(Blog)

