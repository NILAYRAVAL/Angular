export class CreateBlogDto {
    image:string;
    shortdesc:string;
    longdesc:string;
    title:string;
    CreatedOn?:Date;

}
