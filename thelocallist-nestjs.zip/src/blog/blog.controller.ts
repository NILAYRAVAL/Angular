import { Controller, Get, Post, Body, Patch, Param, Delete, UseInterceptors, Res, UploadedFile, Req, Query } from '@nestjs/common';
import { BlogService } from './blog.service';
import { CreateBlogDto } from './dto/create-blog.dto';
import { UpdateBlogDto } from './dto/update-blog.dto';
import * as AWS from 'aws-sdk';
import { FileInterceptor } from '@nestjs/platform-express';

const AWS_S3_BUCKET_NAME = 'test-s3-direct-upload';
AWS.config.update({
  accessKeyId:'AKIAXQ4DMZG4A2YLFMBS',
  secretAccessKey:'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',
});
const s3 = new AWS.S3();
@Controller('blog')
export class BlogController {
  constructor(private readonly blogService: BlogService) {}

  @Post(':id?')
  @UseInterceptors(FileInterceptor('imageFile'))
  
 async create(@Body() createBlogDto: CreateBlogDto, @Res() response  , @Req() req,@UploadedFile() file: Express.Multer.File) {
  
    try {
      const id = req.params.id;
  
    
      if (!file) {
        return response.status(400).json({ message: 'Image file is required' });
      }
      const filesRes: any = await this.blogService.uploadFile(file);
      if (filesRes) {
        createBlogDto.image = filesRes.Location;
      }

      if (id) {
        const updatedBlog = await this.blogService.update(id, createBlogDto);
        return response.status(200).json({ message: 'Blog updated successfully', data: updatedBlog });
      } else {
        const createdBlog = await this.blogService.create(createBlogDto);
        return response.status(201).json({ message: 'Blog created successfully', data: createdBlog });
      }
    } catch (error) {
      console.error('Error creating/updating service:', error);
      return response.status(500).json({ message: 'Internal server error' });
    }
    
        
  }

  @Get()
  findAll() {
    return this.blogService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.blogService.findOne(+id);
  }

  // @Patch(':id')
  // update(@Param('id') id: string, @Body() updateBlogDto: UpdateBlogDto) {
  //   return this.blogService.update(+id, updateBlogDto);
  // }

  @Delete(':id')
  remove(@Param('id') id: number) {
    return this.blogService.remove(id);
  }
}
