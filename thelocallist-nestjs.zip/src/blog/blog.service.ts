import { Injectable } from '@nestjs/common';
import { CreateBlogDto } from './dto/create-blog.dto';
import { UpdateBlogDto } from './dto/update-blog.dto';
import * as AWS from 'aws-sdk';
import { InjectModel } from '@nestjs/mongoose';
import { Blog } from './schema/blog.schema';
import { Model, now } from 'mongoose';

@Injectable()
export class BlogService {
  constructor(
    @InjectModel(Blog.name) private blogModal:Model<Blog>    ){

  }

  AWS_S3_BUCKET = 'test-s3-direct-upload';
  s3 = new AWS.S3({
    accessKeyId: 'AKIAXQ4DMZG4A2YLFMBS',
    secretAccessKey: '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',
  });

  async uploadFile(file) {
    console.log(file,"fileeeee");
    const { originalname } = file;

    return await this.s3_upload(
      file.buffer,
      this.AWS_S3_BUCKET,
      originalname,
      file.mimetype,
    );
  }

  async s3_upload(file, bucket, name, mimetype) {
    const params = {
      Bucket: bucket,
      Key: String(name),
      Body: file,
      ACL: 'public-read',
      ContentType: mimetype,
      ContentDisposition: 'inline',
      CreateBucketConfiguration: {
        LocationConstraint: 'ap-south-1',
      },
    };

    try {
      let s3Response = await this.s3.upload(params).promise();
      return s3Response;
    } catch (e) {
      console.log(e);
    }
  }
  create(createBlogDto: CreateBlogDto) {
    createBlogDto.CreatedOn=now();
    const newBlog=new this.blogModal(createBlogDto);
    newBlog.save();
    return newBlog;
  }

  async findAll() {
 
  
      return this.blogModal.find()
        .then((x) => { return x })
        .catch((error) => { console.log(error); })
    }
  findOne(id: number) {
    return `This action returns a #${id} blog`;
  }
  async update(id: string, updateBlogDto: UpdateBlogDto): Promise<Blog> {
    try {
      const updateBlog = await this.blogModal.findByIdAndUpdate(id, updateBlogDto, { new: true });
      return updateBlog;
    } catch (error) {
      console.error('Error updating service:', error);
      throw error;
    }
  }

  async remove(id: number) {
    return await this.blogModal.findByIdAndDelete(id).exec();
  }  
}
