import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrationComponent } from './Component/registration/registration.component';
import { LoginComponent } from './Component/login/login.component';
import { OtpGeneratorComponent } from './Component/otp-generator/otp-generator.component';
import { HomePageComponent } from './home-page/home-page.component';
import { AppComponent } from './app.component';
import { StudentComponent } from './Component/student/student.component';
import { TeacherComponent } from './Component/teacher/teacher.component';
// import { ApplicationComponent } from './application/application.component';


const routes: Routes = [
  // { path: '', component:AppComponent,children:[
  //     { path: 'application', 
  //     loadChildren:()=>import('./application/application/application-routing.module')
  //     .then(m=>m.ApplicationRoutingModule),}
    
  // ] },
  { path: '', component: LoginComponent, pathMatch:'full'},
  { path: 'Login', component: LoginComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'otp', component: OtpGeneratorComponent  },
  { path: 'home', component: HomePageComponent  },
  { path: 'student', component: StudentComponent  },
  { path: 'teacher', component: TeacherComponent  },
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
