import { Component, OnInit } from '@angular/core';
import { MatTableModule } from '@angular/material/table';



@Component({
  selector: 'home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css'],

})
export class HomePageComponent implements OnInit {
  user: any
  greet: any;
  STUDENT_DATA: any;
  showFiller = false;

  
 
  ngOnInit(): void {
    this.user = localStorage.getItem('values');
    // document.getElementById('values').textContent=user  
    // console.log(user);
    var pen = new Date()
    let finalHour = pen.getHours();
    if (finalHour < 12) this.greet = 'Good Morning';
    else if (finalHour >= 12 && finalHour <= 17) this.greet = 'Good Afternoon';
    else if (finalHour >= 17 && finalHour <= 24) this.greet = 'Good Evening';
    console.log(finalHour);
    console.log(this.greet);
  }

}

