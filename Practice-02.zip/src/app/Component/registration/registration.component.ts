import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  loginPageForm: FormGroup;
  hide = true;
  hide1=true;
  // route: any;
  
  confirmPasswordValidator: ValidatorFn = (
    control: AbstractControl
  ): ValidationErrors | null => {
    
    console.log(control)
    return control.value.password === control.value.cpassword
    ? null
    : { PasswordNoMatch: true };
  };
  constructor(private _fa_: FormBuilder,public route:Router) { }

  ngOnInit(): void {
    this.loginPageForm = this._fa_.group({
      userName: this._fa_.control(null,Validators.required),
      email:this._fa_.control(null,Validators.compose([Validators.required,Validators.email,Validators.pattern('[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}')])),
      password:this._fa_.control(null,[Validators.required,Validators.pattern('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{10,}$')]),
      cpassword:this._fa_.control(null,[Validators.required,Validators.pattern('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{10,}$')]),
    },{Validators:this.confirmPasswordValidator})
  }
  loginForm(){
    console.log(this.loginPageForm);
    console.log(this.loginPageForm.value);
    this.route.navigateByUrl('/Login'); //navigate into next page.
    
  }
  getErrorMessage() {
    if (this.loginPageForm.get('email').hasError('required')) {
      return 'You must enter a value';
    }
    return this.loginPageForm.get('email').hasError('email') ? 'Not a valid email' : '';
  }
  
}

