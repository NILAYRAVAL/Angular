import { Component } from '@angular/core';
export interface PeriodicElement {
  id: number,
  name: string,
  joinDate: any,
  education: string,
  sub:string,
}

const TEACHER_DATA: PeriodicElement[] = [
  { id: 1, name: "Aakash0", joinDate: "11/02/2013", education: "BSC",sub:"English" },
  { id: 2, name: "Aakash1", joinDate: "1/2/2013",  education:"B.E",sub:"internet of things" },
  { id: 3, name: "Aakash2", joinDate: "21/1/2013", education: "MSC",sub:"Data science" },
  { id: 4, name: "Aakash3", joinDate: "15/3/2013", education: "B.Com",sub:"Apllied computing" },
  { id: 5, name: "Aakash4", joinDate: "09/7/2013", education: "ARTS",sub:"cloud development" },
  { id: 6, name: "Aakash5", joinDate: "16/9/2013", education: "M.E",sub:"Software development" },
];
@Component({
  selector: 'teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.css']
})
export class TeacherComponent {
  displayedColumns: string[] = ['id', 'name', 'joinDate', 'education','sub'];
  dataSource = TEACHER_DATA;

}
