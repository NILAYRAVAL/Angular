import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxOtpInputConfig } from 'ngx-otp-input';

@Component({
  selector: 'otp-generator',
  templateUrl: './otp-generator.component.html',
  styleUrls: ['./otp-generator.component.css']
})
export class OtpGeneratorComponent implements OnInit {
  b: any
  OtpPageForm: FormGroup
  // random: any;
  otpInputConfig: NgxOtpInputConfig = {
    otpLength: 6,

    autofocus: true,
    classList: {
      inputBox: 'my-super-box-class',
      input: 'my-super-class',
      inputFilled: 'my-super-filled-class',
      inputDisabled: 'my-super-disable-class',
      inputSuccess: 'my-super-success-class',
      inputError: 'my-super-error-class',
    },
  };

  handeOtpChange(value: string[]): void {
    console.log(value);
  }

  handleFillEvent(value: string): void {
    console.log(value);
  }
  // GenerateOtp:any

  constructor(private _otp_: FormBuilder,public route:Router) { }
  ngOnInit(): void {
    this.OtpPageForm = this._otp_.group({
      otpnumber: this._otp_.control(null, Validators.required),
      GenerateOtp: this._otp_.control(null),
    })
  }
  otpForm() {
    console.log(this.OtpPageForm.value);
    this.route.navigateByUrl('/home');
  }

  randomn() {
    let b = Math.random().toString().substr(2, 6)
    // let a = Number(b)
    console.log(b);
    // console.log(typeof (a));
  }
}

