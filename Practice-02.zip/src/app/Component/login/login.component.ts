import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  loginPageForm: FormGroup;
  hide = true;
  hide1=true;
  
  constructor(private _fa_: FormBuilder,public route:Router) { }

  ngOnInit(): void {
    this.loginPageForm = this._fa_.group({
      userName: this._fa_.control(null,Validators.required),
      password:this._fa_.control(null,[Validators.required]),
      
    })
  }
  loginForm(){
    // console.log(this.loginPageForm);
    console.log(this.loginPageForm.value);
    this.route.navigateByUrl('/otp'); //navigate into next page
    localStorage.setItem('values',this.loginPageForm.value.userName);
  }
}

