import { Component } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

export interface PeriodicElement {
  id: number,
  name: string,
  std: any,
  dob: string,
  dor: string
}

const STUDENT_DATA: PeriodicElement[] = [
  { id: 1, name: "Aakash0", std: 5, dob: "11/02/2013" , dor: "11/2/2026" },
  { id: 2, name: "Aakash1", std: 6, dob: "1/2/2013", dor:"11/23/2014" },
  { id: 3, name: "Aakash2", std: 7, dob: "21/1/2013", dor:"11/23/2013" },
  { id: 4, name: "Aakash3", std: 12, dob: "15/3/2013", dor:"11/23/2016" },
  { id: 5, name: "Aakash4", std: 10, dob: "09/7/2013", dor:"11/23/2018" },
  { id: 6, name: "Aakash5", std: 3, dob: "16/9/2013", dor:"11/23/2019" },
];
@Component({
  selector: 'student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent {

  displayedColumns: string[] = ['id', 'name', 'std', 'dob','dor'];
  dataSource = STUDENT_DATA;
}
