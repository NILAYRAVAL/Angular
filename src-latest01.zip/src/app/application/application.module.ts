import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApplicationRoutingModule } from './application-routing.module';
import { ApplicationComponent } from './application.component';
import { SharedModule } from '../shared/shared.module';
import { AlertDialogComponent } from '../shared/component/alert-dialog/alert-dialog.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    ApplicationComponent,
    AlertDialogComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    ApplicationRoutingModule,
    ReactiveFormsModule,    
    FormsModule,
  ]
})
export class ApplicationModule { }
