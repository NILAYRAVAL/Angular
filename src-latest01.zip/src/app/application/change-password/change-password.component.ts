import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/shared/Services/auth.service';
import { UserService } from 'src/app/shared/Services/components-services /user.service';
import { UtilService } from 'src/app/shared/Services/util.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
})
export class ChangePasswordComponent implements OnInit {

  public changePassFrom!: FormGroup;
  public current_hide:boolean = true;
  public isLoading : boolean =  false;
  public new_pass_hide:boolean = true;
  public confirm_hide:boolean = true;

  public formValidations: any = {
    current_password: [
      { type: 'required', message: 'Current Password is required' },
    ],
    new_password: [{ type: 'required', message: 'Password is required' }],
    confirm_password: [
      { type: 'required', message: 'Confirm Password is required' },
    ],
  };

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    public utilService: UtilService,
    public authService: AuthService,
    private router: Router,
    public userService: UserService
    
  ) {}

  ngOnInit(): void {
    this.changePassFrom = this.formBuilder.group({
      current_password: ['', [Validators.required]],
      new_password: ['', [Validators.required]],
      confirm_password: ['', [Validators.required]],
    },
    {
      validator: this.MustMatch('new_password', 'confirm_password')
    });
  }

  onSubmit() {
    this.changePassFrom.get('current_password')?.setValue((this.changePassFrom.get('current_password')?.value
    ? this.changePassFrom.get('current_password')?.value: ' ').trim());
    this.changePassFrom.get('new_password')?.setValue((this.changePassFrom.get('new_password')?.value
    ? this.changePassFrom.get('new_password')?.value: ' ').trim());
    this.changePassFrom.updateValueAndValidity();
    this.changePassFrom.markAllAsTouched();

    if (this.changePassFrom.valid) {
      this.isLoading = true;
      let basicDetailForm = this.changePassFrom.value;
      delete basicDetailForm.confirm_password

      basicDetailForm.current_password = this.utilService.convertStringBase64(basicDetailForm.current_password);
      basicDetailForm.new_password = this.utilService.convertStringBase64(basicDetailForm.new_password);

      this.userService.userChangePassword(basicDetailForm).subscribe((res: any) => {
          this.isLoading = true;
          this.utilService.storeLocalStorageValue('userDetail', res.data);
          // this.utilService.storeLocalStorageValue('access_token',res.access_token,false);
          this.utilService.showSuccess(res.message,'Success')
          // this.router.navigateByUrl('/application/dashboard');
          this.utilService.logOut()
        },
        (error) => {
         this.isLoading = false;
          if (error && error.error.errors && error.error.errors.failed) {
            this.utilService.showError(error.error.errors.failed[0]);
          }else
          if (error && error.error.errors && error.error.errors.new_password) {
            this.utilService.showError(error.error.errors.new_password[0]);
          }else
          if (error && error.error.errors && error.error.errors.current_password) {
            this.utilService.showError(error.error.errors.current_password[0]);
          }
        }
      );
    }
  }

  MustMatch(controlName: string, matchingControlName: string) {
    controlName.trim()
    matchingControlName.trim()
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];
      if (matchingControl.errors && !matchingControl.errors['mustMatch']) {
        return;
      }
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    };
  }

  public onChangePassword() {
    this.changePassFrom.updateValueAndValidity();
    this.changePassFrom.markAllAsTouched();
  }
}
