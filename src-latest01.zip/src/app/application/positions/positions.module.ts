import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PositionsRoutingModule } from './positions-routing.module';
import { PositionsComponent } from './positions.component';
import { SharedModule } from 'src/app/shared';
import { AddPositionComponent } from './add-position/add-position.component';
import { PositionDetailsComponent } from './position-details/position-details.component';


@NgModule({
  declarations: [
    PositionsComponent,
    AddPositionComponent,
    PositionDetailsComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    PositionsRoutingModule
  ]
})
export class PositionsModule { }
