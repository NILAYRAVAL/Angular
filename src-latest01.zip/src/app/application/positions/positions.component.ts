import { Component, OnInit} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddEditCandidateComponent } from 'src/app/shared/component/add-edit-candidate/add-edit-candidate.component';
import { GlobalVariableService } from 'src/app/shared/Services/global-variable.service';
import { AddPositionComponent } from './add-position/add-position.component';
import { CommonServiceService } from 'src/app/shared/Services/common-service.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { AlertDialogComponent } from 'src/app/shared/component/alert-dialog/alert-dialog.component';
import { PositionService } from 'src/app/shared/Services/components-services /position.service';

import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe, Location } from '@angular/common';
import { FormControl } from '@angular/forms';
import { debounceTime, switchMap } from 'rxjs';


@Component({
  selector: 'app-positions',
  templateUrl: './positions.component.html',
  styleUrls: ['./positions.component.css'],
  providers: [DatePipe]
})
export class PositionsComponent implements OnInit{
 public searchControl!: FormControl;
  
 public allPoasitionData: any = [];
 public exp_date : any = null;
 public filterValue: any = {};
 
 public total: number = 0;
 public currentPage: number = 0;
 public pageSizeOptions: number[] = [10, 25, 50, 100];
 public pageSize:number = 10;

 public  panelOpenState: boolean = false;
 public isPosition_Expiry : boolean = false;
 public setMinExperience: boolean = false;
 public isLoading : boolean = false;
 public dataNotFound : boolean = false;

 public searchText: string = '';
 public position_status :  string = '';
 public minDate: any = '';
 public isOpen_Close_Position : any = '';
 public currentDate = new Date();

  constructor(public matDialog: MatDialog,
              public globalVariable:GlobalVariableService,
              public commonService : CommonServiceService,
              private _utilService : UtilService,
              private dialog: MatDialog,
              private activeRoute: ActivatedRoute,
              public location: Location,
              public positionService:PositionService,
              private _datePipe: DatePipe,
              public router : Router) 
              {
               }

  ngOnInit(): void {
    let myDate = new Date();
    this.minDate = this._datePipe.transform(myDate, 'yyyy-MM-dd');
    this.activeRoute.queryParams.subscribe((params: any) => {
      this.filterValue = {
          order_by: 'position_id',
          sort_by: 'ASC',
      }
      let pageNumber = params['page'] ? parseInt(params['page']) : 0;
      this.searchText = params['search'] ? params['search'] : undefined;
      this.getAllPositionData(pageNumber, 10, 'ASC', 'position_id', this.searchText, this.filterValue);
    });
    this.searchFilter()
    this.getAllPositionData()
  }

  public searchFilter(){
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
    .pipe(
      debounceTime(1000),
      switchMap(searchTerm => {
        //Make Api call herecons
        this.searchText = searchTerm
        this.getPositionBySearch()
        return searchTerm; 
      })
    ).subscribe(result => {
     
    });
  }
  

  public appendURLParameters() {
    let mergedString: string = '';
    mergedString += '?page=' + this.filterValue.page_no;

    if (this.filterValue.search && this.filterValue.search !== null && this.filterValue.search !== '') {
        mergedString += '&search=' + this.filterValue.search;
    }
    this.location.replaceState('/application/positions' + mergedString);
}

public pageChangedCommon($event: any) {
  let pageNo = ($event.pageIndex);
  let perPage = $event.pageSize;
  this.filterValue.page_no = pageNo;
  this.getAllPositionData(pageNo, perPage);
}

public getPositionBySearch() {
if(this.searchText.length > 0) {
  this.getAllPositionData(0, 10, 'ASC', 'position_id', this.searchText, this.filterValue);
}
if(!this.searchText.length) {
  this.getAllPositionData(0, 10, 'ASC', 'position_id', '', this.filterValue);
}
}

public  getAllPositionData(pageNo: number = this.currentPage, perPage: number = 10,  sort_by: string = 'ASC',
  order_by: string = 'position_id', search?: string, filters: any = {}, type?: string){
    // this.isProjectFolderLoading = true;
    this.isLoading = true;
    this.filterValue.per_page = perPage;
    this.filterValue.is_open = this.isOpen_Close_Position;
    this.filterValue.page_no = pageNo;
    this.filterValue.sort_by = sort_by;
    this.filterValue.order_by = order_by;
    if (search) {
        this.filterValue.search = search;
    } else {
        delete this.filterValue.search;
    }
    if (Object.keys(filters).length) {
        Object.keys(filters).map((key: string) => {
            if (filters[key]) {
                this.filterValue[key] = filters[key];
            }
        })
    }
    this.appendURLParameters();
    // let filterCopyObj = _.cloneDeep(this.filterValue);
    let filterCopyObj = this.filterValue;
    filterCopyObj.page_no++;
    this.positionService.getPositionList(filterCopyObj).subscribe((res:any)=>{
        this.allPoasitionData = res.data
        this.isLoading = false;  
        this.dataNotFound = false;
        res.data.forEach((el:any)=>{
          let temp='';
          el.qualificationsIds=[]
          el.qualifications.map((qualification:any)=>{
            temp +=temp?(' ,'+qualification.qualification_name):qualification.qualification_name
            el.qualificationsIds.push(qualification.qualification_id);
          })
          el.qualificationsString=temp;
          this.total = res.with.total;
          this.currentPage = pageNo;
        })
    },
    (error) => {
      if (error && error.error.errors && error.error.errors.failed) {
        this._utilService.showError(error.error.errors.failed[0]);
        this.allPoasitionData = [];
        this.dataNotFound = true;
        this.isLoading = false;  
  }})
  }
   
public  openAddUpdatePositionModal($event:any){
    let model = $event 
    const dialogRef = this.matDialog.open(AddPositionComponent, {
      width: '55vw',
      data: {
        title: $event ? 'Edit Position' : 'Add Position',
        msg: '',
        btnName: $event ? 'Update' :'Save',
        model: model,
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.getAllPositionData()
      }
    });
  }

public  openAddCandidateModel(event:any){
    let model = event
    const dialogRef = this.matDialog.open(AddEditCandidateComponent, {
      width: '70vw',
      autoFocus: false,
      data: {
        title: event ? 'Edit Candidate' : 'Add Candidate',
        msg: '',
        mode: 'Apply',
        btnName: event ? 'Apply' :'Save',
        model: model,
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
    
      }
    });
  }

  // conformation dialog //
public  conformationDialog(id:any) {
    const dialogRef = this.dialog.open(AlertDialogComponent,{
      maxWidth:'400px',
      data:{
        message: 'Are you sure want to delete this position?',
        buttonText: {
          ok: 'Delete',
          cancel: 'Cancel'
        }
      }
    });
     
    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.positionService.deletepsition(id).subscribe((res:any)=>{
          this.getAllPositionData()
          this._utilService.showSuccess('Position Deleted successful!','Success')
        })
      }
    });
  }

public selectPositionStatus(event:any){
  if(event == '1'){
  this.isOpen_Close_Position = 1;
  this.getAllPositionData(0, 10, 'ASC', 'position_id', this.searchText, this.filterValue);
  }else if(event == '0'){
    this.isOpen_Close_Position = 0;
    this.getAllPositionData(0, 10, 'ASC', 'position_id', this.searchText, this.filterValue);
  }else if(event == ''){
    this.isOpen_Close_Position = '';
    this.getAllPositionData(0, 10, 'ASC', 'position_id', this.searchText, this.filterValue);
  }
}

public redirectTo_positon_deatils(id:any){
  this.router.navigate([`/application/positions/position-details/id`],{queryParams : {position_id : id}})
}


}
