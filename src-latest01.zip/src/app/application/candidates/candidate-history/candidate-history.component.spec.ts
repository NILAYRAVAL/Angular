import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateHistoryComponent } from './candidate-history.component';

describe('CandidateHistoryComponent', () => {
  let component: CandidateHistoryComponent;
  let fixture: ComponentFixture<CandidateHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CandidateHistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CandidateHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
