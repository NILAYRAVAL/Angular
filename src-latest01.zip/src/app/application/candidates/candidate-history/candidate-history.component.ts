import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { AddEditCandidateComponent } from 'src/app/shared/component/add-edit-candidate/add-edit-candidate.component';
import { CandidateCommentComponent } from 'src/app/shared/component/candidate-comment/candidate-comment.component';
import { ImgPdfViewerModalComponent } from 'src/app/shared/component/img-pdf-viewer-modal/img-pdf-viewer-modal.component';
import { CandidateService } from 'src/app/shared/Services/components-services /candidate.service';
import { GlobalVariableService } from 'src/app/shared/Services/global-variable.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { Location } from '@angular/common';

const ELEMENT_DATA: any = [];

@Component({
  selector: 'app-candidate-history',
  templateUrl: './candidate-history.component.html',
  styleUrls: ['./candidate-history.component.scss']
})
export class CandidateHistoryComponent implements OnInit {

  public dataSource = ELEMENT_DATA;
  public candidateId: any = null;
  public candidateHistoryData: any = null;
  public candidateApplicationDetails: any = null;
  
  public isLocationFound : boolean = false;
  public panelOpenState:boolean = false;
  public isLoading : boolean = false;
  
  public displayedColumns: string[] = ['created_at', 'stage_name', 'status', 'comment', 'scheduled_date'];
  
    constructor(
      public globalService: GlobalVariableService,
      private candidateSerivce: CandidateService,
      private utilService: UtilService,
      private route: ActivatedRoute,
      private router: Router,
      private dialog: MatDialog
    ) { 
 
    }
  
    ngOnInit(): void {
      
      this.route.queryParams.subscribe((param: any) => {
        this.candidateId = parseInt(param.candidate_id);
        this.isLocationFound = param.isBack
      })
  
      if(this.candidateId) {
        this.getAllGeneralCandidateHistoryData();
        this.getAllCandidateHistoryData();
      }
   
    }
  
   public getAllGeneralCandidateHistoryData() {
      this.candidateSerivce.getCandidatePersonById(this.candidateId).subscribe((res: any) => {
        if(res && res.data) {
          let el = res.data;
          // res.data.forEach((el: any) => {
            let getYear =  (el.month_experience / 12).toFixed(2)
          let years = getYear.toString().split(".")[0]
          let Months:any = parseInt(getYear.toString().split(".")[1])
              Months = Months > 9 ? (Months/100)*12 : (Months/10)*12
              Months=Math.round(Months)
              el.year_experience = parseInt(years)
              el.months_experience = Months
    
            if(el.month_experience >= 12) {
              el.showExperienceData = el.year_experience +'.'+ el.months_experience + ' Years';
            }
    
            if(el.month_experience < 12) {
              el.showExperienceData = el.months_experience+' Months';
            }
    
            el.id = el.application_id
            el.position_id = el.last_application?.position_id
            el.name = el.name
            el.mobile = el.phone
            el.current_ctc = el.last_application?.current_ctc
            el.expected_ctc = el.last_application?.expected_ctc
            el.notice_period = el.last_application?.notice_period
            el.source = el.last_application?.source
            el.supplier_id = el.last_application?.supplier_id
            el.reference_by = el.last_application?.reference_by
            let skills_aryStr = ''
            el.person_skills.forEach((el:any)=>{
              skills_aryStr += ', ' + el.skill_name
            })
            el.skills_ary = skills_aryStr.split(", ").splice(1).join(',');
            el.position = el.position?.technology?.technology_name
    
            let qualifiactionList = ''
            el.person_qualification.forEach((el: any) => {
              qualifiactionList += ', ' + el.qualification_name
            })
            el.qualifiactions = qualifiactionList.slice(1)
            // console.log("qualifiactions ))(==", el.qualifiactions);
    
            el.email = el.email
            el.stageObj = el.stage
            el.statusObj = el.status
            el.stage = el.stage?.stage_name
            el.status = el.status?.status_name
  
            el.current_city_detailpage = (el.current_city) ? el.current_city.city_name : '';
            el.current_state_detailpage = (el.current_state) ? el.current_state.state_name : '';
            el.native_city_detailpage = (el.native_city) ? el.native_city.city_name : '';
            el.native_state_detailpage = (el.native_state) ? el.native_state.state_name : '';
            
            el.person_experience.forEach((el: any) => {
              el.company_name = el.company?.company_name
              el.company_id = el.company?.company_id
              el.isChecked =  el.to_due ? false : true 
              el.start_month = moment(el.from_due).format('MM')
              el.start_year = moment(el.from_due).format('yyyy')
              el.end_month = el.to_due ? moment(el.to_due).format('MM') : ''
              el.end_year = el.to_due ? moment(el.to_due).format('yyyy') : ''
            })
          // })
    
          // this.candidateHistoryData.forEach((el: any) => {
            el.qualificationsIds = []
            el.person_qualification.map((qualification: any) => {
              el.qualificationsIds.push(qualification.qualification_id);
            })
          // })
          // this.candidateHistoryData.forEach((el: any) => {
            el.skillIds = []
            el.person_skills.map((skills_id: any) => {
              el.skillIds.push(skills_id.skill_id);
            })
          // })
   
          this.candidateHistoryData = el;
        }
      },
      (error) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this.utilService.showError(error.error.errors.failed[0]);
          this.dataSource = false;
    }})
    }
  
    public getAllCandidateHistoryData() {
      this.candidateSerivce.getCandidateHistoryById(this.candidateId).subscribe((res: any) => {
        res.data.forEach((element: any) => {
          element.application_created_at = element.application_created_at ? moment.utc(element.created_at).local().format('DD-MM-YYYY HH:mm A') : '';
            element.application_statges.forEach((val: any) => {
              val.created_at = val.created_at ? moment.utc(val.created_at).local().format('DD-MM-YYYY HH:mm A') : '';
              val.scheduled_date = val.scheduled_date ? moment.utc(val.scheduled_date).local().format('DD-MM-YYYY hh:mm A') : '';
            });
        });
        this.candidateApplicationDetails = res.data;
      })
    }
  
    public openPDFIMGModal(candidateDetails: any) {
      const dialogRef = this.dialog.open(ImgPdfViewerModalComponent, {
        width: '65vw',
        height: '80vh',
        data: candidateDetails
      });
  
      dialogRef.afterClosed().subscribe((confirmed: boolean) => {
          // this.getAllCandidateData();
      });
    }
  
    public  openCommentModal(candidateDetails: any) {
      candidateDetails.ApplicationNo = `(Application ${(this.candidateApplicationDetails.length)})`;
      const dialogRef = this.dialog.open(CandidateCommentComponent, {
        width: '65vw',
        data: candidateDetails
      });
  
      dialogRef.afterClosed().subscribe((confirmed: boolean) => {
          this.getAllGeneralCandidateHistoryData();
          this.getAllCandidateHistoryData()
          
      });
    }
  
    public openAddEditCandidateModal(candidateDetails: any) {
      let model = candidateDetails;
      const dialogRef = this.dialog.open(AddEditCandidateComponent, {
        autoFocus: false,
        width: '65vw',
        data: {
          title: candidateDetails ? 'Edit Candidate' : 'Add Candidate',
          msg: '',
          mode: candidateDetails ? 'Update' : 'Save',
          btnName: candidateDetails ? 'Update' : 'Save',
          model: model,
        }
      });
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          this.getAllGeneralCandidateHistoryData()
          this.getAllCandidateHistoryData()
        }
      });
    }
  
  public goBack(){
    this.utilService.goBack()
    
  }

}
