import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CandidatesRoutingModule } from './candidates-routing.module';
import { CandidatesComponent } from './candidates.component';
import { SharedModule } from 'src/app/shared';
import { CandidateHistoryComponent } from './candidate-history/candidate-history.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

@NgModule({
  declarations: [
    CandidatesComponent,
    CandidateHistoryComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    CandidatesRoutingModule,
    NgMultiSelectDropDownModule
  ]
})
export class CandidatesModule { }
