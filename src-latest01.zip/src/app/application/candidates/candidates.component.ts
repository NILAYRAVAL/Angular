import {
  AfterViewInit,
  Component,
  ElementRef,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddEditCandidateComponent } from 'src/app/shared/component/add-edit-candidate/add-edit-candidate.component';
import { GlobalVariableService } from 'src/app/shared/Services/global-variable.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { AlertDialogComponent } from 'src/app/shared/component/alert-dialog/alert-dialog.component';
import { CandidateService } from 'src/app/shared/Services/components-services /candidate.service';
import * as moment from 'moment';
import { CandidateCommentComponent } from 'src/app/shared/component/candidate-comment/candidate-comment.component';
import { ActivatedRoute, Router } from '@angular/router';
import { MatPaginator } from '@angular/material/paginator';
import { Location } from '@angular/common';
import { ImgPdfViewerModalComponent } from 'src/app/shared/component/img-pdf-viewer-modal/img-pdf-viewer-modal.component';
import { FormControl, FormGroup } from '@angular/forms';
import { debounceTime, switchMap } from 'rxjs';
// SkillList ............................
import { MatSelect } from '@angular/material/select';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
const ELEMENT_DATA: any = [];

@Component({
  selector: 'app-candidates',
  templateUrl: './candidates.component.html',
  styleUrls: ['./candidates.component.css'],
})
export class CandidatesComponent implements OnInit, AfterViewInit {
  public searchControl!: FormControl;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  public stagesArray: Array<any> = [];

  public isLoading: boolean = false;

  public total: number = 0;
  public currentPage: number = 0;
  public pageSize: number = 10;
  public pageSizeOptions: number[] = [10, 25, 50, 100];

  public searchText: string = '';
  public displayedColumns: string[] = [
    'id',
    'name',
    'position',
    'email',
    'showExperienceData',
    'mobile',
    'stage',
    'status',
    'action',
    // 'skill_id'
  ];
  public candidate_status: any = '';

  public dataSource: any = ELEMENT_DATA;
  public filterValue: any = {};
  public sendCandidateStages: any = '0';
  // ................................................SkillList..................................................................
  public skillList: any = [];
  // public skillListData: any = [];
  public selectedSkillIds: number[] = [];

  // public filterVal : any ; 

  // ................................................SkillList End..................................................................

  dropdownSettings: any;
 
  constructor(
    public matDialog: MatDialog,
    private dialog: MatDialog,
    public globalService: GlobalVariableService,
    private CandidateSerivce: CandidateService,
    private _utilService: UtilService,
    public router: Router,
    private activeRoute: ActivatedRoute,
    public location: Location
  ) {
    // ........................................   create dropdown for skills[]   ........................................................................................
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'skill_id',
      textField: 'skill_name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 2,
      allowSearchFilter: true,
    };
  }

  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params: any) => {
      this.filterValue = {
        order_by: 'person_id',

        sort_by: 'DESC',
      };
      let pageNumber = params['page'] ? parseInt(params['page']) : 0;
      this.searchText = params['search'] ? params['search'] : undefined;
      // console.log("this.searchText", this.searchControl);
      this.getAllCandidateData(
        pageNumber,
        10,
        'DESC',
        'person_id',
        this.searchText,
        this.filterValue
      );
    });
    this.searchFilter();
    this.getStageList();
    this.getSkills();
  }
  // ................................................SkillList..................................................................

  getSkills() {
    let Param = {
      order_by: 'skill_id',
      sort_by: 'DESC',
    };
    this.CandidateSerivce.getSkillList(Param).subscribe((response: any) => {
      this.skillList = response.data;
      console.log('SKILL LIST', this.skillList);
    });
  }

  // ................................................SkillList..................................................................

  public searchFilter() {
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
      .pipe(
        debounceTime(1000),
        switchMap((searchTerm: any) => {
          //Make Api call herecons
          this.searchText = searchTerm;
          this.getCandidateBySearch();
          return searchTerm;
        })
      )
      .subscribe((result) => {});
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;   
  }
  public appendURLParameters() {
    let mergedString: string = '';
    mergedString += '?page=' + this.filterValue.page_no;

    if (
      this.filterValue.search &&
      this.filterValue.search !== null &&
      this.filterValue.search !== ''
    ) {
      // mergedString += '&search=' + this.filterValue.search;
    }
    this.location.replaceState('/application/candidates' + mergedString);
  }

  public pageChangedCommon($event: any) {
    let pageNo = $event.pageIndex;
    let perPage = $event.pageSize;
    this.filterValue.page_no = pageNo;
    this.getAllCandidateData(pageNo, perPage);
  }

  public getCandidateBySearch() {
    if (this.searchText.length > 0) {
      this.getAllCandidateData(
        0,
        10,
        'DESC',
        'person_id',
        this.searchText,
        this.filterValue
      );
    }
    if (!this.searchText.length) {
      this.getAllCandidateData(
        0,
        10,
        'DESC',
        'person_id',
        '',
        this.filterValue
      );
    }
  }

  public getStageList() {
    let stagesParam = {
      order_by: 'display_order',
      sort_by: 'ASC',
    };
    this.CandidateSerivce.getStages(stagesParam).subscribe((res: any) => {
      // console.log('stagesssssssss',res.data);
      this.stagesArray = res.data;
    });
  }
  //  ..............................  SkillList .......................................................
  public selectionChanged(event: any) {
    // console.log(event,'status---');
    if (event) {
      this.sendCandidateStages = event;
      this.getAllCandidateData(
        0,
        10,
        'DESC',
        'skill_id',
        this.searchText,
        this.filterValue
      );
    } else if (event == 0) {
      this.sendCandidateStages = 0;
      this.getAllCandidateData(
        0,
        10,
        'DESC',
        'skill_id',
        this.searchText,
        this.filterValue
      );
    }
  }
  //  ..............................  SkillList End .......................................................

  public selectCandidateStatus(event: any) {
    // console.log(event,'status---');
    if (event) {
      this.sendCandidateStages = event;
      this.getAllCandidateData(
        0,
        10,
        'DESC',
        'person_id',
        this.searchText,
        this.filterValue
      );
    } else if (event == 0) {
      this.sendCandidateStages = 0;
      this.getAllCandidateData(
        0,
        10,
        'DESC',
        'person_id',
        this.searchText,
        this.filterValue
      );
    }
  }
  public getAllCandidateData(
    pageNo: number = this.currentPage,
    perPage: number = 10,
    sort_by: string = 'DESC',
    order_by: string = 'person_id',
    search?: string,
    filters: any = {},
    skill_id: any[] = [],
    type?: string
  ) {
    // this.isProjectFolderLoading = true;
    this.isLoading = true;
    this.filterValue.per_page = perPage;
    this.filterValue.stage_id = this.sendCandidateStages;
    this.filterValue.page_no = pageNo;
    this.filterValue.sort_by = sort_by;
    this.filterValue.order_by = order_by;
   this.filterValue.skill_id=this.selectedSkillIds;
    // debugger
    // if(this.selectedSkillIds){
    //   this.selectedSkillIds.forEach((ele,ind) => {
    //     this.filterValue['skill_id[]'] = ele
    //   });
    // }
    // this.filterValue.skill_id = this.selectedSkillIds;
    // this.filterValue['skill_id[]'] = 3;
    if (search) {
      this.filterValue.search = search;
      console.log(search);
      // this.searchControl.setValue(search)
    } else {
      delete this.filterValue.search;
    }
    if (Object.keys(filters).length) {
      Object.keys(filters).map((key: string) => {
        if (filters[key]) {
          this.filterValue[key] = filters[key];
        }
      });
    }
    this.appendURLParameters();
    // let filterCopyObj = _.cloneDeep(this.filterValue);
    let filterCopyObj = this.filterValue;
    filterCopyObj.page_no++;
    console.log("COPY OBJ PARAMS",filterCopyObj);
    console.log("filterCopyObj",filterCopyObj);
    // return
    // debugger
    // if(this.selectedSkillIds){
    //   this.selectedSkillIds.forEach((ele,ind) => {
    //     this.filterValue['skill_id[]'] = ele,ind
    //   });
    // }
    if (this.selectedSkillIds) {
      this.selectedSkillIds.forEach((ele, ind) => {
        const skillObj = {
          skill_id: ele as number
        };
        skillObj['index'] = ind;
        console.log(skillObj);
      });
    }
    // ........................................................
    this.CandidateSerivce.getCandidateLists(filterCopyObj).subscribe(
      (res: any) => {
        this.dataSource = res.data;
        this.total = res.with.total;
        this.currentPage = pageNo;
        this.isLoading = false;
        //  console.log("lopp of personnnnnnnnnnnnnnnnn",res.data.person_skills);
        this.dataSource.forEach((el: any) => {
          let getYear = (el.month_experience / 12).toFixed(2);
          let years = getYear.toString().split('.')[0];
          let Months: any = parseInt(getYear.toString().split('.')[1]);
          Months = Months > 9 ? (Months / 100) * 12 : (Months / 10) * 12;
          Months = Math.round(Months);
          el.year_experience = parseInt(years);
          el.months_experience = Months;

          if (el.month_experience >= 12) {
            el.showExperienceData =
              el.year_experience + '.' + el.months_experience + ' Years';
          }

          if (el.month_experience < 12) {
            el.showExperienceData = el.months_experience + ' Months';
          }

          el.id = el.application_id;
          el.position_id = el.last_application?.position_id;
          el.name = el.name;
          el.mobile = el.phone;
          el.current_ctc = el.last_application?.current_ctc;
          el.expected_ctc = el.last_application?.expected_ctc;
          el.notice_period = el.last_application?.notice_period;
          el.source = el.last_application?.source;
          el.supplier_id = el.last_application?.supplier_id;
          el.reference_by = el.last_application?.reference_by;
          let skills_aryStr = '';
          el.person_skills.forEach((el: any) => {
            skills_aryStr += ', ' + el.skill_name;
          });
          el.skills_ary = skills_aryStr.split(', ').splice(1);
          el.position = el.position?.technology?.technology_name;

          let qualifiactionList = '';
          el.person_qualification.forEach((el: any) => {
            qualifiactionList += ', ' + el.qualification_name;
          });
          el.qualifiactions = qualifiactionList.slice(1);

          el.email = el.email;
          el.stageObj = el.stage;
          el.statusObj = el.status;
          el.stage = el.stage?.stage_name;
          el.status = el.status?.status_name;
          el.person_experience.forEach((el: any) => {
            el.company_name = el.company?.company_name;
            el.company_id = el.company?.company_id;
            el.isChecked = el.to_due ? false : true;
            el.start_month = moment(el.from_due).format('MM');
            el.start_year = moment(el.from_due).format('yyyy');
            el.end_month = el.to_due ? moment(el.to_due).format('MM') : '';
            el.end_year = el.to_due ? moment(el.to_due).format('yyyy') : '';
          });
        });

        this.dataSource.forEach((el: any) => {
          el.qualificationsIds = [];
          el.person_qualification.map((qualification: any) => {
            el.qualificationsIds.push(qualification.qualification_id);
          });
        });
        this.dataSource.forEach((el: any) => {
          el.skillIds = [];
          el.person_skills.map((skills_id: any) => {
            el.skillIds.push(skills_id.skill_id);
          });
        });
      },
      (error) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
          this.dataSource = false;
          this.isLoading = false;
        }
      }
    );
  }

  public openAddEditCandidateModal($event: any) {
    let model = $event ? $event : this.globalService.candidateData;
    const dialogRef = this.matDialog.open(AddEditCandidateComponent, {
      autoFocus: false,
      width: '65vw',
      data: {
        title: $event ? 'Edit Candidate' : 'Add Candidate',
        msg: '',
        mode: $event ? 'Update' : 'add_candidate',
        btnName: $event ? 'Update' : 'Save',
        model: model,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getAllCandidateData();
      }
    });
  }

  public openCommentModal(candidateDetails: any) {
    const dialogRef = this.dialog.open(CandidateCommentComponent, {
      width: '65vw',
      data: candidateDetails,
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      this.getAllCandidateData();
    });
  }

  public openPDFIMGModal(candidateDetails: any) {
    const dialogRef = this.dialog.open(ImgPdfViewerModalComponent, {
      width: '65vw',
      height: '80vh',
      data: candidateDetails,
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      // this.getAllCandidateData();
    });
  }

  // conformation dialog //
  public conformationDialog(id?: any) {
    const dialogRef = this.dialog.open(AlertDialogComponent, {
      width: '500px',
      data: {
        message: 'Are you sure want to delete this candidate data?',
        buttonText: {
          ok: 'Delete',
          cancel: 'Cancel',
        },
      },
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.CandidateSerivce.deleteCandidate(id).subscribe((res: any) => {
          this._utilService.showSuccess(
            'Candidate Deleted Successful',
            'Success'
          );
          this.getAllCandidateData();
        });
      }
    });
  }

  public redirectToDetailPage(id: any) {
    this.router.navigate([`/application/candidates/candidate-history/id`], {
      queryParams: { candidate_id: id, isBack: true },
    });
  }

  // const selectedItems  = e;
  // if (e.length) {
    //   this.selectedSkillIds = e.map((item:any) => item.skill_id);
    //   console.log('onItemSelect', this.selectedSkillIds);
    // }
    onItemSelect(e: any) {
    if (Array.isArray(e)) {
      this.selectedSkillIds = e.map((item: any) => item.skill_id);
      if(this.selectedSkillIds){
        this.selectedSkillIds.forEach((ele,ind) => {
          this.filterValue['skill_id[]'] = ele,ind
        });
      }
      console.log('onItemSelect', this.selectedSkillIds);
    } else {
      const skillId = e.skill_id;
      if (!this.selectedSkillIds.includes(skillId)) {
        this.selectedSkillIds.push(skillId);
      }
      console.log('onItemSelect', this.selectedSkillIds);
    }
    this.getAllCandidateData()
    // console.log('index',index);
  }  
  // console.log("selected opt",e);
  //   for (var key in e) {
    //     if (e.hasOwnProperty(key)) {
      //       console.log('if condition for single selecteddddddddddddddddddddddd',key);
      //       this.skillListData.push(key);
      //   }
      // }
      // console.log(
        //   "ids",e.skill_id
        //   );
        //   this.skillListData.push(e.skill_id);
    // const skillsss= e.map((res:any)=>res.skill_id)
    // console.log('latesttttttttttttttttttttt',skillsss);

    // e.forEach((element:any) => {
    //   this.skillListData.push(element.skill_id);
    // });
  //  e.forEach((element?: any) => {
  //     this.skillListData.push(element?.skill_id);
  //   });
// console.log("sdasdsadasdasdasdssssssssssssssssssssssssssssssssssssssssss",banana);
// console.log("slslslsllslslsllslss",this.skillListData);


  onSelectAll(e: any) {
    if (e.length) {
      this.selectedSkillIds = e.map((item:any) => item.skill_id);
      console.log('onSelectAll', this.selectedSkillIds);
    } else {
      this.selectedSkillIds = [];
      console.log('onSelectAlllllllllllll', this.selectedSkillIds)
    }
    // this.getAllCandidateData
    // console.log("slected all",e);
    //   for (var id in e) {
    //     if (e.hasOwnProperty(id)) {
    //       console.log('if conditionnnnnnnnnnnnnnnnnnnnnnnnn',id);
    //       this.skillListData.push(id);
    //   }
    // }
    //   const skillIds = e.map((item: { skill_id: any; }) => item.skill_id);
    // console.log("all accesssssssssssssssss",skillIds);
    // let selectedSkillId:e.map(res=>res.skill_id)
    // this.skillListData.push(selectedSkillId)
    // e.forEach(res =>{selectedSkillId.push(res.skill_id);
    // });
    // this.skillListData = [...this.skillListData, ...selectedSkillId];
    
  }
  onItemDeSelect(e: any) {
    if (Array.isArray(e)) {
      const deSelectedSkillIds = e.map((item: any) => item.skill_id);
      this.selectedSkillIds = this.selectedSkillIds.filter(
        id => !deSelectedSkillIds.includes(id)
      );
      console.log('onItemDeSelect', this.selectedSkillIds);
    } else {
      const skillId = e.skill_id;
      const index = this.selectedSkillIds.findIndex(
        id => id === skillId
      );
      if (index >= 0) {
        this.selectedSkillIds.splice(index, 1);
      }
      console.log('onItemDeSelect', this.selectedSkillIds);
      
    }
    // this.getAllCandidateData
  }  
    // if (e.skill_id === this.skillListData.id) {
      // return 
        // e.skill_id
      //   console.log('delete selectedddddddddddd', e.skill_id);
      // }
  
  onItemDeSelectAll(e: any) {
    this.selectedSkillIds = [];
    console.log('onDeSelectAllllllllllllllll', this.selectedSkillIds);
  }
}
