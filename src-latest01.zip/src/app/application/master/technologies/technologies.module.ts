import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared';
import { TechnologieListComponent } from './technologie-list/technologie-list.component';
import { TechnologieRoutingModule } from './technologies-routing.module';


@NgModule({
  declarations: [
    TechnologieListComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    TechnologieRoutingModule
  ]
})
export class TechnologieModule { }
