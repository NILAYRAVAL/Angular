import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, switchMap } from 'rxjs';
import { AddEditSkillComponent } from 'src/app/shared/component/add-edit-skill/add-edit-skill.component';
import { AlertDialogComponent } from 'src/app/shared/component/alert-dialog/alert-dialog.component';
import { CommonServiceService } from 'src/app/shared/Services/common-service.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { Location } from '@angular/common';
import { TechnologiesService } from 'src/app/shared/Services/components-services /technologies.service';
import { AddEditTechnologyComponent } from 'src/app/shared/component/add-edit-technology/add-edit-technology.component';

@Component({
  selector: 'app-technologie-list',
  templateUrl: './technologie-list.component.html',
  styleUrls: ['./technologie-list.component.scss']
})
export class TechnologieListComponent implements OnInit {
public searchControl!: FormControl;
public isLoading: boolean = false;
  
public total: number = 0;
public currentPage: number = 0;
public pageSize :number = 10;
public pageSizeOptions: number[] = [10, 25, 50, 100];

public filterValue: any = {};
public allTechnologiesData: any = [];

public searchText: string = '';
public displayedColumns: string[] = ['id', 'technology_name', 'action'];

  constructor(
     public commonService : CommonServiceService,
     private _utilService : UtilService,
     private dialog: MatDialog,
     private activeRoute: ActivatedRoute,
     public location: Location,
     public technologiesService: TechnologiesService,
     public router : Router
  ) { }

  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params: any) => {
      this.filterValue = {
          order_by: 'technology_id',
          sort_by: 'ASC',
      }

      let pageNumber = params['page'] ? parseInt(params['page']) : 0;
      this.searchText = params['search'] ? params['search'] : undefined;
      this.getAllTechnologiesData(pageNumber, 10, 'ASC', 'technology_id', this.searchText, this.filterValue);
    });
    this.searchFilter()
    // this.getAllTechnologiesData()
  }

  public searchFilter(){
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
    .pipe(
      debounceTime(1000),
      switchMap((searchTerm: any) => {
        //Make Api call herecons
        this.searchText = searchTerm
        this.getTechnologiesBySearch()
        return searchTerm; 
      })
    ).subscribe(result => {
     
    });
  }

   public appendURLParameters() {
     let mergedString: string = '';
     mergedString += '?page=' + this.filterValue.page_no;
 
     if (this.filterValue.search && this.filterValue.search !== null && this.filterValue.search !== '') {
        //  mergedString += '&search=' + this.filterValue.search;
     }
     this.location.replaceState('/application/master/technologies' + mergedString);
 }

 public getTechnologiesBySearch() {
  if(this.searchText.length > 0) {
    this.getAllTechnologiesData(0, 10, 'ASC', 'technology_id', this.searchText, this.filterValue);
  }
  if(!this.searchText.length) {
    this.getAllTechnologiesData(0, 10, 'ASC', 'technology_id', '', this.filterValue);
  }

}

public pageChangedCommon($event: any) {
  let pageNo = ($event.pageIndex);
  let perPage = $event.pageSize;
  this.filterValue.page_no = pageNo;
  this.getAllTechnologiesData(pageNo, perPage);
}

  public getAllTechnologiesData(pageNo: number = this.currentPage, perPage: number = 10,  sort_by: string = 'ASC',
  order_by: string = 'technology_id', search?: string, filters: any = {}, type?: string){
    this.isLoading = true;
    this.filterValue.per_page = perPage;
    this.filterValue.page_no = pageNo;
    this.filterValue.sort_by = sort_by;
    this.filterValue.order_by = order_by;
    if (search) {
        this.filterValue.search = search;
    } else {
        delete this.filterValue.search;
    }
    if (Object.keys(filters).length) {
        Object.keys(filters).map((key: string) => {
            if (filters[key]) {
                this.filterValue[key] = filters[key];
            }
        })
    }
    this.appendURLParameters();
    // let filterCopyObj = _.cloneDeep(this.filterValue);
    let filterCopyObj = this.filterValue;
    filterCopyObj.page_no++;

    this.technologiesService.geTechnologyList(filterCopyObj).subscribe((res:any)=>{
      this.total = res.with.total;
      this.currentPage = pageNo;
      this.allTechnologiesData = res.data;
      this.isLoading = false;
    },
    (error: any) => {
      if (error && error.error.errors && error.error.errors.failed) {
        this._utilService.showError(error.error.errors.failed[0]);
        this.allTechnologiesData = false;
        this.isLoading = false;
     
  }})
  }

  public openAddEditTechnologiesModal(data: any) { 
    let model = data ? data : null
    const dialogRef = this.dialog.open(AddEditTechnologyComponent, {
      autoFocus: false,
      width: '20vw',
      data: {
        title: data ? 'Edit Technology' : 'Add Technology',
        msg: '',
        btnName: data ? 'Update' : 'Save',
        model: model,
      }
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      if (result) {
        this.getAllTechnologiesData();
      }
    });
  }

  conformationDialog(id:any) {
    const dialogRef = this.dialog.open(AlertDialogComponent,{
      maxWidth:'400px',
      data:{
        message: 'Are you sure want to delete this Technology?',
        buttonText: {
          ok: 'Delete',
          cancel: 'Cancel'
        }
      }
    });
     
    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.technologiesService.deleteTechnology(id).subscribe((res:any)=>{
          this.getAllTechnologiesData()
          this._utilService.showSuccess('Technology Deleted successful!','Success')
        })
      }
    });
  }

}
