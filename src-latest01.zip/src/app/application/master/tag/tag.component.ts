import { Component, OnInit } from '@angular/core';
import { ElementRef, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
/***************************************************************************** */

import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, switchMap } from 'rxjs';
// import { AlertDialogComponent } from 'src/app/shared/component/alert-dialog/alert-dialog.component';
import { CommonServiceService } from 'src/app/shared/Services/common-service.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { Location } from '@angular/common';
import { TagService } from 'src/app/shared/Services/components-services /tag.service';

export interface PeriodicElement {
  
  // email: string;
  tag_id: number;
  tag_name: string;
  is_active: number;
}
@Component({
  selector: 'app-tag',
  templateUrl: './tag.component.html',
  styleUrls: ['./tag.component.scss'],
})
export class TagComponent implements OnInit {
/****************************************************************** */
  separatorKeysCodes: number[] = [ENTER, COMMA];
  fruitCtrl = new FormControl('');
  filteredFruits: Observable<string[]>;
  fruits: string[] = ['Lemon'];
  allFruits: string[] = ['Apple', 'Lemon', 'Lime', 'Orange', 'Strawberry'];
  
  @ViewChild('fruitInput')
  fruitInput!: ElementRef<HTMLInputElement>;
  /******************************************************************* */
  public searchControl!: FormControl;
  public isLoading: boolean = false;

  public total: number = 0;
  public currentPage: number = 0;
  public pageSize: number = 10;
  public pageSizeOptions: number[] = [10, 25, 50, 100];

  public filterValue: any = {};
  public allUsersData: any = [];

  public searchText: string = '';
  public displayedColumns: string[] = ['tag_id', 'tag_name', 'is_active'];

  constructor(
    public commonService: CommonServiceService,
    private _utilService: UtilService,
    private dialog: MatDialog,
    private activeRoute: ActivatedRoute,
    public location: Location,
    public router: Router,
    
    public tagService: TagService,
    ) {
    this.filteredFruits = this.fruitCtrl.valueChanges.pipe(
      startWith(null),
      map((fruit: string | null) =>
        fruit ? this._filter(fruit) : this.allFruits.slice()
      )
    );
  }
 /*************************************************************************** */
  add(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();

    // Add our fruit
    if (value) {
      this.fruits.push(value);
    }

    // Clear the input value
    event.chipInput!.clear();

    this.fruitCtrl.setValue(null);
  }

  remove(fruit: string): void {
    const index = this.fruits.indexOf(fruit);

    if (index >= 0) {
      this.fruits.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.fruits.push(event.option.viewValue);
    this.fruitInput.nativeElement.value = '';
    this.fruitCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allFruits.filter((fruit) =>
      fruit.toLowerCase().includes(filterValue)
    );
  }

 /*************************************************************************** */
  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params: any) => {
      this.filterValue = {
        order_by: 'tag_id',
        sort_by: 'DESC',
      };

      let pageNumber = params['page'] ? parseInt(params['page']) : 0;
      this.searchText = params['search'] ? params['search'] : undefined;
      this.getAllUserData(
        pageNumber,
        10,
        'DESC',
        'tag_id',
        this.searchText,
        this.filterValue
      );
    });
    this.searchFilter();
  }

  public searchFilter() {
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
      .pipe(
        debounceTime(1000),
        switchMap((searchTerm: any) => {
          //Make Api call herecons
          this.searchText = searchTerm;
          this.getUsersBySearch();
          return searchTerm;
        })
      )
      .subscribe((result) => {});
  }

  public appendURLParameters() {
    let mergedString: string = '';
    mergedString += '?page=' + this.filterValue.page_no;

    if (
      this.filterValue.search &&
      this.filterValue.search !== null &&
      this.filterValue.search !== ''
    ) {
      //  mergedString += '&search=' + this.filterValue.search;
    }
    this.location.replaceState('/application/master/tag' + mergedString);
  }

  public getUsersBySearch() {
    if (this.searchText.length > 0) {
      this.getAllUserData(
        0,
        10,
        'DESC',
        'tag_id',
        this.searchText,
        this.filterValue
      );
    }
    if (!this.searchText.length) {
      this.getAllUserData(0, 10, 'DESC', 'tag_id', '', this.filterValue);
    }
  }

  public pageChangedCommon($event: any) {
    let pageNo = $event.pageIndex;
    let perPage = $event.pageSize;
    this.filterValue.page_no = pageNo;
    this.getAllUserData(pageNo, perPage);
  }

  public getAllUserData(
    pageNo: number = this.currentPage,
    perPage: number = 10,
    sort_by: string = 'DESC',
    order_by: string = 'tag_id',
    search?: string,
    filters: any = {},
    type?: string
  ) {
    this.isLoading = true;
    this.filterValue.per_page = perPage;
    this.filterValue.page_no = pageNo;
    this.filterValue.sort_by = sort_by;
    this.filterValue.order_by = order_by;
    if (search) {
      this.filterValue.search = search;
    } else {
      delete this.filterValue.search;
    }
    if (Object.keys(filters).length) {
      Object.keys(filters).map((key: string) => {
        if (filters[key]) {
          this.filterValue[key] = filters[key];
        }
      });
    }
    this.appendURLParameters();
    // let filterCopyObj = _.cloneDeep(this.filterValue);
    let filterCopyObj = this.filterValue;
    filterCopyObj.page_no++;

    this.tagService.getTagList(filterCopyObj).subscribe(
      (res: any) => {
        this.total = res.with.total;
        this.currentPage = pageNo;
        this.allUsersData = res.data;
        // get data from services display in table
        console.log(this.allUsersData);
        this.isLoading = false;
      },
      (error: any) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
          this.allUsersData = false;
          this.isLoading = false;
        }
      }
    );
  }

  // public openAddEditUsersModal(data: any) {
  //   let model = data ? data : null;

  //   const dialogRef = this.dialog.open(AddEditUserComponent, {
  //     autoFocus: false,
  //     width: '25vw',
  //     data: {
  //       title: data ? 'Edit User' : 'Add User',
  //       msg: '',
  //       btnName: data ? 'Update' : 'Save',
  //       model: model,
  //     },
  //   });
  //   dialogRef.afterClosed().subscribe((result: any) => {
  //     console.log(result);
  //     if (result) {
  //       this.getAllUserData();
  //     }
  //   });
  // }

  // conformationDialog(id: any) {
  //   const dialogRef = this.dialog.open(AlertDialogComponent, {
  //     maxWidth: '400px',
  //     data: {
  //       message: 'Are you sure want to delete this User?',
  //       buttonText: {
  //         ok: 'Delete',
  //         cancel: 'Cancel',
  //       },
  //     },
  //   });

    // dialogRef.afterClosed().subscribe((confirmed: boolean) => {
    //   if (confirmed) {
    //     this.tagService.deleteUsers(id).subscribe((res: any) => {
    //       this.getAllUserData();
    //       this._utilService.showSuccess('User Deleted successful!', 'Success');
    //     });
    //   }
    //   else{
    //     "not workiiiiiiiiiiiiiiiiiiiiiing "
    //   }
    // });
  // }

}
