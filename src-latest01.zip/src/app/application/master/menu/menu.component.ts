import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, switchMap } from 'rxjs';
import { AlertDialogComponent } from 'src/app/shared/component/alert-dialog/alert-dialog.component';
import { CommonServiceService } from 'src/app/shared/Services/common-service.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { Location } from '@angular/common';
import { AddEditUserComponent } from 'src/app/shared/component/add-edit-user/add-edit-user.component';
import { MenuService } from 'src/app/shared/Services/components-services /menu.service';
import { AddEditMenuComponent } from 'src/app/shared/component/add-edit-menu/add-edit-menu.component';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { MatTableDataSource } from '@angular/material/table';

export interface PeriodicElement {
  menu_id: number;
  menu_name: string;
  menu_code: string;
  display_order: number;
  children_menu: child_menu[];
  status: boolean;
  secondary: any;
}
interface child_menu {
  menu_id: number;
  menu_name: string;
  menu_code: string;
  permissions: menu_access[];
}
interface menu_access {
  permission_name: string;
}
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class MenuComponent implements OnInit {
  [x: string]: any;
  public searchControl!: FormControl;
  public isLoading: boolean = false;

  public total: number = 0;
  public currentPage: number = 0;
  public pageSize: number = 10;
  public pageSizeOptions: number[] = [10, 25, 50, 100];

  public filterValue: any = {};
  public allMenuData: any = [];

  public searchText: string = '';
  currentRowSelected: any;

  displayedColumns = [
    'children_menu',
    'menu_id',
    'menu_name',
    'display_order',
    'status',
    'action',
  ];
//   dataSource = 
//   [
//     {
//         "menu_id": 1,
//         "menu_name": "Permission",
//         "menu_code": "PERMISSION",
//         "parent_id": 0,
//         "url": null,
//         "icon_css_class": null,
//         "display_order": 1,
//         "is_active": 1,
//         "children_menu": []
//     },
//     {
//         "menu_id": 2,
//         "menu_name": "Role",
//         "menu_code": "ROLE",
//         "parent_id": 0,
//         "url": null,
//         "icon_css_class": null,
//         "display_order": 2,
//         "is_active": 1,
//         "children_menu": []
//     },
//     {
//         "menu_id": 3,
//         "menu_name": "User",
//         "menu_code": "USER",
//         "parent_id": 0,
//         "url": null,
//         "icon_css_class": null,
//         "display_order": 3,
//         "is_active": 1,
//         "children_menu": []
//     },
//     {
//         "menu_id": 4,
//         "menu_name": "Position",
//         "menu_code": "POSITION",
//         "parent_id": 0,
//         "url": null,
//         "icon_css_class": null,
//         "display_order": 4,
//         "is_active": 1,
//         "children_menu": []
//     },
//     {
//         "menu_id": 5,
//         "menu_name": "Candidate",
//         "menu_code": "CANDIDATE",
//         "parent_id": 0,
//         "url": null,
//         "icon_css_class": null,
//         "display_order": 5,
//         "is_active": 1,
//         "children_menu": [
//             {
//                 "menu_id": 7,
//                 "menu_name": "child_menu_for_menu5.1",
//                 "menu_code": "CHILD_MENU_FOR_MENU5.1",
//                 "parent_id": 5,
//                 "url": "#",
//                 "icon_css_class": null,
//                 "display_order": 2,
//                 "is_active": 1,
//                 "permissions": [
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     }
//                 ],
//                 "children_menu": []
//             },
//             {
//                 "menu_id": 8,
//                 "menu_name": "child_menu_for_menu5.1",
//                 "menu_code": "CHILD_MENU_FOR_MENU5.1",
//                 "parent_id": 5,
//                 "url": "#",
//                 "icon_css_class": null,
//                 "display_order": 3,
//                 "is_active": 1,
//                 "permissions": [],
//                 "children_menu": []
//             },
//             {
//                 "menu_id": 6,
//                 "menu_name": "child_menu_for_menu5",
//                 "menu_code": "CHILD_MENU_FOR_MENU5",
//                 "parent_id": 5,
//                 "url": "#",
//                 "icon_css_class": null,
//                 "display_order": 4,
//                 "is_active": 1,
//                 "permissions": [
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 1,
//                         "permission_name": "Access",
//                         "permission_slug": "ACCESS",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 2,
//                         "permission_name": "Create",
//                         "permission_slug": "CREATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 3,
//                         "permission_name": "Update",
//                         "permission_slug": "UPDATE",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     },
//                     {
//                         "permission_id": 4,
//                         "permission_name": "View",
//                         "permission_slug": "VIEW",
//                         "is_active": 1
//                     }
//                 ],
//                 "children_menu": []
//             }
//         ]
//     },
//     {
//         "menu_id": 6,
//         "menu_name": "child_menu_for_menu5",
//         "menu_code": "CHILD_MENU_FOR_MENU5",
//         "parent_id": 5,
//         "url": "#",
//         "icon_css_class": null,
//         "display_order": 4,
//         "is_active": 1,
//         "children_menu": []
//     },
//     {
//         "menu_id": 7,
//         "menu_name": "child_menu_for_menu5.1",
//         "menu_code": "CHILD_MENU_FOR_MENU5.1",
//         "parent_id": 5,
//         "url": "#",
//         "icon_css_class": null,
//         "display_order": 2,
//         "is_active": 1,
//         "children_menu": []
//     },
//     {
//         "menu_id": 8,
//         "menu_name": "child_menu_for_menu5.1",
//         "menu_code": "CHILD_MENU_FOR_MENU5.1",
//         "parent_id": 5,
//         "url": "#",
//         "icon_css_class": null,
//         "display_order": 3,
//         "is_active": 1,
//         "children_menu": []
//     },
//     {
//         "menu_id": 9,
//         "menu_name": "child_menu_for_menu5.1",
//         "menu_code": "CHILD_MENU_FOR_MENU5.1",
//         "parent_id": 5,
//         "url": "#",
//         "icon_css_class": null,
//         "display_order": 4,
//         "is_active": 0,
//         "children_menu": []
//     }
// ]

  constructor(
    public commonService: CommonServiceService,
    private _utilService: UtilService,
    private dialog: MatDialog,
    private activeRoute: ActivatedRoute,
    public location: Location,
    public _menuService: MenuService,

    public router: Router
  ) {
   
  }

  onClickIconExpand(row:any){
    console.log("cliked on icon",row);
    if( row.children_menu.length){
      if (this.currentRowSelected && this.currentRowSelected != row)
        this.currentRowSelected.isExpanded = false;
      this.currentRowSelected = row;
  
      if (row.isExpanded) {
        row.isExpanded = false;
      } else {
        row.isExpanded = true;
      }
    }
    console.log(this.displayedColumns.length , 'column lengthhhhhhhhhhhhhhhhhh');
    console.log(this.displayedColumns,'displayyyyyyyyyyyyyyyy');
  }

  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params: any) => {
      this.filterValue = {
        order_by: 'menu_id',
        sort_by: 'ASC',
      };

      let pageNumber = params['page'] ? parseInt(params['page']) : 0;
      this.searchText = params['search'] ? params['search'] : undefined;
      this.getAllMenuData(
        pageNumber,
        10,
        'ASC',
        'menu_id',
        this.searchText,
        this.filterValue
      );
    });
    this.searchFilter();
  }
  
  public searchFilter() {
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
      .pipe(
        debounceTime(1000),
        switchMap((searchTerm: any) => {
          //Make Api call herecons
          this.searchText = searchTerm;
          this.getUsersBySearch();
          return searchTerm;
        })
      )
      .subscribe((result) => {});
  }

  public appendURLParameters() {
    let mergedString: string = '';
    mergedString += '?page=' + this.filterValue.page_no;

    if (
      this.filterValue.search &&
      this.filterValue.search !== null &&
      this.filterValue.search !== ''
    ) {
      //  mergedString += '&search=' + this.filterValue.search;
    }
    this.location.replaceState('/application/master/menu' + mergedString);
  }

  public getUsersBySearch() {
    if (this.searchText.length > 0) {
      this.getAllMenuData(
        0,
        10,
        'ASC',
        'menu_id',
        this.searchText,
        this.filterValue
      );
    }
    if (!this.searchText.length) {
      this.getAllMenuData(0, 10, 'ASC', 'menu_id', '', this.filterValue);
    }
  }

  public pageChangedCommon($event: any) {
    let pageNo = $event.pageIndex;
    let perPage = $event.pageSize;
    this.filterValue.page_no = pageNo;
    this.getAllMenuData(pageNo, perPage);
  }

  public getAllMenuData(
    pageNo: number = this.currentPage,
    perPage: number = 10,
    sort_by: string = 'ASC',
    order_by: string = 'menu_id',
    search?: string,
    filters: any = {},
    type?: string
  ) {
    this.isLoading = true;
    this.filterValue.per_page = perPage;
    this.filterValue.page_no = pageNo;
    this.filterValue.sort_by = sort_by;
    this.filterValue.order_by = order_by;
    if (search) {
      this.filterValue.search = search;
    } else {
      delete this.filterValue.search;
    }
    if (Object.keys(filters).length) {
      Object.keys(filters).map((key: string) => {
        if (filters[key]) {
          this.filterValue[key] = filters[key];
        }
      });
    }
    this.appendURLParameters();
    // let filterCopyObj = _.cloneDeep(this.filterValue);
    let filterCopyObj = this.filterValue;
    filterCopyObj.page_no++;

    this._menuService.getMenuList(filterCopyObj).subscribe(
      (res: any) => {
        
        this.total = res.with.total;
        this.currentPage = pageNo;
        this.allMenuData = res.data;
        // this.allMenuData = res.data.map((value: any) => ({ ...value, isExpected: false }));

        console.log(this.allMenuData);
        this.isLoading = false;
      },
      (error: any) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
          this.allMenuData = false;
          this.isLoading = false;
        }
      }
    );
  }

  public openAddEditUsersModal(data: any) {
    let model = data ? data : null;

    const dialogRef = this.dialog.open(AddEditMenuComponent, {
      autoFocus: false,
      width: '25vw',
      data: {
        title: data ? 'Edit User' : 'Add User',
        msg: '',
        btnName: data ? 'Update' : 'Save',
        model: model,
      },
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      console.log(result);
      if (result) {
        this.getAllMenuData();
      }
    });
  }

  conformationDialog(id: any) {
    const dialogRef = this.dialog.open(AlertDialogComponent, {
      maxWidth: '400px',
      data: {
        message: 'Are you sure want to delete this Menu?',
        buttonText: {
          ok: 'Delete',
          cancel: 'Cancel',
        },
      },
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this._menuService.deleteMenu(id).subscribe((res: any) => {
          this.getAllMenuData();
          this._utilService.showSuccess('Menu Deleted successful!', 'Success');
        });
      } else {
        ('not workiiiiiiiiiiiiiiiiiiiiiing ');
      }
    });
  }
    onChangeStatus(element: any) {
    element.is_active = element?.is_active == 1 ? 0 : 1
    console.log(element);
    const newElm = {...element};
    newElm.is_active = element?.is_active == 1 ? 0 : 1
    // console.log("new wlwmwnt",newElm);pageChangedCommon
  }
  
}
