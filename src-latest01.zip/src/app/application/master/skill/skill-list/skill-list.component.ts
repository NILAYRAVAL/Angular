import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertDialogComponent } from 'src/app/shared/component/alert-dialog/alert-dialog.component';
import { CommonServiceService } from 'src/app/shared/Services/common-service.service';
import { GlobalVariableService } from 'src/app/shared/Services/global-variable.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { Location } from '@angular/common';
import { AddEditSkillComponent } from 'src/app/shared/component/add-edit-skill/add-edit-skill.component';
import { SkillService } from 'src/app/shared/Services/components-services /skill.service';
import { FormControl } from '@angular/forms';
import { debounceTime, switchMap } from 'rxjs';

@Component({
  selector: 'app-skill-list',
  templateUrl: './skill-list.component.html',
  styleUrls: ['./skill-list.component.scss']
})
export class SkillListComponent implements OnInit {

public searchControl!: FormControl;
public isLoading: boolean = false;
  
public total: number = 0;
public currentPage: number = 0;
public pageSize :number = 10;
public pageSizeOptions: number[] = [10, 25, 50, 100];

public filterValue: any = {};
public allSkillData: any = [];

public searchText: string = '';
public displayedColumns: string[] = ['id', 'skill_name', 'action'];
 
   constructor(
     public matDialog: MatDialog,
     public globalVariable:GlobalVariableService,
     public commonService : CommonServiceService,
     private _utilService : UtilService,
     private dialog: MatDialog,
     private activeRoute: ActivatedRoute,
     public location: Location,
     public skillService: SkillService,
     public router : Router
   ) { 
   }
 
   ngOnInit(): void {
     this.activeRoute.queryParams.subscribe((params: any) => {
       this.filterValue = {
           order_by: 'skill_id',
           sort_by: 'ASC',
       }
 
       let pageNumber = params['page'] ? parseInt(params['page']) : 0;
       this.searchText = params['search'] ? params['search'] : undefined;
       this.getAllSkillData(pageNumber, 10, 'ASC', 'skill_id', this.searchText, this.filterValue);
     });
     this.searchFilter()
     this.getAllSkillData()
   }
 

   public searchFilter(){
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
    .pipe(
      debounceTime(1000),
      switchMap(searchTerm => {
        //Make Api call herecons
        this.searchText = searchTerm
        this.getQualificationBySearch()
        return searchTerm; 
      })
    ).subscribe(result => {
     
    });
  }

   public appendURLParameters() {
     let mergedString: string = '';
     mergedString += '?page=' + this.filterValue.page_no;
 
     if (this.filterValue.search && this.filterValue.search !== null && this.filterValue.search !== '') {
        //  mergedString += '&search=' + this.filterValue.search;
     }
     this.location.replaceState('/application/master/skill' + mergedString);
 }
 
 public getQualificationBySearch() {
  if(this.searchText.length > 0) {
    this.getAllSkillData(0, 10, 'ASC', 'skill_id', this.searchText, this.filterValue);
  }
  if(!this.searchText.length) {
    this.getAllSkillData(0, 10, 'ASC', 'skill_id', '', this.filterValue);
  }

}

public pageChangedCommon($event: any) {
  let pageNo = ($event.pageIndex);
  let perPage = $event.pageSize;
  this.filterValue.page_no = pageNo;
  this.getAllSkillData(pageNo, perPage);
}
   public getAllSkillData(pageNo: number = this.currentPage, perPage: number = 10,  sort_by: string = 'ASC',
   order_by: string = 'skill_id', search?: string, filters: any = {}, type?: string){
     this.isLoading = true;
     this.filterValue.per_page = perPage;
     this.filterValue.page_no = pageNo;
     this.filterValue.sort_by = sort_by;
     this.filterValue.order_by = order_by;
     if (search) {
         this.filterValue.search = search;
     } else {
         delete this.filterValue.search;
     }
     if (Object.keys(filters).length) {
         Object.keys(filters).map((key: string) => {
             if (filters[key]) {
                 this.filterValue[key] = filters[key];
             }
         })
     }
     this.appendURLParameters();
     // let filterCopyObj = _.cloneDeep(this.filterValue);
     let filterCopyObj = this.filterValue;
     filterCopyObj.page_no++;
 
     this.skillService.getSkillList(filterCopyObj).subscribe((res:any)=>{
       this.total = res.with.total;
       this.currentPage = pageNo;
       this.allSkillData = res.data;
       this.isLoading = false;
     },
     (error: any) => {
       if (error && error.error.errors && error.error.errors.failed) {
         this._utilService.showError(error.error.errors.failed[0]);
         this.allSkillData = false;
         this.isLoading = false;
      
   }})
   }

   public openAddEditSkillModal(data: any) { 
     let model = data ? data : null
     const dialogRef = this.matDialog.open(AddEditSkillComponent, {
       autoFocus: false,
       width: '20vw',
       data: {
         title: data ? 'Edit Skill' : 'Add Skill',
         msg: '',
         btnName: data ? 'Update' : 'Save',
         model: model,
       }
     });
     dialogRef.afterClosed().subscribe((result: any) => {
       if (result) {
         this.getAllSkillData();
       }
     });
   }
 
   conformationDialog(id:any) {
     const dialogRef = this.dialog.open(AlertDialogComponent,{
       maxWidth:'400px',
       data:{
         message: 'Are you sure want to delete this Skill?',
         buttonText: {
           ok: 'Delete',
           cancel: 'Cancel'
         }
       }
     });
      
     dialogRef.afterClosed().subscribe((confirmed: boolean) => {
       if (confirmed) {
         this.skillService.deleteSkill(id).subscribe((res:any)=>{
           this.getAllSkillData()
           this._utilService.showSuccess('Skill Deleted successful!','Success')
         })
       }
     });
   }

}
