import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CompanyService } from 'src/app/shared/Services/components-services /company.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { Location } from '@angular/common';
import { MatPaginator } from '@angular/material/paginator';
import { FormControl } from '@angular/forms';
import { debounceTime, switchMap } from 'rxjs';

const ELEMENT_DATA: any = [];

@Component({
  selector: 'app-company-detail',
  templateUrl: './company-detail.component.html',
  styleUrls: ['./company-detail.component.scss']
})
export class CompanyDetailComponent implements OnInit {

  @ViewChild(MatPaginator) paginator!: MatPaginator; 
  public searchControl!: FormControl;
  public isLoading : boolean = false;

  public companyId : any = null;
  public dataSource: any = ELEMENT_DATA;
  public filterValue: any = {};
  public compnayData : any;

  public total: number = 0;
  public currentPage: number = 0;
  public pageSize:number = 10;
  public pageSizeOptions: number[] = [10, 25, 50, 100];

  public displayedColumns: string[] = ['id', 'name','email', 'mobile', 'stage', 'status', 'action'];
  public searchText: string = '';

  constructor(
    public utilService : UtilService,
    public route: ActivatedRoute,
    public location: Location,
    public companyService: CompanyService,
    public router : Router
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params:any)=>{
      this.companyId = parseInt(params.company_id)
      this.filterValue = {
        order_by: 'person_id',
        sort_by: 'ASC',
    }
    let pageNumber = params['page'] ? parseInt(params['page']) : 0;
    this.searchText = params['search'] ? params['search'] : undefined;
    this.getAllCompanyData(pageNumber, 10, 'ASC', 'person_id', this.searchText, this.filterValue )
  })
  this.getCompanyDetails()
  this.searchFilter()
  }

  public searchFilter(){
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
    .pipe(
      debounceTime(1000),
      switchMap(searchTerm => {
        //Make Api call herecons
        this.searchText = searchTerm
        this.getCandidateBySearch()
        return searchTerm; 
      })
    ).subscribe(result => {
     
    });
  }


public getCompanyDetails(){
    this.isLoading = true;
    this.companyService.getCompanyDetailsById(this.companyId).subscribe((res:any)=>{
      this.compnayData = res.data;
      this.isLoading = false;

    },
    (error) => {
      if (error && error.error.errors && error.error.errors.failed) {
        this.utilService.showError(error.error.errors.failed[0]);
        this.isLoading = false;
  }})
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }


  public appendURLParameters() {
    let mergedString: string = '';
    mergedString += `?company_id=${this.companyId}page=${this.filterValue.page_no}`;

    if (this.filterValue.search && this.filterValue.search !== null && this.filterValue.search !== '') {
        mergedString += '&search=' + this.filterValue.search;
    }
    this.location.replaceState('application/master/company/company-detail/id' + mergedString);
    
}

public pageChangedCommon($event: any) {
  let pageNo = ($event.pageIndex);
  let perPage = $event.pageSize;
  this.filterValue.page_no = pageNo;
  this.getAllCompanyData(pageNo, perPage);

}
public getCandidateBySearch() {
  if(this.searchText.length > 0) {
    this.getAllCompanyData(0, 10, 'ASC', 'person_id', this.searchText, this.filterValue);
  }
  if(!this.searchText.length) {
    this.getAllCompanyData(0, 10, 'ASC', 'person_id', '', this.filterValue);
  }

}

public  getAllCompanyData(pageNo: number = this.currentPage, perPage: number = 10,  sort_by: string = 'ASC',
        order_by: string = 'person_id', search?: string, filters: any = {}, type?: string) {
        // this.isProjectFolderLoading = true;
        this.isLoading = true;
        this.filterValue.per_page = perPage;
        this.filterValue.page_no = pageNo;
        this.filterValue.sort_by = sort_by;
        this.filterValue.order_by = order_by;
        if (search) {
            this.filterValue.search = search;
        } else {
            delete this.filterValue.search;
        }
        if (Object.keys(filters).length) {
            Object.keys(filters).map((key: string) => {
                if (filters[key]) {
                    this.filterValue[key] = filters[key];
                }
            })
        }
        this.appendURLParameters();
        this.filterValue.company_id = this.companyId
        let filterCopyObj = this.filterValue;
        filterCopyObj.page_no++;

    this.companyService.getCompanyAppliedPersonDetailsById(this.companyId,filterCopyObj).subscribe((res: any) => {
      this.dataSource = res.data;
      this.total = res.with.total;
      this.currentPage = pageNo;
      this.isLoading = false;

      this.dataSource.forEach((el: any) => {
        this.dataSource.id = el.application_id
        el.name = el.name
        el.mobile = el.phone
        el.email = el.email
        el.mobile = el.phone
        el.stage = el.stage?.stage_name
        el.status = el.status?.status_name
      })
    },
    (error) => {
      if (error && error.error.errors && error.error.errors.failed) {
        this.utilService.showError(error.error.errors.failed[0]);
        this.dataSource = false;
        this.isLoading = false;
  }})
  }

public openPositionInNewWindow(element: any) {
   const url = this.router.serializeUrl(this.router.createUrlTree(['/application/candidates/candidate-history/id'], { queryParams: { candidate_id: element.person_id } }));
    window.open(url, '_blank');
  // this.router.navigate(['/application/candidates-history'], { queryParams: { candidate_id:id } })
  }
public goBack(){
    this.utilService.goBack()
  }
}
