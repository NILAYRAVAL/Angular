import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonServiceService } from 'src/app/shared/Services/common-service.service';
import { GlobalVariableService } from 'src/app/shared/Services/global-variable.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { Location } from '@angular/common';
import { AlertDialogComponent } from 'src/app/shared/component/alert-dialog/alert-dialog.component';
import { CompanyService } from 'src/app/shared/Services/components-services /company.service';
import { AddEditCompanyComponent } from 'src/app/shared/component/add-edit-company/add-edit-company.component';
import { FormControl } from '@angular/forms';
import { debounceTime, switchMap } from 'rxjs';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.scss']
})
export class CompanyListComponent implements OnInit {
  
public searchControl!: FormControl;
public isLoading: boolean = false;
  
public total: number = 0;
public currentPage: number = 0;
public pageSize = 10;
public pageSizeOptions: number[] = [10, 25, 50, 100];

public filterValue: any = {};
public allCompanyData: any = [];
  
public searchText: string = '';
public displayedColumns: string[] = ['id', 'company_name','total_persons', 'action'];
 
   constructor(
     public matDialog: MatDialog,
     public globalVariable:GlobalVariableService,
     public commonService : CommonServiceService,
     private _utilService : UtilService,
     private dialog: MatDialog,
     private activeRoute: ActivatedRoute,
     public location: Location,
     public companyService: CompanyService,
     public router : Router
   ) { }
 
   ngOnInit(): void {
     this.activeRoute.queryParams.subscribe((params: any) => {
       this.filterValue = {
           order_by: 'company_name',
           sort_by: 'ASC',
       }
 
       let pageNumber = params['page'] ? parseInt(params['page']) : 0;
       this.searchText = params['search'] ? params['search'] : undefined;
       this.getAllCompanyData(pageNumber, 10, 'ASC', 'company_name', this.searchText, this.filterValue);
     });
     this.searchFilter()
     this.getAllCompanyData()
   }
 
   public searchFilter(){
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
    .pipe(
      debounceTime(1000),
      switchMap(searchTerm => {
        //Make Api call herecons
        this.searchText = searchTerm
    
        this.getCompanyBySearch()
        return searchTerm; 
      })
    ).subscribe(result => {
     
    });
  }

  public getCompanyBySearch() {
    if(this.searchText.length > 0) {
      this.getAllCompanyData(0, 10, 'ASC', 'company_name', this.searchText, this.filterValue);
    }
    if(!this.searchText.length) {
      this.getAllCompanyData(0, 10, 'ASC', 'company_name', '', this.filterValue);
    }
  
  }

public pageChangedCommon($event: any) {
    let pageNo = ($event.pageIndex);
    let perPage = $event.pageSize;
    this.filterValue.page_no = pageNo;
    this.getAllCompanyData(pageNo, perPage);
  }
public appendURLParameters() {
     let mergedString: string = '';
     mergedString += '?page=' + this.filterValue.page_no;
 
     if (this.filterValue.search && this.filterValue.search !== null && this.filterValue.search !== '') {
        //  mergedString += '&search=' + this.filterValue.search;
     }
     this.location.replaceState('/application/master/company' + mergedString);
 }
 
public getAllCompanyData(pageNo: number = this.currentPage, perPage: number = 10,  sort_by: string = 'ASC',
   order_by: string = 'company_name', search?: string, filters: any = {}, type?: string){
     this.isLoading = true;
     this.filterValue.per_page = perPage;
     this.filterValue.page_no = pageNo;
     this.filterValue.sort_by = sort_by;
     this.filterValue.order_by = order_by;
     if (search) {
         this.filterValue.search = search;
     } else {
         delete this.filterValue.search;
     }
     if (Object.keys(filters).length) {
         Object.keys(filters).map((key: string) => {
             if (filters[key]) {
                 this.filterValue[key] = filters[key];
             }
         })
     }
     this.appendURLParameters();
     // let filterCopyObj = _.cloneDeep(this.filterValue);
     let filterCopyObj = this.filterValue;
     filterCopyObj.page_no++;
    
     this.companyService.getCompanyList(filterCopyObj).subscribe((res:any)=>{
       this.total = res.with.total;
       this.currentPage = pageNo;
       this.allCompanyData = res.data;
         this.isLoading = false;
     },
     (error) => {
       if (error && error.error.errors && error.error.errors.failed) {
         this._utilService.showError(error.error.errors.failed[0]);
         this.allCompanyData = false;
         this.isLoading = false;
   }})
   }
 
 
public openAddEditCompanyModal(data: any) {
     let model = data ? data : null
     const dialogRef = this.matDialog.open(AddEditCompanyComponent, {
       autoFocus: false,
       width: '65vw',
       data: {
         title: data ? 'Edit Company' : 'Add Company',
         msg: '',
         btnName: data ? 'Update' : 'Save',
         model: model,
       }
     });
     dialogRef.afterClosed().subscribe(result => {
       if (result) {
         this.getAllCompanyData();
       }
     });
   }
 
public conformationDialog(id:any) {
     const dialogRef = this.dialog.open(AlertDialogComponent,{
       maxWidth:'400px',
       data:{
         message: 'Are you sure want to delete this Company?',
         buttonText: {
           ok: 'Delete',
           cancel: 'Cancel'
         }
       }
     });
      
     dialogRef.afterClosed().subscribe((confirmed: boolean) => {
       if (confirmed) {
         this.companyService.deleteCompany(id).subscribe((res:any)=>{
           this.getAllCompanyData()
           this._utilService.showSuccess('Company Deleted successful!','Success')
         })
       }
     });
   }

public redirectTOCompanyDetails(id:any){
      this.router.navigate([`application/master/company/company-detail/id`],{queryParams: {company_id : id}});
      
}

}
