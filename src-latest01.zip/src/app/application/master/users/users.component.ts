import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { debounceTime, switchMap } from 'rxjs';
import { AlertDialogComponent } from 'src/app/shared/component/alert-dialog/alert-dialog.component';
import { CommonServiceService } from 'src/app/shared/Services/common-service.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { Location } from '@angular/common';
import { AddEditUserComponent } from 'src/app/shared/component/add-edit-user/add-edit-user.component';
import { UserService } from 'src/app/shared/Services/components-services /user.service';
// import { UserformComponent } from 'src/app/shared/component/userform/userform.component';


export interface PeriodicElement {
  
  user_id: string;
  email: string;
  name: string;
  role_id: string;
}

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
})
export class UsersComponent implements OnInit {
  public searchControl!: FormControl;
  public isLoading: boolean = false;

  public total: number = 0;
  public currentPage: number = 0;
  public pageSize: number = 10;
  public pageSizeOptions: number[] = [10, 25, 50, 100];

  public filterValue: any = {};
  public allUsersData: any = [];

  public searchText: string = '';
  public displayedColumns: string[] = ['user_id', 'name', 'email', 'action'];

  constructor(
    public commonService: CommonServiceService,
    private _utilService: UtilService,
    private dialog: MatDialog,
    private activeRoute: ActivatedRoute,
    public location: Location,
    public router: Router,
    
    public userService: UserService,
  ) {}

  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe((params: any) => {
      this.filterValue = {
        order_by: 'user_id',
        sort_by: 'ASC',
      };

      let pageNumber = params['page'] ? parseInt(params['page']) : 0;
      this.searchText = params['search'] ? params['search'] : undefined;
      this.getAllUserData(
        pageNumber,
        10,
        'ASC',
        'user_id',
        this.searchText,
        this.filterValue
      );
    });
    this.searchFilter();
  }

  public searchFilter() {
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
      .pipe(
        debounceTime(1000),
        switchMap((searchTerm: any) => {
          //Make Api call herecons
          this.searchText = searchTerm;
          this.getUsersBySearch();
          return searchTerm;
        })
      )
      .subscribe((result) => {});
  }

  public appendURLParameters() {
    let mergedString: string = '';
    mergedString += '?page=' + this.filterValue.page_no;

    if (
      this.filterValue.search &&
      this.filterValue.search !== null &&
      this.filterValue.search !== ''
    ) {
      //  mergedString += '&search=' + this.filterValue.search;
    }
    this.location.replaceState('/application/master/users' + mergedString);
  }

  public getUsersBySearch() {
    if (this.searchText.length > 0) {
      this.getAllUserData(
        0,
        10,
        'ASC',
        'user_id',
        this.searchText,
        this.filterValue
      );
    }
    if (!this.searchText.length) {
      this.getAllUserData(0, 10, 'ASC', 'user_id', '', this.filterValue);
    }
  }

  public pageChangedCommon($event: any) {
    let pageNo = $event.pageIndex;
    let perPage = $event.pageSize;
    this.filterValue.page_no = pageNo;
    this.getAllUserData(pageNo, perPage);
  }

  public getAllUserData(
    pageNo: number = this.currentPage,
    perPage: number = 10,
    sort_by: string = 'ASC',
    order_by: string = 'user_id',
    search?: string,
    filters: any = {},
    type?: string
  ) {
    this.isLoading = true;
    this.filterValue.per_page = perPage;
    this.filterValue.page_no = pageNo;
    this.filterValue.sort_by = sort_by;
    this.filterValue.order_by = order_by;
    if (search) {
      this.filterValue.search = search;
    } else {
      delete this.filterValue.search;
    }
    if (Object.keys(filters).length) {
      Object.keys(filters).map((key: string) => {
        if (filters[key]) {
          this.filterValue[key] = filters[key];
        }
      });
    }
    this.appendURLParameters();
    // let filterCopyObj = _.cloneDeep(this.filterValue);
    let filterCopyObj = this.filterValue;
    filterCopyObj.page_no++;

    this.userService.getUserList(filterCopyObj).subscribe(
      (res: any) => {
        this.total = res.with.total;
        this.currentPage = pageNo;
        this.allUsersData = res.data;
        // get data from services display in table
        console.log(this.allUsersData);
        this.isLoading = false;
      },
      (error: any) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
          this.allUsersData = false;
          this.isLoading = false;
        }
      }
    );
  }

  public openAddEditUsersModal(data: any) {
    let model = data ? data : null;

    const dialogRef = this.dialog.open(AddEditUserComponent, {
      autoFocus: false,
      width: '25vw',
      data: {
        title: data ? 'Edit User' : 'Add User',
        msg: '',
        btnName: data ? 'Update' : 'Save',
        model: model,
      },
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      console.log(result);
      if (result) {
        this.getAllUserData();
      }
    });
  }

  conformationDialog(id: any) {
    const dialogRef = this.dialog.open(AlertDialogComponent, {
      maxWidth: '400px',
      data: {
        message: 'Are you sure want to delete this User?',
        buttonText: {
          ok: 'Delete',
          cancel: 'Cancel',
        },
      },
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.userService.deleteUsers(id).subscribe((res: any) => {
          this.getAllUserData();
          this._utilService.showSuccess('User Deleted successful!', 'Success');
        });
      }
      else{
        "not workiiiiiiiiiiiiiiiiiiiiiing "
      }
    });
  }
}
