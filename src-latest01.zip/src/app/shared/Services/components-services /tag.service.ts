import { Injectable } from '@angular/core';
import { CommonService } from '../common.service';

@Injectable({
  providedIn: 'root',
})
export class TagService {
  
  constructor(private _commonService: CommonService) {}


  public getTagList(params: any) {
    return this._commonService.get(`tag?`, params);
  }
//   public getRoleList(params: any) {
//     return this._commonService.get(`user-management/roles?`, params);
//   }
  public addUpdateuser(data: FormData) {
    return this._commonService.postWithFormData(`tag/store-update`, data);
  }
  public deleteUsers(usersId: any) {
    return this._commonService.delete(`tag/${usersId}`);
  }
}
