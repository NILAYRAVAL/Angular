import { Injectable } from '@angular/core';
import { CommonService } from '../common.service';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  
  constructor(private _commonService: CommonService) {}


  public getUserList(params: any) {
    return this._commonService.get(`user-management/users?`, params);
  }
  public getRoleList(params: any) {
    return this._commonService.get(`user-management/roles?`, params);
  }
  public addUpdateuser(data: FormData) {
    return this._commonService.postWithFormData(`user-management/users/store-update`, data);
  }
  public deleteUsers(usersId: any) {
    return this._commonService.delete(`user-management/users/${usersId}`);
  }
  public userChangePassword(data: any) {
    return this._commonService.postWithFormData(`change-password`, data);
  }
}
