import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonService } from '../common.service';

@Injectable({
  providedIn: 'root'
})
export class CandidateService {

  constructor(private _commonService: CommonService) { }


  public getCandidateDetail(data: FormData) {
    return this._commonService.get(`applications/`, data);
  }

  public addUpdateCandidate(data: any) {
    return this._commonService.postWithFormData(`applications/store-update`, data);
  }

  public getCandidateList(params?: any) {
    return this._commonService.get(`applications?`, params);
  }

  public getCandidateLists(params?: any ) {
    return this._commonService.post(`persons`, params);
  }

  public getCandidateById(eventId: any) {
    return this._commonService.get(`applications/${eventId}`);
  }

  public getCandidatePersonById(eventId: any) {
    return this._commonService.get(`persons/${eventId}`);
  }

  public getCandidateHistoryById(candidateId: any) {
    return this._commonService.get(`applications/person/${candidateId}/stage-list`);
  }

  public deleteCandidate(eventId: any) {
    return this._commonService.delete(`applications/${eventId}`);
  }
  public getSkillList(params: any) {
    return this._commonService.get(`skills?`, params);
  }

  // get form option array list //

  public getQualificationList() {
    return this._commonService.get(`qualifications?search=&order_by=qualification_id&sort_by=DESC&per_page=1000&page_no=1`);
  }

  public getSkillsList() {
    return this._commonService.get(`skills?search=&order_by=skill_id&sort_by=DESC&per_page=1000&page_no=1`);
  }

  public getDesignationList() {
    return this._commonService.get(`designations`);
  }

  public getTechnologyList() {
    return this._commonService.get(`technologies`);
  }
  public getCompnayList(queryParams?: any) {
    if (!queryParams) {
      return this._commonService.get(`companies`);
    } else {
      return this._commonService.get(`companies?` + queryParams);
    }
  }

  public getExistUserList(){
    return this._commonService.get(`persons`);
  }

  public FindExistUserList(data:any){
    return this._commonService.postWithFormData(`persons/find-person`,data);
  }

  public FindExistUserDataById(data:any){
    return this._commonService.get(`persons/` + data);
  }

  public addCandidateCompany(data: any) {
    return this._commonService.postWithFormData(`companies/store-update`, data);
  }

  public getSupplierData() {
    return this._commonService.get(`suppliers`);
  }

  public getStages(param: any): Observable<any> {
    return this._commonService.get('stages?', param)
  }

  public getStatus(param: any): Observable<any> {
    return this._commonService.get('statuses?', param)
  }

  public updateCandidateComment(candidateComment: any): Observable<any> {
    return this._commonService.post('applications/stage-update', candidateComment)
  }

  public getCurrentStateIdWithData(country_id = 101): Observable<any> {
    return this._commonService.get('states?search=&order_by=id&sort_by=DESC&per_page=1000&page_no=1&country_id=101')
  }
  public getCurrentCityIdWithData(stateId:any): Observable<any> {
    return this._commonService.get(`cities?search=&order_by=id&sort_by=DESC&per_page=1000&page_no=1&state_id=${stateId}`)
  }
  public getNativeCityIdWithData(stateId:any): Observable<any> {
    return this._commonService.get(`cities?search=&order_by=id&sort_by=DESC&per_page=1000&page_no=1&state_id=${stateId}`)
  }

}
