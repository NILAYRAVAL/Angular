import { Injectable } from '@angular/core';
import {CommonService } from '../common.service';
 


@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private _commonService : CommonService) { }

  public getDashboardCount() {
    return this._commonService.get(`dashboard`);
  }

  public getTodayScheduleData(params: any) {
    return this._commonService.get(`dashboard/schedule-interview?`,params);
  }

}
