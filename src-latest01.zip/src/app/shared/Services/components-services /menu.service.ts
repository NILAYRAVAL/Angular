import { Injectable } from '@angular/core';
import { CommonService } from '../common.service';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  
  constructor(private _commonService: CommonService) {}


  public getMenuList(params: any) {
    return this._commonService.get(`menus?`, params);
  }
//   public getRoleList(params: any) {
//     return this._commonService.get(`user-management/roles?`, params);
//   }
  public addUpdateuser(data: FormData) {
    return this._commonService.postWithFormData(`menus/store-update`, data);
  }
  public deleteMenu(menuId: any) {
    return this._commonService.delete(`menus/${menuId}`);
  }
}
