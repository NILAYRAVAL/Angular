import { Injectable } from '@angular/core';
import {CommonService } from '../common.service';
 


@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  constructor(private _commonService : CommonService) { }

  public addUpdateCompany(data: FormData) {
    return this._commonService.postWithFormData(`companies/store-update`, data);
  }

  public getCompanyList(params: any) {
    return this._commonService.get(`companies?`, params);
  }
   
  public deleteCompany(companyId: any) {
    return this._commonService.delete(`companies/${companyId}`);
  }

  public getCompanyDetailsById(companyId: any) {
    return this._commonService.get(`companies/${companyId}`);
  }

  public getCompanyAppliedPersonDetailsById(companyId: any,params: any) {
    return this._commonService.get(`companies/${companyId}/person-lists?`,params);
  }

  public getCountryList(params: any) {
    return this._commonService.get(`countries?`, params);
  }

  public getStateList(params: any) {
    return this._commonService.get(`states?`, params);
  }

  public getCityList(params: any) {
    return this._commonService.get(`cities?`, params);
  }

}
