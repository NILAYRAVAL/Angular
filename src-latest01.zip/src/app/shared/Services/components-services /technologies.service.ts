import { Injectable } from '@angular/core';
import {CommonService } from '../common.service';
 


@Injectable({
  providedIn: 'root'
})
export class TechnologiesService {

  constructor(private _commonService : CommonService) { }

  public addUpdatetechnology(data: FormData) {
    return this._commonService.postWithFormData(`technologies/store-update`, data);
  }

  public geTechnologyList(params: any) {
    return this._commonService.get(`technologies?`, params);
  }
   
  public deleteTechnology(technologiesId: any) {
    return this._commonService.delete(`technologies/${technologiesId}`);
  }

}
