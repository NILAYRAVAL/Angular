import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { QualificationService } from '../../Services/components-services /qualification.service';
import { SkillService } from '../../Services/components-services /skill.service';
import { GlobalVariableService } from '../../Services/global-variable.service';
import { UtilService } from '../../Services/util.service';

@Component({
  selector: 'app-add-edit-skill',
  templateUrl: './add-edit-skill.component.html',
  styleUrls: ['./add-edit-skill.component.scss']
})
export class AddEditSkillComponent implements OnInit {
  
  public subscription : Subscription[] = []

  public isLoading: boolean = false;
  
  public addEditTitle : string= '';


  public formValidations: any = {
    skill_name: [{ type: 'required', message: 'Skill Name is required' }]
  };

  addEditForm = this._fb.group({
    skill_name: new FormControl('', Validators.required)
  });

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<AddEditSkillComponent>,
    public globalVariable: GlobalVariableService,
    public matDialog: MatDialog,
    public globalService: GlobalVariableService,
    private _fb: FormBuilder,
    private _utilService: UtilService,
    private _skillService: SkillService,
    private dialog: MatDialog
  ) { }

  ngOnInit(): void {
    if (this.data.btnName == 'Update') {
      this.addEditTitle = 'Edit Skill';
      this.addEditForm.patchValue(this.data.model)
    } else if (this.data.btnName == 'Save') {
      this.addEditTitle = 'Add Skill';
    }
  }

  public onNoClick(formData: any): void {
    this.onSubmitData(formData);
  }
  public genrateFormData(form: any) {
    const fd: FormData = new FormData();
    Object.keys(form).map((key: string) => {
      let value: any = form[key];
      if (Array.isArray(value)) {
        value.map((val) => {
          fd.append(key, val);
        });
        if (!value.length) {
          fd.append(key, '[]');
        }
      } else {
        if (value != null) {
          fd.append(key, value);
        } else {
          fd.append(key, '');
        }
      }
    });
    return fd;
  }

  public onSubmitData(formData: any) {
    this.addEditForm.markAllAsTouched();
    this.addEditForm.updateValueAndValidity();
    // this.setCompanyExpriance();
    if(this.addEditForm.invalid){
      this.isLoading = false;
      return;
    }
    this.isLoading = true;
    let payloadObj: any = formData;
    payloadObj.skill_id = this.data.btnName == 'Save' ? 0 : this.data.model.skill_id;
    const fd: any = this.genrateFormData(payloadObj);
    this.subscription.push(this._skillService.addUpdateSkill(fd).subscribe(
      (res: any) => {
        this.isLoading = false;
        this._utilService.showSuccess(res.message);
        this.dialogRef.close(true);
      },
      (error) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
        }
      }
    ));
  }
  public Close() {
    this.dialogRef.close(true);
  }

}
