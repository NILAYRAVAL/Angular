import { Component, Inject, OnInit } from '@angular/core';

import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
// import { ConfirmationComponent } from '../confirmation/confirmation.component';
// import { Practice00Service } from '../practice00.service';
import { Router } from '@angular/router';
import { UserService } from '../../Services/components-services /user.service';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-userform',
  templateUrl: './userform.component.html',
  styleUrls: ['./userform.component.scss'],
})
export class UserformComponent implements OnInit {
  loginPageForm!: FormGroup;
  posts5: any;
  roles: any[] = [];
  hide = true;

  constructor(
    // private _httpservice: Practice00Service,
    private _fa_: FormBuilder,
    public _userservice: UserService,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public datas: any,
    private router: Router
  ) {}

  ngOnInit(): void {
    console.log('DIALOG DATAA==>>', this.datas);

    this.loginPageForm = this._fa_.group(
      {
        user_id: ['0', Validators.required],

        email: this._fa_.control(
          null,
          Validators.compose([
            Validators.required,
            Validators.email,
            Validators.pattern(
              '[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}'
            ),
          ])
        ),
        name: this._fa_.control(null, [Validators.required]),
        password: this._fa_.control(null, [Validators.required]),
        role_id: ['', Validators.required],
      }
      // { Validators: this.confirmPasswordValidator }
    );

    this.getData();
  }
  get data() {
    return this.loginPageForm.get('data') as FormArray;
  }

  getData() {
    let params: any;
    this._userservice.getRoleList(params).subscribe(
      (res: any) => {
        this.roles = res?.data;
        console.log(this.roles);
        // this.data.push(this.roles);
      },
      (error) => {
        console.error(error);
        this.roles = [];
      }
    );
  }
  get fc() {
    return this.loginPageForm.controls;
  }
  get aakash() {
    return this.loginPageForm.get('role_id') as FormArray;
  }

  loginForm() {
    console.log(this.loginPageForm);
    console.log(this.loginPageForm.value);
  }

  PostData() {
    const reqBody = this.loginPageForm.value;

    this._userservice.addUpdateuser(reqBody).subscribe(
      (response: any) => {
        console.log(response);
        this.roles = response;

        if (response) {
          window.location.reload();
          // this.router.navigate(['table'])
        }
      },
      (error: any) => {
        debugger;
        console.log(error);
      }
    );
  }
}
