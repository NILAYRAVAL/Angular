import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { CompanyService } from '../../Services/components-services /company.service';
import { QualificationService } from '../../Services/components-services /qualification.service';
import { GlobalVariableService } from '../../Services/global-variable.service';
import { UtilService } from '../../Services/util.service';

@Component({
  selector: 'app-add-edit-company',
  templateUrl: './add-edit-company.component.html',
  styleUrls: ['./add-edit-company.component.scss']
})
export class AddEditCompanyComponent implements OnInit {

  public subscription : Subscription[] = []

  public countryListArray: Array <any> = [];
  public stateListArray: Array <any> = [];
  public cityListArray: Array <any> = [];

  public countryId: any = null;
  public stateId: any  = null;
  public selectedCityId: any = null;

 public isLoading: boolean = false;

  public addEditTitle : string= '';

  public selectedCountry: any;
  public selectedState: any;


  public formValidations: any = {
    company_name: [{ type: 'required', message: 'Company Name is required' }],
    email: [{ type: 'required', message: 'Email is required' }],
    phone: [{ type: 'required', message: 'Phone is required' }],
    address_line1: [{ type: 'required', message: 'Address Line1 is required' }],
    address_line2: [{ type: 'required', message: 'Address Line2 is required' }],
  };

  addEditForm = this._fb.group({
    company_name: new FormControl('', Validators.required),
    phone: new FormControl(''),
    email: new FormControl(''),
    country_id: new FormControl(''),
    state_id: new FormControl(''),
    city_id: new FormControl(''),
    address_line1: new FormControl(''),
    address_line2: new FormControl(''),
    zip_code: new FormControl('')
  });

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<AddEditCompanyComponent>,
    public globalVariable: GlobalVariableService,
    public matDialog: MatDialog,
    public globalService: GlobalVariableService,
    private _fb: FormBuilder,
    private _utilService: UtilService,
    private _companyService: CompanyService,
    private dialog: MatDialog
  ) { }

  ngOnInit(): void {
    if (this.data.btnName == 'Update') {
      this.addEditTitle = 'Edit Company';
      this.addEditForm.patchValue(this.data.model)
      if(this.data.model && this.data.model.country_id) {
        this.countryId = this.data.model.country_id;
        this.getCountry("", true);
      } else {
        this.getCountry();
      }

      if(this.data.model && this.data.model.state_id) {
        this.stateId = this.data.model.state_id;
        this.getState("", this.countryId, true);
      }

      if(this.data.model && this.data.model.city_id) {
        this.selectedCityId = this.data.model.city_id;
        this.getCity("", this.stateId, true);
      }

    } else if (this.data.btnName == 'Save') {
      this.getCountry();
      this.addEditTitle = 'Add Company';
    }
  }

 public onSearchCountry(strVal: any) {
  const searchStr: any = strVal.target.value;
  this.getCountry(searchStr);
 }

 public onSearchState(strVal: any) {
  const searchStr: any = strVal.target.value;
  this.getState(searchStr, this.selectedCountry);
 }

 public onSearchCity(strVal: any) {
  const searchStr: any = strVal.target.value;
  this.getCity(searchStr, this.selectedState);
 }

 public onSelecteCity(data: any) {
   const cityId = this.cityListArray.filter((res: any) => res.city_name === data);
   this.selectedCityId = cityId[0].id;
 }

 public getCountry(search?: string, isSetValue?: boolean){
    let payloadObj: any = {};
    payloadObj.per_page = 1000;
    payloadObj.page_no = 1;
    payloadObj.sort_by = 'ASC';
    payloadObj.order_by = 'id';
    if (search) {
      payloadObj.search = search;
    } else {
        delete payloadObj.search;
    }
    this._companyService.getCountryList(payloadObj).subscribe((res:any)=>{
      if(res) {
        this.countryListArray = res.data;
        if (this.data.btnName == 'Update' && isSetValue) {
          const setCountry = this.countryListArray.filter((res: any)=> res.id === this.data.model.country_id)[0]
          this.addEditForm.get('country_id')?.setValue(setCountry.country_name);
        }
      }
    }, (error: any) => {
      this.countryListArray = [];
    })
  }

 public getState(search?: any, data?: any, isSetValue?: boolean) {
  this.selectedCountry = data;
  if (this.data.btnName == 'Update' && isSetValue) {
    this.countryId = this.data.model.country_id;
  } else {
    const countryId = this.countryListArray.filter((res: any) => res.country_name === data);
    this.countryId = (countryId && countryId.length) ? countryId[0].id : null;
  }
  
    let payloadObj: any = {};
    payloadObj.per_page = 1000;
    payloadObj.page_no = 1;
    payloadObj.sort_by = 'ASC';
    payloadObj.order_by = 'id';
    payloadObj.country_id = (this.data.btnName == 'Update' && isSetValue) ? this.data.model.country_id : this.countryId;

    if (search) {
      payloadObj.search = search;
    } else {
        delete payloadObj.search;
    }

    this._companyService.getStateList(payloadObj).subscribe((res:any)=>{
      if(res) {
        this.stateListArray = res.data;
        if (this.data.btnName == 'Update' && isSetValue) {
          const setState = this.stateListArray.filter((res: any)=> res.id === this.data.model.state_id)[0]
          this.addEditForm.get('state_id')?.setValue(setState.state_name);
        }
      }
    }, (error: any) => {
      this.stateListArray = [];
    })
  
 }

 public getCity(search?: any, data?: any, isSetValue?: boolean) {
  this.selectedState = data;
  if (this.data.btnName == 'Update' && isSetValue) {
    this.stateId = this.data.model.state_id;
  } else {
    const statId = this.stateListArray.filter((res: any) => res.state_name === data);
    this.stateId = (statId && statId.length) ? statId[0].id : null;
  }
    let payloadObj: any = {};
    payloadObj.per_page = 1000;
    payloadObj.page_no = 1;
    payloadObj.sort_by = 'ASC';
    payloadObj.order_by = 'id';
    payloadObj.country_id = (this.data.btnName == 'Update' && isSetValue) ? this.data.model.country_id : this.countryId
    payloadObj.state_id = (this.data.btnName == 'Update' && isSetValue) ? this.data.model.state_id : this.stateId

    if (search) {
      payloadObj.search = search;
    } else {
        delete payloadObj.search;
    }

    this._companyService.getCityList(payloadObj).subscribe((res:any)=>{
      if(res) {
        this.cityListArray = [];
        this.addEditForm.get('city_id')?.setValue(null);
        this.cityListArray = res.data;
        if (this.data.btnName == 'Update' && isSetValue) {
          const setCity = this.cityListArray.filter((res: any)=> res.id === this.data.model.city_id)[0]
          this.addEditForm.get('city_id')?.setValue(setCity.city_name);
        }
      }
    }, (error: any) => {
      this.cityListArray = [];
    })
  }
  public onNoClick(formData: any): void {
    this.onSubmitData(formData);
  }
  public genrateFormData(form: any) {
    const fd: FormData = new FormData();
    Object.keys(form).map((key: string) => {
      let value: any = form[key];
      if (Array.isArray(value)) {
        value.map((val) => {
          fd.append(key, val);
        });
        if (!value.length) {
          fd.append(key, '[]');
        }
      } else {
        if (value != null) {
          fd.append(key, value);
        } else {
          fd.append(key, '');
        }
      }
    });
    return fd;
  }

  public onSubmitData(formData: any) {
    this.addEditForm.markAllAsTouched();
    this.addEditForm.updateValueAndValidity();
    // this.setCompanyExpriance();
    if(this.addEditForm.invalid){
      this.isLoading = false;
      return;
    }
    this.isLoading = true;
    let payloadObj: any = formData;
    payloadObj.company_id = this.data.btnName == 'Save' ? 0 : this.data.model.company_id;
    payloadObj.country_code = '+91';
    payloadObj.country_id = this.countryId;
    payloadObj.state_id = this.stateId;
    payloadObj.city_id = this.selectedCityId;

    const fd: any = this.genrateFormData(payloadObj);
    this.subscription.push(this._companyService.addUpdateCompany(fd).subscribe(
      (res: any) => {
        this.isLoading = false;
        this._utilService.showSuccess(res.message);
        this.dialogRef.close(true);
      },
      (error) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
        }
      }
    ));
  }
  public Close() {
    this.dialogRef.close(true);
  }

}
