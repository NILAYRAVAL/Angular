import { Component, Inject, OnInit } from '@angular/core';
import { encode, decode } from 'js-base64';

import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { UtilService } from '../../Services/util.service';
import { UserService } from '../../Services/components-services /user.service';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrls: ['./add-edit-user.component.scss'],
})
export class AddEditUserComponent implements OnInit {
  public subscription: Subscription[] = [];
  hide = true;

  roles: any[] = [];
  public isLoading: boolean = false;
  public addEditTitle: string = '';
  public formValidations: any = {
    name: [{ type: 'required', message: 'User Name is required' }],
    email: [
      { type: 'required', message: 'Email is required' },
      { type: 'email', message: 'Not a valid email' },
    ],
    password: [
      {
        type: 'required',
        message: 'Password is required',
      },
    ],
    role_id: [[{ type: 'required', message: 'Role is required' }]],
  };

  public addEditForm: any;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<AddEditUserComponent>,
    private _fb: FormBuilder,
    private _utilService: UtilService,
    private _userservice: UserService,
    private dialog: MatDialog
  ) {
    this.data?.btnName == 'Update'
      ? this.initializeEditForm()
      : this.initializeAddFrom();
  }

  ngOnInit(): void {
    console.log('DATAAA', this.data);
    if (this.data.btnName == 'Update') {
      this.addEditTitle = 'Edit User';
      // console.log(this.data.model);
      this.addEditForm.patchValue(
        {
          email: this.data.model.email,
          name: this.data.model.name,
          role_id: this.data.model.role.role_id,
          if() {},
        },
        { emitEvent: false }
      );
    } else if (this.data.btnName == 'Save') {
      this.addEditTitle = 'Add User';
    }
    this.getData();
  }

  initializeEditForm() {
    this.addEditForm = this._fb.group({
      email: this._fb.control(
        { value: '', disabled: true },
        Validators.compose([
          Validators.required,
          Validators.email,
          Validators.pattern('[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}'),
        ])
      ),
      name: ['', [Validators.required]],
      role_id: ['', Validators.required],
    });

    // this.addEditForm.controls[email].disable();
  }
  initializeAddFrom() {
    this.addEditForm = this._fb.group({
      email: this._fb.control(
        null,
        Validators.compose([
          Validators.required,
          Validators.email,
          Validators.pattern('[A-Za-z0-9._%-]+@[A-Za-z0-9._%-]+\\.[a-z]{2,3}'),
        ])
      ),
      name: ['', [Validators.required]],
      role_id: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  getData() {
    let params: any;
    this._userservice.getRoleList(params).subscribe(
      (res: any) => {
        this.roles = res?.data;
        console.log(this.roles);
      },
      (error) => {
        console.error(error);
        this.roles = [];
      }
    );
  }
  public onNoClick(formData: any): void {
    formData.password = encode(formData.password);
    // console.log(formData.password);
    this.onSubmitData(formData);
  }
  public genrateFormData(form: any) {
    const fd: FormData = new FormData();
    Object.keys(form).map((key: string) => {
      let value: any = form[key];
      if (Array.isArray(value)) {
        value.map((val) => {
          fd.append(key, val);
        });
        if (!value.length) {
          fd.append(key, '[]');
        }
      } else {
        if (value != null) {
          fd.append(key, value);
        } else {
          fd.append(key, '');
        }
      }
    });
    return fd;
  }

  public onSubmitData(formData: any) {
    console.log(formData);

    this.addEditForm.markAllAsTouched();
    this.addEditForm.updateValueAndValidity();

    console.log('formm', this.addEditForm);
    console.log('this.addEditForm.invalid', this.addEditForm.invalid);

    if (this.addEditForm.invalid) {
      this.isLoading = false;
      return;
    }
    this.isLoading = true;
    let payloadObj: any = formData;

    payloadObj.user_id =
      this.data.btnName == 'Save' ? 0 : this.data.model.user_id;
    const fd: any = this.genrateFormData(payloadObj);
    // console.log(payloadObj);
    this.subscription.push(
      this._userservice.addUpdateuser(fd).subscribe(
        (res: any) => {
          console.log('new user added', res);

          this.isLoading = false;
          this._utilService.showSuccess(res.message);
          this.dialogRef.close(true);
        },
        (error) => {
          const { errors } = error?.error;

          if (errors) {
            this.isLoading = false;
            Object.keys(errors).forEach((key, i) => {
              this._utilService.showError(errors[key][0]);
              const newError = {
                type: 'api',
                message: errors[key][i],
              };
              this.formValidations[key].push(newError);
              this.addEditForm.get(key).setErrors(newError);

              return;
            });
          } else {
            this._utilService.showError(error.error.message);
          }

          // if (error && error.error) {
          //   this._utilService.showError(error.error.message);
          // } else if (error && error.error.errors && error.error.errors.failed) {
          //   this._utilService.showError(error.error.errors.failed[0]);
          // }else{
          //   this._utilService.showError(error);
          // }
        }
      )
    );
  }
  public Close() {
    this.dialogRef.close();
  }
}
