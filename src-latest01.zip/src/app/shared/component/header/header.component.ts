import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../Services/util.service';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  public user_detials :any;

  constructor(private _utilService : UtilService,
              private dialog: MatDialog,

              public router : Router) { }

  ngOnInit(): void {

  this.user_detials = this._utilService.getLocalStorageValue('userDetail')

  }
public changePass(){
  this.router.navigateByUrl('/application/change-password')
}

  // conformation dialog //
  public openLogoutDialoug(id?: any) {
    const dialogRef = this.dialog.open(AlertDialogComponent, {
      width: '400px',
      data: {
        message: 'Are you sure want to logout?',
        buttonText: {
          ok: 'Yes',
          cancel: 'No'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
    this._utilService.logOut();
      }
    });
  }

public signout(){
    // this.router.navigate([''])
    // this._utilService.logOut();
  }
}
