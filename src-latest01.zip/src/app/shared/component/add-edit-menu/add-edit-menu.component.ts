import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-menu',
  templateUrl: './add-edit-menu.component.html',
  styleUrls: ['./add-edit-menu.component.scss']
})
export class AddEditMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
