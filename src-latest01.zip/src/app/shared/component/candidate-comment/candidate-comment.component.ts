import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { CandidateService } from '../../Services/components-services /candidate.service';

@Component({
  selector: 'app-candidate-comment',
  templateUrl: './candidate-comment.component.html',
  styleUrls: ['./candidate-comment.component.scss']
})
export class CandidateCommentComponent implements OnInit {

  public formData!: FormGroup;

  public stagesArray: Array<any> = [];
  public statusArray: Array<any> = [];

  public isHideDatepicker: boolean = false;
  public isStatus: boolean = false;
  public isCommentSave: boolean = false;
  public isLoading : boolean = false;

  public defaultStatusId: any;
  public formValidations: any = {
    comment: [{ type: 'required', message: ' Comment is required' }]
  };
  
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    public matDialogRef: MatDialogRef<CandidateCommentComponent>,
    public candidateService: CandidateService,
    public formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.formData = this.formBuilder.group({
      application_id: [this.data.last_application.application_id],
      stage_id: [],
      status_id: [],
      comment: ['', Validators.required],
      scheduled_date: []
    })

    let stagesParam = {
      order_by: "display_order", sort_by: "ASC"
    }

    this.candidateService.getStages(stagesParam).subscribe((res: any) => {
      this.stagesArray = res.data;

      let defaultStage: any = null;
      if(this.data && this.data.stageObj && this.data.stageObj.stage_id) {
        defaultStage = this.stagesArray.filter((val) => { return val.stage_id == this.data.stageObj.stage_id });
      } else {
        defaultStage = this.stagesArray.filter((val) => { return val.is_default == 1 });
      }
      if (defaultStage.length) {
        this.isStatus = defaultStage[0].is_status
        this.formData.get('stage_id')?.setValue(defaultStage[0].stage_id)
      }
    }, error => {
      
    })

    let statusParam = {
      order_by: "display_order", sort_by: "ASC"
    }

    this.candidateService.getStatus(statusParam).subscribe((res: any) => {
      this.statusArray = res.data;

      let status: any = null;
      if(this.data && this.data.statusObj && this.data.statusObj.status_id) {
        status = this.statusArray.filter((val) => { return val.status_id == this.data.statusObj.status_id })
      } else {
        status = this.statusArray.filter((val) => { return val.is_default == 1 })
      }

      if (status.length) {
        this.defaultStatusId = status[0].status_id;
        this.formData.get('status_id')?.setValue(status[0].status_id)
      }
    }, error => {
     
    })
    // this.formData.get('comment')?.setValue(this.data.comment)
    if(this.data.status == "Schedule" || this.data.status == "Reschedule"){
      this.isHideDatepicker = true;
      // this.formData.get('scheduled_date')?.setValue(new Date(this.data.scheduled_date))
    }else{
      this.isHideDatepicker = false;
    }
  }
 
  stageChange() {
    let defaultStage = this.stagesArray.filter((val) => { return val.stage_id == this.formData.get('stage_id')?.value });
    if (defaultStage.length) {
      this.isStatus = defaultStage[0].is_status
      if(defaultStage[0].is_status == 0){
        this.isHideDatepicker = false;
      }else if (defaultStage[0].is_status == 1){
            if(this.defaultStatusId == 2 || this.defaultStatusId == 4){
             this.isHideDatepicker = true;
            }else{
             this.isHideDatepicker = false;
            }
      }
  
      if (this.isStatus) {
        this.formData.get('status_id')?.setValue(this.defaultStatusId)
      } else {
        this.formData.get('status_id')?.setValue(null)
      }
    }
  }

  public statusChange(eve: any) {
    if(eve && eve.value === 2) {
      this.isHideDatepicker = true;
    } else if(eve && eve.value === 4){
      this.isHideDatepicker = true;
    } else {
      this.isHideDatepicker = false;
    }
  }


  saveCandidateComment() {
    this.isLoading = true;
    this.isCommentSave = true;
    let obj = this.formData.value;
    obj.scheduled_date = obj.scheduled_date ? moment(obj.scheduled_date).utc().format('YYYY-MM-DD HH:mm') : '';
    this.candidateService.updateCandidateComment(obj).subscribe((response: any) => {
      this.isCommentSave = false;
      this.isLoading = false;
      this.matDialogRef.close();
    }, error => {
      this.isCommentSave = false;
      this.isLoading = false;
    })
  }


}
