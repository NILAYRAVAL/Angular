import { Component, OnInit, Inject, Input } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UtilService } from '../../Services/util.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.scss'],
})
export class AlertDialogComponent implements OnInit {
  public isLoading: boolean = false;

  public input_value: any;

  public message: string = 'Are you sure?';
  public confirmButtonText: string = 'Yes';
  public cancelButtonText: string = 'Cancel';

  alertForm = this.fb.group({
    alert_message: new FormControl(''),
  });

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    public utilService: UtilService,
    public fb: FormBuilder,
    private dialogRef: MatDialogRef<AlertDialogComponent>
  ) {}

  ngOnInit(): void {
    console.log(this.data);

    if (this.data) {
      this.message = this.data.message || this.message;
      this.input_value = this.data.inputData;

      if (this.data.buttonText) {
        this.confirmButtonText =
          this.data.buttonText.ok || this.confirmButtonText;
        this.cancelButtonText =
          this.data.buttonText.cancel || this.cancelButtonText;
      }
    }
    //  this.dialogRef.updateSize('400px','170px')
  }
  onConfirmClick(data: any): void {
    this.utilService.sendUpdate(data.alert_message);
    this.dialogRef.close({ issave: true, name: data.alert_message });
  }
}
