import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImgPdfViewerModalComponent } from './img-pdf-viewer-modal.component';

describe('ImgPdfViewerModalComponent', () => {
  let component: ImgPdfViewerModalComponent;
  let fixture: ComponentFixture<ImgPdfViewerModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImgPdfViewerModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImgPdfViewerModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
