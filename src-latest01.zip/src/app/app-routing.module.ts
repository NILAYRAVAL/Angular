import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '', loadChildren: () => import('./login/login.module')
      .then(mod => mod.LoginModule)
  }
  ,
  {
    path: 'forgot-password', loadChildren: () => import('./forgot-password/forgot-password.module').then(m => m.ForgotPasswordModule),
    
  },
  {
    path: 'application', loadChildren: () => import('./application/application.module').then(m => m.ApplicationModule),
  },
  { path: '', redirectTo: 'application', pathMatch: 'full' },
  { path: '**', redirectTo: 'application' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
