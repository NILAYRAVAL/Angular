import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilService } from '../shared/Services/util.service';
import { AuthService } from '../shared/Services/auth.service';
import { NgOtpInputConfig } from 'ng-otp-input';
import { Subject, debounceTime } from 'rxjs';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
})
export class ForgotPasswordComponent implements OnInit {
  @ViewChild('ngOtpInput') ngOtpInput: any;

  public forgotForm!: FormGroup;
  public OtpUpdate = new Subject<string>();
  public otpMessages: number = 0;

  public returnUrl!: string;
  public view: string = 'Forgot';
  public email : string = 'mansukh005@gmail.com'

  public hide: boolean = true;
  public isLoading : boolean = false;
  
  public optInputConfig :NgOtpInputConfig = {
    allowNumbersOnly: true,
    length: 6,
    isPasswordInput: false,
    disableAutoFocus: true,
  }


  public formValidations: any = {
    email: [
      { type: 'required', message: 'Email is required' },
      { type: 'pattern', message: 'Enter valid email' },
    ],
    password: [{ type: 'required', message: 'Password is required' }],
    confirm_password: [
      { type: 'required', message: 'Confirm Password is required' },
    ],
  };

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    public utilService: UtilService,
    public authService: AuthService,
    private router: Router
  ) {
    this.OtpUpdate.pipe(debounceTime(500)).subscribe((value: any) => {
      this.otpMessages = value
       });
  }

  ngOnInit(): void {
    this.forgotForm = this.formBuilder.group({
      email: [
        '',
        [
          Validators.required,
          Validators.pattern(this.utilService._emialRegExp),
        ],
      ],
      password: ['', [Validators.required]],
      confirm_password: ['', [Validators.required]],
    });
  }

  onSubmit() {
    this.forgotForm.get('email')?.setValue((this.forgotForm.get('email')?.value
      ? this.forgotForm.get('email')?.value: ' ').trim());
    this.forgotForm.get('password')?.setValue((this.forgotForm.get('password')?.value
      ? this.forgotForm.get('password')?.value: ' ').trim());
    this.forgotForm.updateValueAndValidity();
    this.forgotForm.markAllAsTouched();
    if (this.forgotForm.valid) {
      let basicDetailForm = this.forgotForm.value;
      basicDetailForm.password = this.utilService.convertStringBase64(
        basicDetailForm.password
      );
      this.authService.loginUser(basicDetailForm).subscribe(
        (res: any) => {
          this.utilService.storeLocalStorageValue('userDetail', res.data);
          this.utilService.storeLocalStorageValue(
            'access_token',
            res.access_token,
            false
          );
          this.router.navigateByUrl('/application/dashboard');
        },
        (error) => {
          if (error && error.error.errors && error.error.errors.failed) {
            this.utilService.showError(error.error.errors.failed[0]);
          }
          if (error && error.error.errors && error.error.errors.password) {
            this.utilService.showError(error.error.errors.password[0]);
          }
        }
      );
    }
  }

  handleOtpChange(event:any){
    this.OtpUpdate.next(event)
  }
 setVal(val:any) {
    this.ngOtpInput.setValue(val);
  }

  public onSendOTP() {
    this.view = 'send_OTP';
  }
  public onVerifyOTP() {
    this.isLoading = true;
    setTimeout(() => {
    this.view = 'reset';
    }, 3000);
    
  }
  public onResetOTP() {
    this.router.navigateByUrl('/');
  }

 
}
