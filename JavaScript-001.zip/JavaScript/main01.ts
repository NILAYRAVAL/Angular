import { SyntaxKind } from "typescript";

let Name: string = "Nilay"
console.log(Name);

const car: { type: string, model: string, year: number }
  = { type: "Toyota", model: "Corolla", year: 2009 };
console.log(car);

// Ans { type: 'Toyota', model: 'Corolla', year: 2009 }


interface Person {
  name: string;
  location: string;
  isProgrammer: boolean;
}

let person1: Person = {
  name: 'Danny',
  location: 'UK',
  isProgrammer: true,
};

let person2: Person = {
  name: 'Sarah',
  location: 'Germany',
  isProgrammer: false,
};

console.log(person1)   // Ans { name: 'Danny', location: 'UK', isProgrammer: true }
console.log(person2)   // Ans { name: 'Sarah', location: 'Germany', isProgrammer: false }


interface Speech {
  sayHi(name: string): string;
  sayBye: (name: string) => string;
}

let sayStuff: Speech = {
  sayHi: function (name: string) {
    return `Hi ${name}`;
  },
  sayBye: (name: string) => `Bye ${name}`,
};

console.log(sayStuff.sayHi('Heisenberg')); // Hi Heisenberg
console.log(sayStuff.sayBye('Heisenberg')); // Bye Heisenberg




class Person {
  name: string;
  isCool: boolean;
  pets: number;

  constructor(n: string, c: boolean, p: number) {
    this.name = n;
    this.isCool = c;
    this.pets = p;
  }

  sayHello() {
    return `Hi, my name is ${this.name} and I have ${this.pets} pets`;
  }
}

const person1 = new Person('Danny', false, 1);
const person2 = new Person('Sarah', 'yes', 6);
console.log(person1.sayHello()); // Hi, my name is Danny and I have 1 pets


interface Person {    // we can also use interface <=> type
  name: string,
  gender: string
}

function sayhey(person: Person) {
  console.log(`Hello my name is ${person.name}`)

}

sayhey({
  name: "Nilay",
  gender: "Male"
})
// ANS Hello my name is Nilay



function sayHi(person: { name: string; age: number }) {
  console.log(`Hi ${person.name}`);
}

sayHi({
  name: 'John',
  age: 48,
}); // Hi John

// Interface extends 
interface Animal {
  name: string
}

interface Bear extends Animal {
  honey: boolean
}

const bear: Bear = {
  name: "Winnie",
  honey: true,
}
console.log(bear) // ANS { name: 'Winnie', honey: true }


// Re-opening the Animal interface
interface Animal {
  name: string
}

// Re-opening the Animal interface to add a new field
interface Animal {
  tail: boolean
}

const dog: Animal = {
  name: "Bruce",
  tail: true,
}
console.log(dog)   // ANS { name: 'Bruce', tail: true }


// Literal types in TypeScript
let favouriteColor: 'red' | 'blue' | 'green' | 'yellow';
favouriteColor = 'blue';
// favouriteColor = 'crimson';  // Error
console.log(favouriteColor)  // ANS blue


