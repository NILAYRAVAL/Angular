export const environment = {
  production: true,
  apiHostURL:'https://recruitmentapi.arhamtechs.com/api/',
};
