import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicationComponent } from './application.component';
import { AddEditCandidateComponent } from '../shared/component/add-edit-candidate/add-edit-candidate.component';
import { AuthGuardGuard } from '../shared/Services/auth-guard.guard';

const routes: Routes = [
  {  path: '', component: ApplicationComponent, canActivate: [AuthGuardGuard],
   
    children:[
    {
      path:'',redirectTo:'dashboard',pathMatch:'full'
    },
    {
      path: 'change-password', loadChildren: () => import('./change-password/change-password.module').then(m => m.ChangePasswordModule),
    },
    {
      path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule),
    },
    {
      path: 'positions', loadChildren: () => import('./positions/positions.module').then(m => m.PositionsModule),
    },
    {
      path: 'candidates', loadChildren: () => import('./candidates/candidates.module').then(m => m.CandidatesModule),
    },
    {
      path:"user/:id", component :AddEditCandidateComponent 
    }, 
    {
      path: 'master/qualification', loadChildren: () => import('./master/qualification/qualification.module').then(m => m.QualificationModule),
    },
    {
      path: 'master/skill', loadChildren: () => import('./master/skill/skill.module').then(m => m.SkillModule),
    },
    {
      path: 'master/company', loadChildren: () => import('./master/company/company.module').then(m => m.CompanyModule),
    },
    {
      path: 'master/supplier', loadChildren: () => import('./master/supplier/supplier.module').then(m => m.SupplierModule),
    },
    {
      path: 'master/technologies', loadChildren: () => import('./master/technologies/technologies.module').then(m => m.TechnologieModule)
    },
]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ApplicationRoutingModule { }
