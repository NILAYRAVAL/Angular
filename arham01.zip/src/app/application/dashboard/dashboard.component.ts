import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { CandidateService } from 'src/app/shared/Services/components-services /candidate.service';
import { DashboardService } from 'src/app/shared/Services/components-services /dashboard.service';
import { Location } from '@angular/common';
import { UtilService } from 'src/app/shared/Services/util.service';
import { debounceTime, switchMap } from 'rxjs';

const ELEMENT_DATA: any = [];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

@ViewChild(MatPaginator) paginator!: MatPaginator; 
public searchControl!: FormControl;
  
public candidateShceduleDetails: Array <any> = [];
public  dashboardData: any = [];
public dataSource: any = ELEMENT_DATA;

public candidateId : Number = 1 ;
public total: number = 0;
public currentPage: number = 0;
public pageSize:number = 10;
public pageSizeOptions: number[] = [10, 25, 50, 100];

public companyId : any = null;
public filterValue: any = {};
public compnayData : any;

public displayedColumns: string[] = ['id', 'name', 'mobile', 'stage', 'status', 'scheduled_date','action'];
public searchText: string = '';
public type : string = '';

public isLoading : boolean = false;

  constructor(
    public dashboardService: DashboardService,
    private candidateSerivce: CandidateService,
    public router : Router,
    public location: Location,
    public utilService : UtilService

  ) { }

  ngOnInit(): void {
    this.getDashboarData()
    this.getAllScheduleData()
    this.searchFilter()
  }

public getDashboarData() {
  this.dashboardService.getDashboardCount().subscribe((res:any)=>{ 
    this.dashboardData = res.data
    // console.log(this.dashboardData,'this.dashboardData---');
    
  },
  (error) => {
    if (error && error.error.errors && error.error.errors.failed) {
      this.utilService.showError(error.error.errors.failed[0]);
      this.dataSource = false;
      this.isLoading = false;
}})

}

public searchFilter(){
  this.searchControl = new FormControl('');
  this.searchControl.valueChanges
  .pipe(
    debounceTime(1000),
    switchMap(searchTerm => {
      //Make Api call herecons
      this.searchText = searchTerm
      this.getCandidateBySearch()
      return searchTerm; 
    })
  ).subscribe(result => {
   
  });
}

ngAfterViewInit() {
  this.dataSource.paginator = this.paginator;
}
public pageChangedCommon($event: any) {
  let pageNo = ($event.pageIndex);
  let perPage = $event.pageSize;
  this.filterValue.page_no = pageNo;
  this.getAllScheduleData(pageNo, perPage);

}

public getCandidateBySearch() {
  if(this.searchText.length > 0) {
    this.getAllScheduleData(0, 10, 'ASC', 'person_id', this.searchText, this.filterValue);
  }
  if(!this.searchText.length) {
    this.getAllScheduleData(0, 10, 'ASC', 'person_id', '', this.filterValue);
  }

}
public appendURLParameters() {
  let mergedString: string = '';
  mergedString += `?person_id=${this.companyId}page=${this.filterValue.page_no}`;

  if (this.filterValue.search && this.filterValue.search !== null && this.filterValue.search !== '') {
      mergedString += '&search=' + this.filterValue.search;
  }
  this.location.replaceState('application/dashboard' + mergedString);
  
}


public  getAllScheduleData(pageNo: number = this.currentPage, perPage: number = 10,  sort_by: string = 'ASC',
        order_by: string = 'person_id', search?: string, filters: any = {}, type?: string) {
        // this.isProjectFolderLoading = true;
        this.isLoading = true;
        this.filterValue.per_page = perPage;
        this.filterValue.page_no = pageNo;
        this.filterValue.sort_by = sort_by;
        this.filterValue.order_by = order_by;
        if (search) {
            this.filterValue.search = search;
        } else {
            delete this.filterValue.search;
        }
        if (Object.keys(filters).length) {
            Object.keys(filters).map((key: string) => {
                if (filters[key]) {
                    this.filterValue[key] = filters[key];
                }
            })
        }
        this.appendURLParameters();
        this.filterValue.person_id 
        let filterCopyObj = this.filterValue;
        filterCopyObj.page_no++;

    this.dashboardService.getTodayScheduleData(filterCopyObj).subscribe((res: any) => {
      this.dataSource = res.data;
      // console.log(this.dataSource,'this.dataSource---');
      
      this.total = res.with.total;
      this.currentPage = pageNo;
      this.isLoading = false;

      this.dataSource.forEach((el: any) => {
        this.dataSource.id = el.application_id
        el.name = el.name
        el.mobile = el.phone
        el.email = el.email
        el.mobile = el.phone
        el.stage = el.stage?.stage_name
        el.status = el.status?.status_name
        el.scheduled_date =  moment.utc(el.scheduled_date).local().format('DD-MM-YYYY hh:mm A')
      })
 
    },
    (error) => {
      if (error && error.error.errors && error.error.errors.failed) {
        // this.utilService.showError(error.error.errors.failed[0]);
        this.dataSource = false;
        this.isLoading = false;
  }})
  }

public getAllCandidateHistoryData() {
  this.candidateSerivce.getCandidateHistoryById(this.candidateId).subscribe((res: any) => {
    res.data.forEach((element: any) => {
      element.application_created_at = element.application_created_at ? moment(element.created_at).format('DD-MM-YYYY HH:mm A') : '';
        element.application_statges.forEach((val: any) => {
          val.created_at = val.created_at ? moment(val.created_at).format('DD-MM-YYYY HH:mm A') : '';
          val.scheduled_date = val.scheduled_date ? moment(val.scheduled_date).local().format('DD-MM-YYYY HH:mm A') : '';
        });
    });

    this.candidateShceduleDetails = res.data;
  })
}

public openPositionInNewWindow(element: any) {
  const url = this.router.serializeUrl(this.router.createUrlTree(['/application/candidates/candidate-history/id'], { queryParams: { candidate_id: element.person_id } }));
   window.open(url, '_blank');
 // this.router.navigate(['/application/candidates-history'], { queryParams: { candidate_id:id } }
 }

public onDisplaySchedule(event:any){
    this.type = event;
}

public oonDisplayPostion( ){
  this.router.navigate([`application/positions/`])
}

public onDisplayCandidate( ){
  this.router.navigate([`application/candidates/`])
}

}
