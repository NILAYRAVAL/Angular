import { Location } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { debounceTime, switchMap } from 'rxjs';
import { PositionService } from 'src/app/shared/Services/components-services /position.service';
import { UtilService } from 'src/app/shared/Services/util.service';

const ELEMENT_DATA: any = [];

@Component({
  selector: 'app-position-details',
  templateUrl: './position-details.component.html',
  styleUrls: ['./position-details.component.scss']
})
export class PositionDetailsComponent implements OnInit {

@ViewChild(MatPaginator) paginator!: MatPaginator; 
public searchControl!: FormControl;
  
public positionData : any = [];

public positionId : any = null;
public positon_name : any;
public dataSource: any = ELEMENT_DATA;
public filterValue: any = {};
  
public total: number = 0;
public currentPage: number = 0;
public pageSize:number = 10;
public pageSizeOptions: number[] = [10, 25, 50, 100];
  
public  panelOpenState:boolean = false;
public  isLoading : boolean = false; 
  
public displayedColumns: string[] = ['id', 'name','email', 'mobile', 'stage', 'status', 'action'];
public searchText: string = '';

  constructor(
    private route: ActivatedRoute,
    public positionService:PositionService,
    public location: Location,
    public utilService : UtilService,
    public router: Router
  ) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe((param: any) => {
      this.positionId  =  parseInt(param.position_id)
      this.filterValue = {
        order_by: 'position_id',
        sort_by: 'ASC',
    }
    let pageNumber = param['page'] ? parseInt(param['page']) : 0;
    this.searchText = param['search'] ? param['search'] : undefined;
    this.getAllPositionAppiliedData(pageNumber, 10, 'ASC', 'position_id', this.searchText, this.filterValue )
    this.getPositonDetails()
  })
  this.searchFilter()
  this.getAllPositionAppiliedData()
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  public searchFilter(){
    this.searchControl = new FormControl('');
    this.searchControl.valueChanges
    .pipe(
      debounceTime(1000),
      switchMap(searchTerm => {
        //Make Api call herecons
        this.searchText = searchTerm
        this.getCandidateBySearch()
        return searchTerm; 
      })
    ).subscribe(result => {
     
    });
  }
  
public appendURLParameters() {
    let mergedString: string = '';
    mergedString += `?position_id=${this.positionId}page=${this.filterValue.page_no}`;

    if (this.filterValue.search && this.filterValue.search !== null && this.filterValue.search !== '') {
        mergedString += '&search=' + this.filterValue.search;
    }
    this.location.replaceState('/application/positions/position-details/id' + mergedString);
}

public pageChangedCommon($event: any) {
  let pageNo = ($event.pageIndex);
  let perPage = $event.pageSize;
  this.filterValue.page_no = pageNo;
  this.getAllPositionAppiliedData(pageNo, perPage);
}
public getCandidateBySearch() {
  if(this.searchText.length > 0) {
    this.getAllPositionAppiliedData(0, 10, 'ASC', 'person_id', this.searchText, this.filterValue);
  }
  if(!this.searchText.length) {
    this.getAllPositionAppiliedData(0, 10, 'ASC', 'person_id', '', this.filterValue);
  }

}

public  getAllPositionAppiliedData(pageNo: number = this.currentPage, perPage: number = 10,  sort_by: string = 'ASC',
  order_by: string = 'person_id', search?: string, filters: any = {}, type?: string) {
        // this.isProjectFolderLoading = true;
        this.isLoading = true;
        this.filterValue.per_page = perPage;
        this.filterValue.page_no = pageNo;
        this.filterValue.sort_by = sort_by;
        this.filterValue.order_by = order_by;
        if (search) {
            this.filterValue.search = search;
        } else {
            delete this.filterValue.search;
        }
        if (Object.keys(filters).length) {
            Object.keys(filters).map((key: string) => {
                if (filters[key]) {
                    this.filterValue[key] = filters[key];
                }
            })
        }
        this.appendURLParameters();
        this.filterValue.position_id = this.positionId
        let filterCopyObj = this.filterValue;
        filterCopyObj.page_no++;

    this.positionService.getPositionAppliedData(this.positionId,filterCopyObj).subscribe((res: any) => {
      this.dataSource = res.data;
      this.total = res.with.total;
      this.currentPage = pageNo;
      this.isLoading = false;

      this.dataSource.forEach((el: any) => {
        this.dataSource.id = el.application_id
        el.position_id = el.last_application?.position_id
        el.name = el.person?.name
        el.mobile = el.person?.phone
        el.email = el.person?.email
        el.mobile = el.person?.phone
        el.stage = el.stage?.stage_name
        el.status = el.status?.status_name
        el.position_name = el.position.technology.technology_name
       
      })
    
    },
    (error) => {
      if (error && error.error.errors && error.error.errors.failed) {
        this.utilService.showError(error.error.errors.failed[0]);
        this.dataSource = false;
        this.isLoading = false;
  }})
  }

public getPositonDetails(){
  this.positionService.getPositionById(this.positionId).subscribe((res:any)=>{
    this.positionData = res.data;
    this.positionData.qualificationsString='';
    this.positionData.qualifications.forEach((el:any)=>{
      this.positionData.qualificationsString +=(this.positionData.qualificationsString ?', ':'') + el.qualification_name
    })
  },
  (error) => {
    if (error && error.error.errors && error.error.errors.failed) {
      this.utilService.showError(error.error.errors.failed[0]);
      this.isLoading = false;
}})
}

public openPositionInNewWindow(element: any) {
  const url = this.router.serializeUrl(this.router.createUrlTree(['/application/candidates/candidate-history/id'], { queryParams: { candidate_id: element.person_id } }));
  window.open(url, '_blank');
}

public goBack(){
  this.utilService.goBack()
}

}
