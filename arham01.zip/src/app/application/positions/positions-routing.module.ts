import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PositionsComponent } from './positions.component';
import { PositionDetailsComponent } from './position-details/position-details.component';

const routes: Routes = [

  { 
    path: '', 
    component: PositionsComponent 
  },
  {
    path : 'position-details/:id',
    component : PositionDetailsComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PositionsRoutingModule { }
