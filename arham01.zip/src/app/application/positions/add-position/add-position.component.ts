import { Component, Inject, OnInit } from '@angular/core';
import { NgForm,FormGroup,FormBuilder,FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GlobalVariableService } from 'src/app/shared/Services/global-variable.service';
//import Editor from './ckeditor5/build/ckeditor';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { DatePipe } from '@angular/common';
import { CommonServiceService } from 'src/app/shared/Services/common-service.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { PositionService } from 'src/app/shared/Services/components-services /position.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { retry } from 'rxjs';

@Component({
  selector: 'app-add-position',
  templateUrl: './add-position.component.html',
  styleUrls: ['./add-position.component.css'],
  providers: [DatePipe]
})
export class AddPositionComponent implements OnInit {

  public technologyList : Array <any> = [] ;
  public degignationList  : Array <any> = [] ;
  public qualificationList  : Array <any> = [] ;

  public Editor = ClassicEditor;
  public isAddPositionLoading: boolean = false;
  public isLoading : boolean = false;

  public expiryDate : string = '';
  public openings_no :string = '';
  public minDate: string = '';
  public experience_max_none : string = ''
 

  public positionBtn: any = null;
  public positionDataId: any = null;

  public formValidations: any = {
     technology_id: [{ type: 'required', message: ' Technology is required' } ],
     designation_id: [{ type: 'required', message: 'Designation is required' } ],
     no_of_openings: [{ type: 'required', message: 'No Of Openings is required' } ],
     budget_min: [{ type: 'required', message: 'Budget Min is required' } ],
     budget_max: [{ type: 'required', message: 'Budget Max is required' } ],
     experience_min: [{ type: 'required', message: 'Experience Min is required' } ],
     experience_max: [{ type: 'required', message: 'Experience Max is required' } ],
     expiry_date: [{ type: 'required', message: 'Expiry Date is required' } ],
     description: [{ type: 'required', message: 'Description is required' } ],
     qualification_ids: [{ type: 'required', message: 'Qualification is required' } ],
     is_open: [{ type: 'required', message: 'Position Status is required' } ],
   
  };

   addPositonForm = this._fb.group({
    technology_id : new FormControl ('',[]), 
    designation_id : new FormControl ('',[]), 
    no_of_openings : new FormControl ('',[]), 
    budget_min : new FormControl ('',[]), 
    budget_max : new FormControl ('',[]), 
    experience_min : new FormControl (), 
    experience_max: new FormControl(), 
    expiry_date : new FormControl (), 
    description : new FormControl ('',[]), 
    qualification_ids : new FormControl ([]), 
    is_open : new FormControl ( ), 
    is_available_for_website : new FormControl (0),
  })

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
              public dialogRef: MatDialogRef<AddPositionComponent>,
              public globalVariable:GlobalVariableService,
              private _commenService : CommonServiceService,
              private _fb : FormBuilder,
              private _utilService : UtilService,
              private _positionService : PositionService,
              private _datePipe: DatePipe,
              public router : ActivatedRoute
              ) { 
                // let myDate = new Date();
                // this.minDate = this._datePipe.transform(myDate, 'yyyy-MM-dd');
               }

  
  ngOnInit(): void {
    this.getTechnologyList()
    this.getDesignationList()
    this.getQualificationList()
    const positionData = this.data.model
    if(this.data.btnName == 'Update'){
    this.openings_no =  positionData.no_of_openings
    this.addPositonForm.patchValue(positionData) // patchValue for edit data //
 
    this.addPositonForm.get('experience_min')?.setValue(Number(positionData.experience_min))
    this.addPositonForm.get('experience_max')?.setValue(Number(positionData.experience_max))
    this.positionDataId = this.data.model.position_id
    this.addPositonForm.get('qualification_ids')?.setValue(positionData.qualificationsIds)
    this.addPositonForm.get('expiry_date')?.setValue(positionData.expiry_date)
    }
  }
 
public getTechnologyList(){
    this._positionService.getTechnologyList().subscribe((res:any)=>{
      this.technologyList = res.data
    }, error => {
      if(error && error.error.errors && error.error.errors.failed) {
        this._utilService.showError(error.error.errors.failed[0]);
        this.isLoading = false;

      }
    })
  }
public getDesignationList(){
    this._positionService.getDesignationList().subscribe((res:any)=>{
      this.degignationList = res.data
    }, error => {
      if(error && error.error.errors && error.error.errors.failed) {
        this._utilService.showError(error.error.errors.failed[0]);
        this.isLoading = false;

      }
    })
  }
public  getQualificationList(){
    this._positionService.getQualificationList().subscribe((res:any)=>{
      this.qualificationList = res.data;
    }, error => {
      if(error && error.error.errors && error.error.errors.failed) {
        this._utilService.showError(error.error.errors.failed[0]);
        this.isLoading = false;

      }
    })
  }

public selectPositionStatus(event:any){
  }

public onSaveData(data:any){
    this.addPositonForm.updateValueAndValidity();
    this.addPositonForm.markAllAsTouched();
    if(this.addPositonForm.invalid){
      return
    }
    this.isLoading = true;
    if(this.data.btnName == 'Save'){
      data.expiry_date = this._datePipe.transform(data.expiry_date,"yyyy-MM-dd");
      data.is_open = parseInt(this.addPositonForm.get('is_open')?.value)
      data.is_available_for_website = data.is_available_for_website ? 1 : 0;

      this._positionService.addUpdatePosition(data).subscribe((res:any)=>{
        if(res) {
          this.isLoading = false;
          this.dialogRef.close(true);
          this._utilService.showSuccess(res.message)
        } 
      }, error => {
        if(error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
        }
      })
    }else if(this.data.btnName == 'Update'){
      data.position_id = this.positionDataId
      data.is_open = parseInt(this.addPositonForm.get('is_open')?.value)
      data.is_available_for_website = data.is_available_for_website ? 1 : 0;
      data.expiry_date = this._datePipe.transform(data.expiry_date,"yyyy-MM-dd");
      this._positionService.addUpdatePosition(data).subscribe((res:any)=>{
        if(res) {
          this.isLoading = false;
          this.dialogRef.close(true);
          this._utilService.showSuccess(res.message)
        }
      }, error => {
        if(error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
          this.isLoading = false;

        }
      })
    }
  }

public  Close() {
    this.dialogRef.close(null);
  }
}
