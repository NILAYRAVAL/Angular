import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnologieListComponent } from './technologie-list.component';

describe('TechnologieListComponent', () => {
  let component: TechnologieListComponent;
  let fixture: ComponentFixture<TechnologieListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TechnologieListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TechnologieListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
