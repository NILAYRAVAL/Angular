import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// import { PositionsRoutingModule } from './positions-routing.module';
import { SharedModule } from 'src/app/shared';
import { CompanyListComponent } from './company-list/company-list.component';
import { CompanyRoutingModule } from './company-routing.module';
import { CompanyDetailComponent } from './company-detail/company-detail.component';
 

@NgModule({
  declarations: [
    CompanyListComponent,
    CompanyDetailComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    CompanyRoutingModule
  ]
})
export class CompanyModule { }
