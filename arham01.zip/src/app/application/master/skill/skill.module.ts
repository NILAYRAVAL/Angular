import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// import { PositionsRoutingModule } from './positions-routing.module';
import { SharedModule } from 'src/app/shared';
import { SkillListComponent } from './skill-list/skill-list.component';
import { SkillRoutingModule } from './skill-routing.module';


@NgModule({
  declarations: [
    SkillListComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    SkillRoutingModule
  ]
})
export class SkillModule { }
