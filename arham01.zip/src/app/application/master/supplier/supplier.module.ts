import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SupplierRoutingModule } from './supplier-routing.module';
import { SupplierComponent } from './supplier.component';
import { SharedModule } from 'src/app/shared';
import { SupplierDetailsComponent } from './supplier-details/supplier-details.component';


@NgModule({
  declarations: [
    SupplierComponent,
    SupplierDetailsComponent
  ],
  imports: [
    CommonModule,
    SupplierRoutingModule,
    SharedModule
  ]
})
export class SupplierModule { }
