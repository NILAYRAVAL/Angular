import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QualificationListComponent } from './qualification-list.component';

const routes: Routes = [
  { path: '', component: QualificationListComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class QualificationRoutingModule { }
