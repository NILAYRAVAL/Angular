import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// import { PositionsRoutingModule } from './positions-routing.module';
import { SharedModule } from 'src/app/shared';
import { QualificationListComponent } from './qualification-list.component';
import { QualificationRoutingModule } from './qualification-routing.module';


@NgModule({
  declarations: [
    QualificationListComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    QualificationRoutingModule
  ]
})
export class QualificationModule { }
