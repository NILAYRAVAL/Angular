import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CandidatesComponent } from './candidates.component';
import { CandidateHistoryComponent } from './candidate-history/candidate-history.component';

const routes: Routes = [

  { 
    path: '', 
    component: CandidatesComponent 
  },
  {
    path : 'candidate-history/:id',
    component : CandidateHistoryComponent
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CandidatesRoutingModule { }
