import {
  AfterViewInit,
  Component,
  ElementRef,
  Inject,
  Input,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  FormControl,
  NgForm,
  Validators,
  FormArray,
  AbstractControl,
  MaxLengthValidator,
  EmailValidator,
  ValidatorFn,
} from '@angular/forms';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { GlobalVariableService } from '../../Services/global-variable.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonServiceService } from '../../Services/common-service.service';
import { UtilService } from '../../Services/util.service';
import { CandidateService } from '../../Services/components-services /candidate.service';
import { DatePipe } from '@angular/common';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';
import { style } from '@angular/animations';
import {
  Observable,
  Subject,
  Subscription,
  filter,
  fromEvent,
  map,
  pipe,
  startWith,
  switchMap,
} from 'rxjs';
import { debounceTime, distinctUntilChanged, tap } from 'rxjs/operators';
import * as moment from 'moment';
import { ProgressSpinnerMode } from '@angular/material/progress-spinner';
import { NgSelectConfig } from '@ng-select/ng-select';
import { PositionService } from '../../Services/components-services /position.service';

@Component({
  selector: 'app-add-edit-candidate',
  templateUrl: './add-edit-candidate.component.html',
  styleUrls: ['./add-edit-candidate.component.css'],
  providers: [DatePipe],
})
export class AddEditCandidateComponent implements OnInit, AfterViewInit {
  
  @ViewChild('fileBrowser') public fileBrowser: any;
  @ViewChild('input_number', { static: false }) input_number!: ElementRef;
  @ViewChild('input_email', { static: false }) input_email!: ElementRef;

  public company_experience!: FormArray;
  public date = new Date();
  public subscription: Subscription[] = [];

  public grandChallengesMultipleMedia: Array<any> = [];
  public compnayList: Array<any> = [];
  public onExistUserList: Array<any> = [];
  public startYearsArray: Array<any> = [];
  public endYearsArray: Array<any> = [];
  public positionList: Array<any> = [];
  public skillList: Array<any> = [];
  public qualificationList: Array<any> = [];
  public supplierList: Array<any> = [];
  public currentStateData: Array<any> = [];
  public currentCityData: Array<any> = [];
  public currentNativeCityData: Array<any> = [];
  public monthArrayList: Array<any> = [];
  public exisUserData: any = [];

  public isAddEditCandidateLoading: boolean = false;
  public changeTitle: boolean = false;
  public inputCustomMonths: boolean = false;
  public addMoreExperience: boolean = false;
  public addExperiance: boolean = false;
  public sourceByRefernce: boolean = false;
  public sourceByItRecruiter: boolean = false;
  public isAddCompany: boolean = false;
  public isExistingnumber: boolean = false;
  public isExistingEmail: boolean = false;
  public isLoading_email: boolean = false;
  public isLoading_phone: boolean = false;
  public isLoading: boolean = false;
  public isContinues: boolean = false;
  public addMoreExperience_intern: boolean = false;
  public addMoreExperience_fresher: boolean = false;
  public isWrongResumeUpload: boolean = false;
  public isSupplierLoader: boolean = false;

  public modeType: string = '';
  public type: string = '';
  public newCompanyName: string = '';
  public fullNewCompanyName: string = '';
  public fileToUploadName: any = '';

  public FindCurrentState: any;
  public FindCity: any;
  public FindNativeState: any;
  public FindNativeCity: any;
  public imageName: any;
  public candiatePosition: any;
  public extraa: any;
  public PicPreview: any;

  public UploadFile: any = {
    fileName: '',
    file: '',
  };

  public formValidations: any = {
    position_id: [{ type: 'required', message: ' Position is required' }],
    name: [
      { type: 'required', message: 'Name is required' },
      { type: 'pattern', message: 'Enter valid Name' },
    ],
    email: [
      { type: 'required', message: 'Email is required' },
      { type: 'pattern', message: 'Enter valid email' },
    ],
    country_code: [{ type: 'required', message: 'Budget Min is required' }],
    phone: [{ type: 'required', message: 'Primary No is required' }],
    second_phone: [{ type: 'required', message: 'Phone is required' }],
    qualification_ids: [
      { type: 'required', message: 'Qualification is required' },
    ],
    experience: [{ type: 'required', message: 'Experience is required' }],
    company_experience: [
      { type: 'required', message: 'Company Experience is required' },
    ],
    skills: [{ type: 'required', message: 'Skills is required' }],
    source: [{ type: 'required', message: 'Source is required' }],
    file: [{ type: 'required', message: 'Upload your Resume as PDF or JPEG.' }],
    reference_by: [{ type: 'required', message: 'Reference is required' }],
    supplier_id: [{ type: 'required', message: 'Supplier Name is required' }],
    current_ctc: [{ type: 'required', message: 'Current CTC is required' }],
    expected_ctc: [{ type: 'required', message: 'Expected CTC is required' }],
    notice_period: [{ type: 'required', message: 'Notice Period is required' }],
    company_name: [{ type: 'required', message: 'Company Name is required' }],
    last_designation: [
      { type: 'required', message: 'Last Designation is required' },
    ],
    start_month: [{ type: 'required', message: 'Start Month is required' }],
    start_year: [{ type: 'required', message: 'Start Year is required' }],
    end_month: [{ type: 'required', message: 'End Month is required' }],
    end_year: [{ type: 'required', message: 'End Year is required' }],
  };

  addEditForm = this._fb.group({
    position_id: new FormControl(''),
    application_id: new FormControl(''),
    person_id: new FormControl(''),
    name: new FormControl('',[Validators.minLength(3), Validators.pattern(/^(\s+\S+\s*)*(?!\s).*$/)]), // this.petern For no-whiteSpace //
    // email: ['', [Validators.required,Validators.pattern(this.utilService._emialRegExp)]] ,
    email: new FormControl(''),
    country_code: new FormControl('+91'),
    second_country_code: new FormControl('+91'),
    phone: new FormControl('',[Validators.minLength(10)]),
    second_phone: new FormControl(''),
    native_state_id: new FormControl(''),
    native_city_id: new FormControl(''),
    current_state_id: new FormControl(''),
    current_city_id: new FormControl(''),
    qualification_ids: new FormControl([]),
    experience: new FormControl(''),
    year_experience: new FormControl(''),
    months_experience: new FormControl(0),
    month_experience: new FormControl(''),
    company_experience: new FormArray([this.addMoreExperianceArray()]),
    skills: new FormControl([]),
    source: new FormControl(''),
    reference_by: new FormControl(''),
    supplier_id: new FormControl(''),
    current_ctc: new FormControl(''),
    expected_ctc: new FormControl(''),
    notice_period: new FormControl(''),
    file: new FormControl(''),
  });
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<AddEditCandidateComponent>,
    public globalVariable: GlobalVariableService,
    public matDialog: MatDialog,
    public globalService: GlobalVariableService,
    public utilService: UtilService,
    private _fb: FormBuilder,
    private _candidateService: CandidateService,
    private dialog: MatDialog,
    private config: NgSelectConfig,
    public positionService: PositionService,

  ) {}

  ngOnInit(): void {
    if (this.data.mode == 'add_candidate') {
      this.type = 'add_candidate';
    }
    this.monthArrayList = this.utilService.experienceMonthArray;
    const currentYear = new Date().getFullYear();
    const range = (start: any, stop: any, step: any) =>
      Array.from(
        { length: (stop - start) / step + 1 },
        (_, i) => start + i * step
      );
    this.startYearsArray = range(currentYear, currentYear - 25, -1);
    this.endYearsArray = range(currentYear, currentYear - 25, -1);
    this.getQualificationList();
    this.getSkillList();
    this.getCompanyList();
    this.candiatePosition = this.data.model;
    this.getCurrentStateIdData();
    this.getPositionName();
    this.setValue();
    
  }

  public setValue(): void {
    if (this.data.mode == 'Apply') {
      this.modeType = this.candiatePosition.technology.technology_name;
      this.addEditForm.controls['position_id'].setValue(
        this.data.model.position_id
      );
    }
    if (this.data.mode == 'Update') {
      this.modeType = 'Edit Candidate';
      if (this.candiatePosition?.experience == 'experienced') {
        this.addMoreExperience = true;
        this.addMoreExperience_fresher = false;
        this.addMoreExperience_intern = false;
        this.setCompanyExpriance();
        if (this.candiatePosition?.person_experience.length == 0) {
          this.removeExp(0);
        }
      } else if (this.candiatePosition.experience === 'fresher') {
        this.addMoreExperience = false;
        this.addMoreExperience_fresher = true;
        this.addMoreExperience_intern = false;
      } else if (this.candiatePosition.experience === 'intern') {
        this.addMoreExperience_intern = true;
        this.addMoreExperience = false;
        this.addMoreExperience_fresher = false;
      }
      if (this.candiatePosition.source === 'reference') {
        this.sourceByRefernce = true;
        this.sourceByItRecruiter = false;
        this.addEditForm
          .get('reference_by')
          ?.setValue(this.candiatePosition?.reference_by);
      } else if (this.candiatePosition.source === 'it-recruiter') {
        this.sourceByRefernce = false;
        this.sourceByItRecruiter = true;
        this.getSupplierList();
      }
      this.imageName = this.candiatePosition.resume?.file_name;
      this.addEditForm.patchValue(this.candiatePosition);
      this.addEditForm
        .get('qualification_ids')
        ?.setValue(this.candiatePosition?.qualificationsIds);
      this.addEditForm.get('skills')?.setValue(this.candiatePosition?.skillIds);
      // if(this.candiatePosition?.current_state?.id && this.candiatePosition?.native_state?.id){
      this.FindCurrentState = this.candiatePosition?.current_state?.id;
      this.sendValueToFindCurrentCity(this.candiatePosition?.current_state?.id);
      this.FindCity = this.candiatePosition?.current_city?.id;

      this.FindNativeState = this.candiatePosition?.native_state?.id;
      this.sendValueToFindNativeCity(this.candiatePosition?.native_state?.id);
      this.FindNativeCity = this.candiatePosition?.native_city?.id;
      // }
      let getYear = (this.candiatePosition.month_experience / 12).toFixed(2);
      let years = getYear.toString().split('.')[0];
      this.addEditForm.get('year_experience')?.setValue(years);
      let Months: any = parseInt(getYear.toString().split('.')[1]);
      Months = Months > 9 ? (Months / 100) * 12 : (Months / 10) * 12;
      Months = Math.round(Months);
      this.addEditForm.get('months_experience')?.setValue(Months);
    } else if (this.data.btnName == 'Save') {
      this.modeType = 'Add Candidate';
    }
  }

  public getPositionName() {
    let queryParams =
      'search=0&order_by=position_id&sort_by=ASC&per_page=1000&page_no=1&is_open=';
    this.positionService.getPositionList(queryParams).subscribe(
      (res: any) => {
        this.positionList = res.data;
      },
      (error) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this.utilService.showError(error.error.errors.failed[0]);
          this.isLoading = false;
        }
      }
    );
  }

  public getCurrentStateIdData() {
    this._candidateService.getCurrentStateIdWithData().subscribe(
      (res: any) => {
        this.currentStateData = res.data;
      },
      (error) => {
        this.isLoading = false;
        if (error && error.error.errors && error.error.errors.failed) {
          this.utilService.showError(error.error.errors.failed[0]);
        }
      }
    );
  }

  public sendValueToFindCurrentCity(event: any) {
    if (event == null) {
      return;
    }
    this.currentCityData = [];
    this.addEditForm.get('current_city_id')?.setValue(null);
    this._candidateService.getCurrentCityIdWithData(event).subscribe(
      (res: any) => {
        this.currentCityData = res.data;
      },
      (error) => {
        this.isLoading = false;
        if (error && error.error.errors && error.error.errors.failed) {
          this.utilService.showError(error.error.errors.failed[0]);
        }
      }
    );
  }

  public sendValueToFindNativeCity(event: any) {
    if (event == null) {
      return;
    }
    this.currentNativeCityData = [];
    this.addEditForm.get('native_city_id')?.setValue(null);
    this._candidateService.getNativeCityIdWithData(event).subscribe(
      (res: any) => {
        this.currentNativeCityData = res.data;
      },
      (error) => {
        this.isLoading = false;
        if (error && error.error.errors && error.error.errors.failed) {
          this.utilService.showError(error.error.errors.failed[0]);
        }
      }
    );
  }

  public openReferenceOrItRecruter(event: any) {
    if (event == 'reference') {
      this.sourceByRefernce = true;
      this.sourceByItRecruiter = false;
    } else if (event == 'it-recruiter') {
      this.getSupplierList();
      this.sourceByItRecruiter = true;
      this.sourceByRefernce = false;
    } else {
      this.sourceByRefernce = false;
      this.sourceByItRecruiter = false;
    }
  }

  public setCompanyExpriance() {
    if (this.candiatePosition.person_experience.length > 0) {
      const companyArray = this.addEditForm.get(
        'company_experience'
      ) as FormArray;
      companyArray.clear();
      this.candiatePosition.person_experience.forEach((element: any) => {
        const group = this.addMoreExperianceArray();
        group.patchValue(element);
        companyArray.push(group);
      });
    }
  }

  public getQualificationList() {
    this.subscription.push(
      this._candidateService.getQualificationList().subscribe(
        (res: any) => {
          this.qualificationList = res.data;
        },
        (error) => {
          if (error && error.error.errors && error.error.errors.failed) {
            this.utilService.showError(error.error.errors.failed[0]);
          }
        }
      )
    );
  }

  public getSkillList() {
    this.subscription.push(
      this._candidateService.getSkillsList().subscribe(
        (res: any) => {
          this.skillList = res.data;
        },
        (error) => {
          if (error && error.error.errors && error.error.errors.failed) {
            this.utilService.showError(error.error.errors.failed[0]);
          }
        }
      )
    );
  }

  public getSupplierList() {
    this.isSupplierLoader = true;
    this.subscription.push(
      this._candidateService.getSupplierData().subscribe(
        (res: any) => {
          this.supplierList = res.data;
          this.isSupplierLoader = false;
        },
        (error) => {
          this.isSupplierLoader = false;
          if (error && error.error.errors && error.error.errors.failed) {
            this.utilService.showError(error.error.errors.failed[0]);
          }
        }
      )
    );
  }

  /*Upload File ot Image */
  public changeFile($event: any) {
    this.UploadFile.fileName = $event.target.files[0].name;
    this.UploadFile.file = $event.target.files[0];
    let file = $event.target.files[0];
    let reader = new FileReader();
    var that = this;
    reader.onloadend = function () {
      that.PicPreview = reader.result;
    };
    reader.readAsDataURL(file);
  }

  public removeFile() {
    this.UploadFile.fileName = '';
    this.UploadFile.fileName = null;
    this.UploadFile.file = null;
  }

  public uploadMultipleChallengeFile() {
    const fd: FormData = new FormData();
    fd.append('grand_challenge_id', this.candiatePosition.editId.toString());
    this.subscription.push(
      this._candidateService.addUpdateCandidate(fd).subscribe(
        (res: any) => {
          this.utilService.showSuccess(
            'Success',
            'Media File Uploaded Successful'
          );
          this.dialogRef.close(true);
        },
        (error: any) => {
          this.utilService.showErrorCall(error, false);
        }
      )
    );
  }
  public uploadMultipleChallengeImage($event: any, variableName: string) {
    if ($event) {
      for (let index = 0; index < $event.target.files.length; index++) {
        let size = $event.target.files[index].size / 1024 / 1024;
        if (size > 24) {
          this.utilService.showSuccess(
            'Please select file less than 24MB ' +
              $event.target.files[index].name,
            'Error'
          );
        } else {
          this.grandChallengesMultipleMedia.push($event.target.files[index]);
          var url = $event.target.files[index];
          this.imageName = url.name; // show image path name display
        }
      }
    }
  }

  public openFileBrowser() {
    this.fileBrowser.nativeElement.click();
  }

  public bytesToSize(bytes: any) {
    let sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes == 0) return 'n/a';
    this.extraa = Math.floor(Math.log(bytes) / Math.log(1024));
    if (this.extraa == 0) return bytes + ' ' + sizes[this.extraa];
    return (
      (bytes / Math.pow(1024, this.extraa)).toFixed(1) +
      ' ' +
      sizes[this.extraa]
    ); //
  }

  public fileChanged(event: any) {
    if (event.target.value.length != 0) {
      let fileSize = this.bytesToSize(event.target.files[0].size);
      let size: any = fileSize.split(' ');
      if (size > 24) {
        this.utilService.showSuccess(
          'Please select file less than 24MB ' + event.target.files[0].name,
          'Error'
        );
        return;
      }
      if (
        !this.utilService.checkFileUploadType(
          event.target.files[0],
          undefined,
          ['image/jpeg', 'image/png', 'application/pdf']
        )
      ) {
        this.addEditForm.get('file')?.setValue(null);
        this.fileToUploadName = null;
        this.imageName = null;
        this.isWrongResumeUpload = true;
        return;
      } else {
        this.isWrongResumeUpload = false;
      }
      this.fileToUploadName = event.target.files[0].name;
      this.imageName = event.target.files[0].name;
    }
  }

  //fonmArray //
  public addMoreExperianceArray() {
    return this._fb.group({
      company_id: ['0'],
      company_name: [''],
      last_designation: [''],
      start_month: [null],
      start_year: [null],
      end_month: [null],
      end_year: [null],
      isChecked: [null],
      isAddCompany: [false, Validators.required],
    });
  }
  public addMoreExpbtn(event: any) {
    if (event == 'experienced') {
      this.addMoreExperience = true;
      this.addMoreExperience_fresher = false;
      this.addMoreExperience_intern = false;
    } else if (event == 'fresher') {
      this.addMoreExperience = false;
      this.addMoreExperience_fresher = true;
      this.addMoreExperience_intern = false;
      this.removeExp(0);
      const arr: FormArray = this.addEditForm.get(
        'company_experience'
      ) as FormArray;
      arr.controls = [];
    } else if (event == 'intern') {
      this.addMoreExperience_intern = true;
      this.addMoreExperience = false;
      this.addMoreExperience_fresher = false;
      this.removeExp(0);
      const arr: FormArray = this.addEditForm.get(
        'company_experience'
      ) as FormArray;
      arr.controls = [];
    }
  }

  public getControls() {
    return (this.addEditForm.get('company_experience') as FormArray).controls;
  }

  public addMoreExp(): void {
    this.addExperiance = true;
    this.company_experience = this.addEditForm.get(
      'company_experience'
    ) as FormArray;
    this.company_experience.push(this.addMoreExperianceArray());
  }

  public removeExp(index: any) {
    (this.addEditForm.get('company_experience') as FormArray).removeAt(index);
  }

  /*Set Exprience Years or Months*/
  public getStartYear(i: number): any {
    return (this.addEditForm.get('company_experience') as FormArray).at(i).value
      .start_year;
  }

  public getMoths(i: number): any {
    return (this.addEditForm.get('company_experience') as FormArray).at(i).value
      .start_month;
  }

  public getEndYear(i: number): any {
    // (this.addEditForm.get('company_experience') as FormArray).at(i).get('end_year')?.setValue((this.addEditForm.get('company_experience') as FormArray).at(i).value.start_year)
    if (
      (this.addEditForm.get('company_experience') as FormArray).at(i).value
        .isChecked
    ) {
      (this.addEditForm.get('company_experience') as FormArray)
        .at(i)
        .get('end_year')
        ?.setValue('');
    }
    return (this.addEditForm.get('company_experience') as FormArray).at(i).value
      .end_year;
  }

  public isContinuese(i: number): any {
    return (this.addEditForm.get('company_experience') as FormArray).at(i).value
      .isChecked;
  }

  public isCheckBox(event: any, i: any) {
    if (event) {
      //  (this.addEditForm.get('company_experience') as FormArray).at(i).get('isChecked')?.setValue(true),
      (this.addEditForm.get('company_experience') as FormArray)
        .at(i)
        .get('end_month')
        ?.setValue('');

      if (
        (this.addEditForm.get('company_experience') as FormArray).at(i).value
          .isChecked
      ) {
        (this.addEditForm.get('company_experience') as FormArray)
          .at(i)
          .get('end_year')
          ?.setValue('');
      }

      let end_year_control =
        this.addEditForm.controls.company_experience.at(i)?.controls.end_year;
      end_year_control.clearValidators();
      end_year_control.updateValueAndValidity();

      let end_month_control =
        this.addEditForm.controls.company_experience.at(i)?.controls.end_month;
      end_month_control.clearValidators();
      end_month_control.updateValueAndValidity();

      // if((this.addEditForm.get('company_experience') as FormArray).at(i).value.false){
      //   let end_year_control = this.addEditForm.controls.company_experience.at(i)?.controls.end_year;
      //   end_year_control.setValidators([Validators.required]);
      //   end_year_control.updateValueAndValidity();
      //   let end_month_control = this.addEditForm.controls.company_experience.at(i)?.controls.end_month;
      //   end_month_control.setValidators([Validators.required]);
      //   end_month_control.updateValueAndValidity();
      // }
    } else {
      // (this.addEditForm.get('company_experience') as FormArray).at(i).get('isChecked')?.setValue(false)
      // let end_year_control = this.addEditForm.controls.company_experience.at(i)?.controls.end_year;
      // end_year_control.setValidators([Validators.required]);
      // end_year_control.updateValueAndValidity();
      // let end_month_control = this.addEditForm.controls.company_experience.at(i)?.controls.end_month;
      // end_month_control.setValidators([Validators.required]);
      // end_month_control.updateValueAndValidity();
    }
  }

  public changeStartYear(selectedYear: any) {}

  public onPhoneNoChange(eve: any) {
    let primaryPhNo: any = this.addEditForm.get('phone')?.value;
    if(primaryPhNo){
      let secondaryPhNo: any = this.addEditForm.get('second_phone')?.value;
      if (primaryPhNo === secondaryPhNo) {
        this.utilService.showError(
          'Primary and Secondary Phone Number could not be same !'
        );
      }
    }
  }

  /*Add Unique Compny or Show CompnyList */
  public getCompanyList() {
    this.subscription.push(
      this._candidateService.getCompnayList().subscribe(
        (res: any) => {
          this.compnayList = res.data;
        },
        (error) => {
          if (error && error.error.errors && error.error.errors.failed) {
            this.utilService.showError(error.error.errors.failed[0]);
          }
        }
      )
    );
  }

  public onSearchCompany(event: any, index: any): void {
    if (event.target.value) {
      this.newCompanyName = event.target.value;
      let queryParams: any = `search=${event.target.value}&order_by=company_id&sort_by=ASC&per_page=20&page_no=1`;
      this.subscription.push(
        this._candidateService.getCompnayList(queryParams).subscribe(
          (res: any) => {
            this.compnayList = res.data;
            (this.addEditForm.get('company_experience') as FormArray)
              .at(index)
              .get('isAddCompany')
              ?.setValue(true);
          },
          (error) => {
            if (error && error.error.errors && error.error.errors.failed) {
              this.utilService.showError(error.error.errors.failed[0]);
              this.compnayList = [];
              (this.addEditForm.get('company_experience') as FormArray)
                .at(index)
                .get('isAddCompany')
                ?.setValue(true);
            }
          }
        )
      );
    } else {
      this.getCompanyList();
    }
  }

  public onselecteCompany(value: any, index: any) {
    (this.addEditForm.get('company_experience') as FormArray)
      .at(index)
      .get('isAddCompany')
      ?.setValue(false);
  }

  public addCompany(index?: any) {
    const dialogRef = this.dialog.open(AlertDialogComponent, {
      maxWidth: '500px',
      data: {
        message: `Are you sure want to Add this ${this.newCompanyName} Company ?`,
        buttonText: {
          ok: 'Add',
          cancel: 'Cancel',
        },
        inputData:
          this.addEditForm.controls.company_experience.at(index).controls
            .company_name.value,
      },
    });

    dialogRef.afterClosed().subscribe((confirmed: any) => {
      if (confirmed) {
        let payload: any = {
          company_id: 0,
          company_name: confirmed.name,
        };
        this.addEditForm.controls.company_experience
          .at(index)
          .controls.company_name.setValue(confirmed.name);
        this._candidateService
          .addCandidateCompany(payload)
          .subscribe((res: any) => {
            this.newCompanyName = '';
            (this.addEditForm.get('company_experience') as FormArray)
              .at(index)
              .get('isAddCompany')
              ?.setValue(false);
            this.utilService.showSuccess(
              'Success',
              'Company Added Successful!'
            );
            this.getCompanyList();
          });
      }
    });
  }

  public chkAddCompanyBtn() {
    this.company_experience = this.addEditForm.get(
      'company_experience'
    ) as FormArray;
    let chkIsDisabled = this.company_experience.value.filter(
      (res: any) => res.isAddCompany
    );
    return chkIsDisabled.length ? true : false;
  }

  /*check Email and Phone Valid or Not*/
  public ngAfterViewInit(): void {
    // if(this.candiatePosition.application_id){
    //   return;
    // }
    fromEvent(this.input_email.nativeElement, 'keyup')
      .pipe(
        filter(Boolean),
        debounceTime(1000),
        distinctUntilChanged(),
        tap((text) => {
          if (this.addEditForm.get('email')?.valid) {
            this.isLoading_email = true;
            const payload = {
              email: this.input_email.nativeElement.value,
            };
            this.subscription.push(
              this._candidateService.FindExistUserList(payload).subscribe(
                (res: any) => {
                  this.exisUserData = res.data;
                  this.isLoading_email = false;
                  if (res.data) {
                    this.openExistUserModal(this.exisUserData.person_id);
                    this.isExistingnumber = false;
                  }
                },
                (error) => {
                  this.isLoading_email = false;
                  this.isExistingEmail = false;
                }
              )
            );
          }
        })
      )
      .subscribe((val: any) => {});

    //Get Phone Number value //
    fromEvent(this.input_number.nativeElement, 'keyup')
      .pipe(
        filter(Boolean),
        debounceTime(1000),
        distinctUntilChanged(),
        tap((text) => {
          if (
            this.addEditForm.get('phone')?.value?.length == 10 ||
            this.addEditForm.get('phone')?.value == ''
          ) {
            this.isLoading_phone = true;
            const payload = {
              phone: this.input_number.nativeElement.value,
            };
            this.subscription.push(
              this._candidateService.FindExistUserList(payload).subscribe(
                (res: any) => {
                  this.exisUserData = res.data;
                  this.isLoading_phone = false;
                  this.isExistingEmail = false;
                  if (res.data) {
                    this.openExistUserModal(this.exisUserData.person_id);
                  }
                },
                (error) => {
                  this.isLoading_phone = false;
                  this.isExistingnumber = false;
                }
              )
            );
          }
        })
      )
      .subscribe((val: any) => {});
  }

  public openExistUserModal(data: any) {
    const dialogRef = this.dialog.open(AlertDialogComponent, {
      width: '500px',
      data: {
        message: `This user is already exist! Do you want to edit data?`,
        buttonText: {
          ok: 'Yes',
          cancel: 'No',
        },
      },
    });
    dialogRef.afterClosed().subscribe((confirmed: any) => {
      if (confirmed) {
        this.subscription.push(
          this._candidateService.FindExistUserDataById(data).subscribe(
            (res: any) => {
              if (res.data.email == this.input_email.nativeElement.value) {
                this.isExistingEmail = false;
              }
              if (res.data.phone == this.input_number.nativeElement.value) {
                this.isExistingnumber = false;
              }
              this.exisUserData = res.data;
              // let skills_aryStr = '';
              // this.exisUserData.person_skills.forEach((el: any) => {
              //   skills_aryStr += ', ' + el.skill_name;
              // });
              // this.exisUserData.skills_ary = skills_aryStr.split(', ').splice(1);
              this.exisUserData.person_experience.forEach((el: any) => {
                el.company_name = el.company?.company_name;
                el.company_id = el.company?.company_id;
                el.start_month = moment(el.from_due).format('MM');
                el.start_year = moment(el.from_due).format('yyyy');
                el.end_month = moment(el.to_due).format('MM');
                el.end_year = moment(el.to_due).format('yyyy');
              });
              let qualifiactions = '';
              this.exisUserData.person_qualification.forEach((el: any) => {
                qualifiactions += ', ' + el.qualification_name;
              });
              this.exisUserData.qualifiactions = qualifiactions
                .slice(1)
                .toString();
              let qualificationsIds: any[] = [];
              this.exisUserData.person_qualification.forEach((el: any) => {
                qualificationsIds.push(el.qualification_id);
              });
              this.exisUserData.qualificationsIds = qualificationsIds;
              let skillIds: any[] = [];
              this.exisUserData.person_skills.forEach((el: any) => {
                skillIds.push(el.skill_id);
              });
              this.exisUserData.skillIds = skillIds;
              // console.log(this.exisUserData,'this.exisUserData===');
              this.FindCurrentState = this.exisUserData?.current_state?.id;
              this.sendValueToFindCurrentCity(
                this.exisUserData?.current_state?.id
              );
              this.FindCity = this.exisUserData?.current_city?.id;
              this.FindNativeState = this.exisUserData?.native_state?.id;
              this.sendValueToFindNativeCity(
                this.exisUserData?.native_state?.id
              );
              this.FindNativeCity = this.exisUserData?.native_city?.id;
              this.setFromDataOnExistUser(this.exisUserData);
            },
            (error) => {
              if (error && error.error.errors && error.error.errors.failed) {
                this.utilService.showError(error.error.errors.failed[0]);
              }
            }
          )
        );
      } else {
        if (
          this.addEditForm.get('email')?.value == '' ||
          this.addEditForm.get('email')?.value !== this.exisUserData.email
        ) {
          this.isExistingEmail = false;
        } else {
          this.isExistingEmail = true;
        }
        if (
          this.addEditForm.get('phone')?.value == '' ||
          this.addEditForm.get('phone')?.value !== this.exisUserData.phone
        ) {
          this.isExistingnumber = false;
        } else {
          this.isExistingnumber = true;
        }
      }
    });
  }

  public setFromDataOnExistUser(data: any) {
    this.candiatePosition = data;
    if (this.candiatePosition.experience == 'experienced') {
      this.addEditForm
        .get('experience')
        ?.setValue(this.candiatePosition.experience);
      this.addMoreExperience = true;
      this.setCompanyExpriance();
    } else if (this.candiatePosition.experience === 'fresher') {
      this.addMoreExperience = false;
      this.addMoreExperience_fresher = true;
      this.addMoreExperience_intern = false;
    } else if (this.candiatePosition.experience === 'intern') {
      this.addMoreExperience_intern = true;
      this.addMoreExperience = false;
      this.addMoreExperience_fresher = false;
    }
    if (this.candiatePosition.source === 'reference') {
      this.sourceByRefernce = true;
      this.sourceByItRecruiter = false;
      this.addEditForm
        .get('reference_by')
        ?.setValue(this.candiatePosition?.reference_by);
    }
    // this.imageName = this.candiatePosition.resume?.file_name;
    this.addEditForm
      .get('phone')
      ?.setValue(this.candiatePosition?.person?.phone);
    this.addEditForm
      .get('second_phone')
      ?.setValue(this.candiatePosition?.person?.second_phone);
    this.addEditForm
      .get('qualification_ids')
      ?.setValue(this.candiatePosition?.qualificationsIds);
    this.addEditForm.patchValue(this.candiatePosition);
    this.addEditForm.get('skills')?.setValue(this.exisUserData.skillIds);
  }


  // onSaveFormData //
  public onNoClick(formData: any): void {
    this.onSubmitData(formData);
  }
  public genrateFormData(form: any) {
    const fd: FormData = new FormData();
    Object.keys(form).map((key: string) => {
      let value: any = form[key];
      if (Array.isArray(value)) {
        value.map((val) => {
          fd.append(key, val);
        });
        if (!value.length) {
          fd.append(key, '[]');
        }
      } else {
        if (value != null) {
          fd.append(key, value);
        } else if(value == undefined){
          fd.append(key, '');
        }else {
          fd.append(key, '');
        }
      }
    });
    return fd;
  }

  public onSubmitData(formData: any) {
    console.log(formData);
    
    this.addEditForm.markAllAsTouched();
    this.addEditForm.updateValueAndValidity();
    if (!this.imageName) {
      this.addEditForm.controls['file'].setValidators([Validators.required]);
    } else if (this.candiatePosition?.resume?.file_name) {
      this.addEditForm.get('file')?.clearValidators();
      this.addEditForm.get('file')?.updateValueAndValidity();
    }

    if (this.addMoreExperience_fresher || this.addMoreExperience_intern) {
      const arr: FormArray = this.addEditForm.get(
        'company_experience'
      ) as FormArray;
      arr.controls = [];
    }
    if (this.addEditForm.invalid) {
      this.isLoading = false;
      return;
    }
    if (!this.addEditForm.get('file')?.value &&this.data.btnName !== 'Update'
    ) {
      return;
    }
    this.isLoading = true;
    let yearOfMonths =
      formData.months_experience + formData.year_experience * 12;
    formData.month_experience = yearOfMonths;
    if (formData.company_experience) {
      formData.company_experience.forEach((element: any) => {
        if (
          !element.start_month ||
          !element.start_year ||
          !element.end_year ||
          !element.end_month
        ) {
          element.from_due = '';
          element.to_due = '';
        } else {
          element.to_due = element.end_year + '-' + element.end_month;
        }
        if (element.start_month || element.start_year) {
          element.from_due = element.start_year + '-' + element.start_month;
        }
        if (
          element.start_year &&
          element.start_year &&
          element.start_month &&
          element.end_month
        ) {
          let getExpOfMonths =
            parseInt(element.start_year) - parseInt(element.end_year);
          let yearOfMoth = (getExpOfMonths * 12).toString().slice(1);
          let months =
            Number(element.start_month.substring(1)) +
            Number(element.end_month.substring(1));
          element.month_experience = parseInt(yearOfMoth) + months;
        } else if (element.start_month && element.start_year) {
          let yearOfMoth = 12;
          let months = Number(element.start_month.substring(1));
          element.month_experience = Number(yearOfMoth) + months;
        }

        let chkCmpId = this.compnayList.filter(
          (res: any) => res.company_name === element.company_name
        );
        if (chkCmpId.length) {
          element.company_id = chkCmpId[0].company_id;
        }
      });
      // formData.company_experience = JSON.stringify(formData.company_experience);
    } else {
      formData.company_experience = null;
    }

    if (this.data.btnName == 'Update') {
      formData.application_id =
        this.candiatePosition.last_application?.application_id;
      formData.person_id = this.candiatePosition.last_application?.person_id;
      if (
        this.candiatePosition.supplier_id == null &&
        formData.supplier_id == null
      ) {
        formData.supplier_id = '';
      }
      if (
        this.candiatePosition.current_ctc == null &&
        formData.current_ctc == null
      ) {
        formData.current_ctc = '';
      }
    }

    let payloadObj: any = formData;
    if (this.addMoreExperience) {
      payloadObj.company_experience = JSON.stringify(
        formData.company_experience
      );
    } else if (this.addMoreExperience == false) {
      payloadObj.company_experience = '';
    }
    payloadObj['qualification_ids[]'] = formData.qualification_ids;
    payloadObj['person_skils[]'] = formData.skills;
    payloadObj['file'] =
      this.fileBrowser.nativeElement.files.length > 0
        ? this.fileBrowser.nativeElement.files[0]
        : null;
    delete payloadObj.qualification_ids;
    delete payloadObj.skills;
    const fd: any = this.genrateFormData(payloadObj);
    this.subscription.push(
      this._candidateService.addUpdateCandidate(fd).subscribe(
        (res: any) => {
          this.isLoading = false;
          this.utilService.showSuccess(res.message);
          this.dialogRef.close(true);
        },
        (error) => {
          this.isLoading = false;
          if (error && error.error.errors && error.error.errors.failed) {
            this.utilService.showError(error.error.errors.failed[0]);
          }
          if (error && error.error.errors && error.error.errors.name) {
            this.utilService.showError(error.error.errors.name[0]);
          }
          if (error && error.error.errors && error.error.errors.failed) {
            this.utilService.showError(error.error.errors.phone[0]);
          }
        }
      )
    );
  }

  public ngOnDestroy() {
    this.subscription.forEach((subscriptions) => subscriptions.unsubscribe());
  }
  public Close() {
    this.dialogRef.close(null);
  }
}
