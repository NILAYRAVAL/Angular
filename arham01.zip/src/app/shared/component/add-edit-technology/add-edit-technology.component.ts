import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { TechnologiesService } from '../../Services/components-services /technologies.service';
import { UtilService } from '../../Services/util.service';

@Component({
  selector: 'app-add-edit-technology',
  templateUrl: './add-edit-technology.component.html',
  styleUrls: ['./add-edit-technology.component.scss']
})
export class AddEditTechnologyComponent implements OnInit {
  public subscription : Subscription[] = []

  public isLoading: boolean = false;
  
  public addEditTitle : string= '';


  public formValidations: any = {
    technology_name: [{ type: 'required', message: 'technology Name is required' }]
  };

  addEditForm = this._fb.group({
    technology_name: new FormControl('', Validators.required)
  });

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<AddEditTechnologyComponent>,
    private _fb: FormBuilder,
    private _utilService: UtilService,
    private _technologyService: TechnologiesService,
    private dialog: MatDialog
  ) { }

  ngOnInit(): void {
    if (this.data.btnName == 'Update') {
      this.addEditTitle = 'Edit Technology';
      this.addEditForm.patchValue(this.data.model)
    } else if (this.data.btnName == 'Save') {
      this.addEditTitle = 'Add Technology';
    }
  }
  
  public onNoClick(formData: any): void {
    this.onSubmitData(formData);
  }
  public genrateFormData(form: any) {
    const fd: FormData = new FormData();
    Object.keys(form).map((key: string) => {
      let value: any = form[key];
      if (Array.isArray(value)) {
        value.map((val) => {
          fd.append(key, val);
        });
        if (!value.length) {
          fd.append(key, '[]');
        }
      } else {
        if (value != null) {
          fd.append(key, value);
        } else {
          fd.append(key, '');
        }
      }
    });
    return fd;
  }

  public onSubmitData(formData: any) {
    this.addEditForm.markAllAsTouched();
    this.addEditForm.updateValueAndValidity();
    // this.setCompanyExpriance();
    if(this.addEditForm.invalid){
      this.isLoading = false;
      return;
    }
    this.isLoading = true;
    let payloadObj: any = formData;
    payloadObj.technology_id = this.data.btnName == 'Save' ? 0 : this.data.model.technology_id;
    const fd: any = this.genrateFormData(payloadObj);
    this.subscription.push(this._technologyService.addUpdatetechnology(fd).subscribe(
      (res: any) => {
        this.isLoading = false;
        this._utilService.showSuccess(res.message);
        this.dialogRef.close(true);
      },
      (error) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
        }
      }
    ));
  }
  public Close() {
    this.dialogRef.close(true);
  }

}
