import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { UtilService } from '../../Services/util.service';
import { SupplierService } from '../../Services/components-services /supplier.service';

@Component({
  selector: 'app-add-edit-supplier',
  templateUrl: './add-edit-supplier.component.html',
  styleUrls: ['./add-edit-supplier.component.scss']
})
export class AddEditSupplierComponent implements OnInit {

  public subscription : Subscription[] = []

  public isLoading: boolean = false;
  
  public addEditTitle : string= '';


  public formValidations: any = {
    supplier_name: [{ type: 'required', message: 'Supplier Name is required' }],
    phone: [{ type: 'required', message: 'Phone is required' }],
    email: [{ type: 'required', message: 'Email Name is required' }]
  };

  addEditForm = this._fb.group({
    supplier_name: new FormControl('', Validators.required),
    phone: new FormControl('', Validators.required),
    email: new FormControl('', Validators.required,)
  });



  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<AddEditSupplierComponent>,
    public matDialog: MatDialog,
    private _fb: FormBuilder,
    private _utilService: UtilService,
    public supplierService : SupplierService
  ) { }

  ngOnInit(): void {
    if (this.data.btnName == 'Update') {
      this.addEditTitle = 'Edit Supplier';
      this.addEditForm.patchValue(this.data.model)
    } else if (this.data.btnName == 'Save') {
      this.addEditTitle = 'Add Supplier';
    }
  }

  public onNoClick(formData: any): void {
    this.onSubmitData(formData);
  }

  public genrateFormData(form: any) {
    const fd: FormData = new FormData();
    Object.keys(form).map((key: string) => {
      let value: any = form[key];
      if (Array.isArray(value)) {
        value.map((val) => {
          fd.append(key, val);
        });
        if (!value.length) {
          fd.append(key, '[]');
        }
      } else {
        if (value != null) {
          fd.append(key, value);
        } else {
          fd.append(key, '');
        }
      }
    });
    return fd;
  }

  public onSubmitData(formData: any) {
    this.addEditForm.markAllAsTouched();
    this.addEditForm.updateValueAndValidity();

    if(this.addEditForm.invalid){
      this.isLoading = false;
      return;
    }
    this.isLoading = true;
    let payloadObj: any = formData;
    payloadObj.supplier_id = this.data.btnName == 'Save' ? 0 : this.data.model.supplier_id;
    const fd: any = this.genrateFormData(payloadObj);
    this.subscription.push(this.supplierService.addUpdateSupplier(fd).subscribe(
      (res: any) => {
        this.isLoading = false;
        this._utilService.showSuccess(res.message);
        this.dialogRef.close(true);
      },
      (error) => {
        if (error && error.error.errors && error.error.errors.failed) {
          this._utilService.showError(error.error.errors.failed[0]);
        }
      }
    ));
  }

  public Close() {
    this.dialogRef.close(true);
  }

}
