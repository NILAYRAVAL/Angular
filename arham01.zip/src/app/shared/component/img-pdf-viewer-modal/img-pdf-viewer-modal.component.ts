import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-img-pdf-viewer-modal',
  templateUrl: './img-pdf-viewer-modal.component.html',
  styleUrls: ['./img-pdf-viewer-modal.component.scss']
})
export class ImgPdfViewerModalComponent implements OnInit {
public pdfSrc = "";
public imgSrc = "";

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    public matDialogRef: MatDialogRef<ImgPdfViewerModalComponent>
  ) { }

  ngOnInit(): void {
    if(this.data && this.data.resume) {
      let chkPDF = this.data.resume.file_type.includes("pdf");
      let chkImg = this.data.resume.file_type.includes("image");
      if(chkPDF) {
        this.pdfSrc = this.data.resume.url;
      }

      if(chkImg) {
        this.imgSrc = this.data.resume.url;
      }
    }
  }

  public closeModal() {
    this.matDialogRef.close();
  }

}
