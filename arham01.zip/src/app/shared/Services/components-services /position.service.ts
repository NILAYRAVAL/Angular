import { Injectable } from '@angular/core';
import {CommonService } from '../common.service';
 


@Injectable({
  providedIn: 'root'
})
export class PositionService {

  constructor(private _commonService : CommonService) { }

  public getPositionDetail(data: FormData) {
    return this._commonService.get(`positions/`, data);
  }

  public getPositionAppliedData(positionId:any,params: any) {
    return this._commonService.post(`positions/${positionId}/applications`,params);
  }

  public getPositionById(positionId:any) {
    return this._commonService.get(`positions/${positionId}` );
  }

  public addUpdatePosition(data: FormData) {
    return this._commonService.postWithFormData(`positions/store-update`, data);
  }

  public getPositionList(params: any) {
    return this._commonService.get(`positions?`, params);
  }
  
 
  public deletepsition(eventId: any) {
    return this._commonService.delete(`positions/${eventId}`);
  }

  // get form option array list //

  public getQualificationList( ) {
    return this._commonService.get(`qualifications`);
  }

  public getDesignationList( ) {
    return this._commonService.get(`designations`);
  }

  public getTechnologyList() {
    return this._commonService.get(`technologies`);
  }

 

}
