import { Injectable } from '@angular/core';
import {CommonService } from '../common.service';
 


@Injectable({
  providedIn: 'root'
})
export class QualificationService {

  constructor(private _commonService : CommonService) { }

  public addUpdateQualification(data: FormData) {
    return this._commonService.postWithFormData(`qualifications/store-update`, data);
  }

  public getQualificationList(params: any) {
    return this._commonService.get(`qualifications?`, params);
  }
   
  public deleteQualification(qualificationId: any) {
    return this._commonService.delete(`qualifications/${qualificationId}`);
  }

}
