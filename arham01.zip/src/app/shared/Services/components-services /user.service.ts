import { Injectable } from '@angular/core';
import { CommonService } from '../common.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private _commonService : CommonService) { }

  public userChangePassword(data:any){
   return this._commonService.postWithFormData(`change-password`,data)
  }
}
