import { Injectable } from '@angular/core';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public base: string = 'auth/';

  constructor(private commonService: CommonService) { }

  public loginUser(data:FormData){
    return this.commonService.post(this.base + 'login', data);
  }

  // public getUserLists(data: any) {
  //   return this.commonService.post('users', data);
  // }

  // public getUserDetail(userId: any) {
  //   return this.commonService.get(`users/${userId}`);
  // }

  // public blockUnBlockUser(data:FormData){
  //   return this.commonService.post('users/block-unblock', data);
  // }

  // public getContactList(data: any) {
  //   return this.commonService.post(`contactus/list`, data);
  // }

}
