import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobalVariableService {

  public positionData: any = {
    positionId: 0,
    technology:'',
    experience:'',
    qualifiactions:[],
    noOfOpenings:0,
    jobdescribtion:'',
    budget:'',
    duration:'',
    designation:'',
    expiryDate:''
    
  };

  public candidateData: any = {
    candidateId: 0,
    name:'',
    email:'',
    mobile:'',
    stage:'',
    status:''
  };

public technology :any = [
  { display: 'Angular', val: 'Angular' },
  { display: 'React', val: 'React' },
  { display: '.Net', val: '.Net' },
  { display: 'Ionic', val: 'Ionic' },
  { display: 'Android', val: 'Android' },
  { display: 'HTML SCSS', val: 'HTML SCSS' },
  { display: 'Java Script', val: 'Java Script'},
  { display: 'Node.Js', val: 'Node.Js'},
  { display: 'MEAN Stack', val: 'MEAN Stack' },
  { display: 'MERN Stack', val: 'MERN Stack' },
  { display: 'Full Stack', val: 'Full Stack' },
  
]

public minExperiences: any = [
   { display: '0.6 Months',val: 0.6  },
   { display: '1 Years', val: 1  },
   { display: '1.5 Years', val:1.5 },
   { display: '2 Years', val: 2  },
   { display: '2.5 Years', val:2.5  },
   { display: '3 Years', val: 3 },
   { display: '3.5 Years', val: 3.5  },
   { display: '4 Years', val: 4 },
   { display: '4.5 Years', val: 4.5},
   { display: '5 Years', val: 5  },
   { display: '5.5 Years', val: 5.5  },
   { display: '6 Years', val: 6  },
   { display: '6.5 Years', val: 6.5 },
   { display: '7 Years', val: 7  },
   { display: '7.5 Years', val: 7.5 },
   { display: '8 Years', val: 8  },
   { display: '8.5 Years', val: 8.5},
   { display: '9 Years', val: 9  },
   { display: '9.5 Years', val: 9.5 },
   { display: '10 Years', val: 10  },
   { display: '10.5 Years', val: 10.5  },
   { display: '11 Years', val: 11  },
   { display: '11.5 Years', val: 11.5 },
   { display: '12 Years', val: 12  },
];

  public maxExperiences: any = [
    { display: '0.6 Months',val: 0.6 },
    { display: '1 Years', val: 1  },
    { display: '1.5 Years', val:1.5 },
    { display: '2 Years', val: 2  },
    { display: '2.5 Years', val:2.5  },
    { display: '3 Years', val: 3 },
    { display: '3.5 Years', val: 3.5  },
    { display: '4 Years', val: 4 },
    { display: '4.5 Years', val: 4.5},
    { display: '5 Years', val: 5  },
    { display: '5.5 Years', val: 5.5  },
    { display: '6 Years', val: 6  },
    { display: '6.5 Years', val: 6.5 },
    { display: '7 Years', val: 7  },
    { display: '7.5 Years', val: 7.5 },
    { display: '8 Years', val: 8  },
    { display: '8.5 Years', val: 8.5},
    { display: '9 Years', val: 9  },
    { display: '9.5 Years', val: 9.5 },
    { display: '10 Years', val: 10  },
    { display: '10.5 Years', val: 10.5  },
    { display: '11 Years', val: 11  },
    { display: '11.5 Years', val: 11.5 },
    { display: '12 Years', val: 12  },

];

public monthArray: Array<any> = [
  { name: 'Jan', value: '01' },
  { name: 'Feb', value: '02' },
  { name: 'Mar', value: '03' },
  { name: 'Apr', value: '04' },
  { name: 'May', value: '05' },
  { name: 'Jun', value: '06' },
  { name: 'July', value: '07' },
  { name: 'Aug', value: '08' },
  { name: 'Sep', value: '09' },
  { name: 'Oct', value: '10' },
  { name: 'Nov', value: '11' },
  { name: 'Dec', value: '12' },
];

public months: any = [
                 
  { display: '01', val: '01' },
  { display: '02', val: '02' },
  { display: '03', val: '03' },
  { display: '04', val: '04' },
  { display: '05', val: '05' },
  { display: '06', val: '06' },
  { display: '07', val: '07' },
  { display: '08', val: '08' },
  { display: '09', val: '09' },
  { display: '10', val: '10' },
  { display: '11', val: '11' },
  { display: '12', val: '12' },
   
  
];

public dummy: any = [
  { display: 'dummy1', val: 'dummy1' },
  { display: 'dummy2', val: 'dummy2' },
  { display: 'dummy3', val: 'dummy3' },
  { display: 'dummy4', val: 'dummy4' },
  { display: 'dummy5', val: 'dummy5' },
  { display: 'dummy6', val: 'dummy6' },
  { display: 'dummy7', val: 'dummy7' },
  { display: 'dummy8', val: 'dummy8' },
];

public qualifications: any = [
  { display: 'MCA', val: 'MCA' },
  { display: 'BCA', val: 'BCA' },
  { display: 'BE(IT)', val: 'BE(IT)' },
  { display: 'B-Tech', val: 'B-Tech' },
  { display: 'M-Tech', val: 'M-Tech' },
  { display: 'PGDCA', val: 'PGDCA' },
  { display: 'MDCA', val: 'MDCA' },
 
];

public noOfPosition: any = [
  { display: '1', val: '1' },
  { display: '2', val: '2' },
  { display: '3', val: '3' },
  { display: '4', val: '4' },
  { display: '5', val: '5' },
  { display: '6', val: '6' },
  { display: '7', val: '7' },
];

public designations: any = [
  {display:'Sr. Developer',val:'Sr. Developer'},
  {display:'Jr. Developer',val:'Jr. Developer'},
  {display:'Fresher',val:'Fresher'},

]

public stages: any = [
  {display:'HR Round',val:'HR Round'},
  {display:'Telephonic Round',val:'Telephonic Round'},
  {display:'Practical Task',val:'Practical Task'},
  {display:'Personal Interview',val:'Personal Interview'},

]

public status:any = [
  {display:'Pending',val:'Pending'},
  {display:'Accepted',val:'Accepted'},
  {display:'Rejected',val:'Rejected'},
  {display:'Hold',val:'Hold'},

]


  constructor() { }
}
