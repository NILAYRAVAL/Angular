import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonServiceService {

  public addEditUserAction  = new BehaviorSubject<boolean>(false)
  public addCandidateAction  = new BehaviorSubject<boolean>(false)
  public addEditUserAction1 = new Subject()
  
baseUrl = 'http://localhost:3000/posts';
candidateURL = 'http://localhost:3000/position';

constructor( private http : HttpClient) { }

//using For crud Operation //
getAlluser() {
  return this.http.get(this.baseUrl)
}
saveUser( data: any ) {
  return this.http.post( this.baseUrl, data );
}
deleteUser( id: any ) {
  return this.http.delete( `${this.baseUrl}/${id}` );
}
getUserById( id: number ) {
  return this.http.get( `${this.baseUrl}/${id}` );
}
updateUserData( id: number, data: any ) {
  return this.http.put( `${this.baseUrl}/${id}`, data );
}
//End--- using For crud Operation //

// position for candidate //
sendCandidatePosition(data:any){
  return this.http.post(this.candidateURL,data)
}
getCandidatePositionData(){
  return this.http.get(this.candidateURL)
}

deleteCandidate( id: any ) {
  return this.http.delete( `${this.candidateURL}/${id}` );
}
//end--- position for candidate //

}
