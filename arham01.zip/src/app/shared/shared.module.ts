import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './component/header/header.component';
import { MaterialModule } from './material/material.module';
import { SidebarComponent } from './component/sidebar/sidebar.component';
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddEditCandidateComponent } from './component/add-edit-candidate/add-edit-candidate.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { CandidateCommentComponent } from './component/candidate-comment/candidate-comment.component';
import { NgxMatDateFormats, NgxMatDatetimePickerModule, NgxMatNativeDateModule, NgxMatTimepickerModule, NGX_MAT_DATE_FORMATS } from '@angular-material-components/datetime-picker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { NgOtpInputModule } from 'ng-otp-input';
import { AddEditQualificationComponent } from './component/add-edit-qualification/add-edit-qualification.component';
import { AddEditSkillComponent } from './component/add-edit-skill/add-edit-skill.component';
import { AddEditCompanyComponent } from './component/add-edit-company/add-edit-company.component';
import { ImgPdfViewerModalComponent } from './component/img-pdf-viewer-modal/img-pdf-viewer-modal.component'; 
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { AddEditSupplierComponent } from './component/add-edit-supplier/add-edit-supplier.component';
import { DebounceKeyupDirective } from './directives/debounce-keyup.directive';
import { NgSelectModule } from '@ng-select/ng-select';
import { AddEditTechnologyComponent } from './component/add-edit-technology/add-edit-technology.component';

const CUSTOM_DATE_FORMATS: NgxMatDateFormats = {
  parse: {
    dateInput: "l, LTS"
  },
  display: {
    dateInput: "l, LTS",
    monthYearLabel: "MMM YYYY",
    dateA11yLabel: "LL",
    monthYearA11yLabel: "MMMM YYYY"
  }
};

@NgModule({
  declarations: [
    HeaderComponent,
    SidebarComponent,
    AddEditCandidateComponent,
    CandidateCommentComponent,
    AddEditQualificationComponent,
    AddEditSkillComponent,
    AddEditCompanyComponent,
    ImgPdfViewerModalComponent,
    AddEditSupplierComponent,
    DebounceKeyupDirective,
    AddEditTechnologyComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    CKEditorModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    NgxMatDatetimePickerModule, NgxMatTimepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    NgxMatNativeDateModule,
    MatDatepickerModule,
    PdfViewerModule,
    NgSelectModule

  ], exports: [
    MaterialModule,
    FlexLayoutModule,
    HeaderComponent,
    SidebarComponent,
    FormsModule,
    ReactiveFormsModule,
    CKEditorModule,
    CandidateCommentComponent,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    NgOtpInputModule,
    PdfViewerModule,
    ImgPdfViewerModalComponent,
    NgSelectModule

  ],
  providers: [],

})
export class SharedModule {
  public static forRoot(): ModuleWithProviders<SharedModule> {
    return {
      ngModule: SharedModule,
      providers: []
    }
  }
}
