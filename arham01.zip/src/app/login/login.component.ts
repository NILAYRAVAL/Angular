import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/shared/Services/auth.service';
import { UtilService } from 'src/app/shared/Services/util.service';
import { PasswordStrengthValidator } from '../shared/validations/password.validatores';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

public  loginForm!: FormGroup;

public isLoading : boolean= false;
public  hide : boolean = true;


public formValidations: any = {
    email: [
      { type: "required", message: "Email is required" },
      { type: "pattern", message: "Enter valid email" },
    ],
    password: [
      { type: "required", message: "Password is required" },
    ],
  };


  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    public utilService: UtilService,
    public authService: AuthService,
    private router: Router) { }

  ngOnInit(): void {

    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required,Validators.pattern(this.utilService._emialRegExp)]],
      password: ['',[Validators.required,PasswordStrengthValidator]],
  });
  }

public onSubmit() {
    this.loginForm.get("email")?.setValue((this.loginForm.get("email")
    ?.value? this.loginForm.get("email")?.value : " ").trim());
    this.loginForm.get("password")?.setValue((this.loginForm.get("password")
    ?.value? this.loginForm.get("password")?.value : " ").trim());
    this.loginForm.updateValueAndValidity();
    this.loginForm.markAllAsTouched();
    if (this.loginForm.valid) {
       this.isLoading = true;
      let basicDetailForm = this.loginForm.value
      basicDetailForm.password = this.utilService.convertStringBase64(basicDetailForm.password);
      this.authService.loginUser(basicDetailForm).subscribe((res: any) => {   
        this.isLoading = false;
        this.utilService.storeLocalStorageValue('userDetail',res.data);
        this.utilService.storeLocalStorageValue('access_token',res.access_token,false);
        this.router.navigateByUrl('/application/dashboard');
      }, error => {
        this.isLoading = false;
        if(error && error.error.errors && error.error.errors.failed) {
          this.utilService.showError(error.error.errors.failed[0]);
        }
        if(error && error.error.errors && error.error.errors.password) {
          this.utilService.showError(error.error.errors.password[0]);
        }
      });
    }
  }
 
public forgotPassword(){
  this.router.navigateByUrl('/forgot-password')
}
}
