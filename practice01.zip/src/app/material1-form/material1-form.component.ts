import { Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  Validators,
 
  FormBuilder,
  ValidatorFn,
  AbstractControl,
  ValidationErrors,

} from '@angular/forms';


@Component({
  selector: 'material1-form',
  templateUrl: './material1-form.component.html',
  styleUrls: ['./material1-form.component.css'],
  // standalone: true,


})
export class Material1FormComponent implements OnInit {
  rectiveForm: FormGroup
  hide = true;
  hide1=true;

  confirmPasswordValidator: ValidatorFn = (
    control: AbstractControl
  ): ValidationErrors | null => {
    // console.log(control)
    
    return control.value.passworld === control.value.cpassworld
    ? null
    : { PasswordNoMatch: true };
  };
  // console.log(passworld);
  constructor(private _fb_: FormBuilder) { }

  ngOnInit(): void {
    this.rectiveForm = this._fb_.group({
      fistName:this._fb_.control(null,[Validators.required]),
      lastName:this._fb_.control(null,[Validators.required]),
      email1: this._fb_.control(null, [Validators.required, Validators.email]),
      passworld: this._fb_.control(null, Validators.compose([Validators.required,Validators.pattern('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{10,}$')])),
      cpassworld:this._fb_.control(null,Validators.compose ([Validators.required,Validators.pattern('^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{10,}$')])),
      
      date:this._fb_.control(null,[Validators.required]),
      mobile:this._fb_.control(null,([Validators.required])),
      gender:this._fb_.control('Male',[Validators.required]),
      course:this._fb_.control(null,[Validators.required]),
    },{validator: this.confirmPasswordValidator})
    
  }
  formSubmited() {
    console.log(this.rectiveForm);
    console.log(this.rectiveForm.value);
  }
  getErrorMessage() {
    if (this.rectiveForm.get('email1') .hasError('required')) {
      return 'You must enter a value';
    }

    return this.rectiveForm.get('email1').hasError('email') ? 'Not a valid email' : '';
  }
}
