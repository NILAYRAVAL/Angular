import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Material1FormComponent } from './material1-form.component';

describe('Material1FormComponent', () => {
  let component: Material1FormComponent;
  let fixture: ComponentFixture<Material1FormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Material1FormComponent]
    });
    fixture = TestBed.createComponent(Material1FormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
