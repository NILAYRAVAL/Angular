import { Component } from '@angular/core';

@Component({
  selector: 'pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent {

name:string= "Nilay Raval"
job:string= "Frontend developer"
company:string= "Arham technogies"
dates = new Date()  
a:number = 1.232
b:number = 0.223231

list:string []=["A","B","C"]

pen:boolean=true
}
