import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pipes02Component } from './pipes02.component';

describe('Pipes02Component', () => {
  let component: Pipes02Component;
  let fixture: ComponentFixture<Pipes02Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Pipes02Component]
    });
    fixture = TestBed.createComponent(Pipes02Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
