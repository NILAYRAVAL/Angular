import { Component } from '@angular/core';

@Component({
  selector: 'pipes02',
  templateUrl: './pipes02.component.html',
  styleUrls: ['./pipes02.component.css']
})
export class Pipes02Component {

}
