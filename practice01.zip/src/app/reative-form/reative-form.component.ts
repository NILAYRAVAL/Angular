import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormControl, Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';


@Component({
  selector: 'reative-form',
  templateUrl: './reative-form.component.html',
  
  styleUrls: ['./reative-form.component.css']
})
export class ReativeFormComponent implements OnInit {
  
  reactiveForm: FormGroup;
  proForm: string
  constructor(private _fb_:FormBuilder){}

  ngOnInit() {
    this.reactiveForm = this._fb_.group({
      
      firstName: [null, [Validators.required,Validators.maxLength(3)]],
      lastName: this._fb_.control(null, Validators.compose([Validators.required,Validators.minLength(3)])),
      email: this._fb_.control(null, [Validators.required, Validators.email]),
      dob: [null, Validators.required],
      
      radioss: this._fb_.group({
        phone: [null, Validators.compose ([Validators.required,Validators.maxLength(10),Validators.minLength(4)])],
        gender: [null, Validators.required],
        courses: ['ML', Validators.required]
      }),
      
      skills: this._fb_.array([
        // this._fb_.control(null, Validators.required),
      
      ]),
      
      experiences: this._fb_.array([])
    })
    // statusChanges event 
    this.reactiveForm.statusChanges.subscribe((datas)=>{
      console.log(datas);
      this.proForm = datas
    })
  }

  OnFormSubmitted() {
    console.log(this.reactiveForm);
    console.log(this.reactiveForm.value);
    this.reactiveForm.reset(     
    )
  }
  addSkills() {
    (<FormArray>this.reactiveForm.get('skills'))
    .push(this._fb_.control(null, Validators.required))
  }
  deleteSkills(index: number) {
    const control = (<FormArray>this.reactiveForm.get('skills'));
    control.removeAt(index);
  }
  addExp() {
    const nilay = this._fb_.group({
      company: this._fb_.control(null, Validators.required),
      position: this._fb_.control(null, Validators.required)
    });
    (<FormArray>this.reactiveForm.get('experiences')).push(nilay);
  }
  DeleteExp(pro:number){
    const experiences1= (<FormArray>this.reactiveForm.get('experiences'))
    experiences1.removeAt(pro); 
  }
}
