import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'practice-01';

  onChanges(form: NgForm) {
    // alert("Registration Successful")
    console.log(form);
    // selectValue & patchValue use for updating value
    // pathchValue for specific value
    // setValue use for all values updation
    // output will be this values however we chage value in form
    // form.form.patchValue({
    //   enroll: '123',
    //   email:"hr@gmail.com",
    //   first_name: "NILAY"
    // })
    
    console.log(form.value);
    form.reset()
  }

  Gender = [
    { name: 'gender', value: 'male', display: 'Male' },
    { name: 'gender', value: 'female', display: 'FeMale' },
    { name: 'gender', value: 'other', display: 'Other' },
  ]

  firstNames: string = " ";
  lastNames: string = " ";
  Emails: string = " ";
  Enrollno: string = " "


}
